from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
import tempfile
import uuid
from copy import deepcopy
from pathlib import Path
from typing import Any

from backend.map_store import MapPackageError
from backend.road_router import haversine_m
from backend.validators import MATRIX_SEMANTICS, NODE_TYPES, identifier, number, validate_matrix, validate_node
from tools.common import utc_iso
from tools.validate_map import validate_map_package


class MapRevisionConflict(RuntimeError):
    """The browser is editing an older map revision."""


class MapEditor:
    """Apply a list of map edits as one validated, recoverable commit."""

    EDITABLE_KEYS = ("hex_grid", "roads", "road_graph", "nodes", "matrix")

    def __init__(self, store: Any):
        self.store = store
        self._recover_interrupted_commits()

    def _recover_interrupted_commits(self) -> None:
        """恢复上次进程在多文件替换中途留下的地图包。

        正常提交成功后不会保留旧版；journal 只在提交尚未完成时存在，用于应对
        SIGKILL、进程崩溃或突然断电，而不是历史版本备份。
        """
        root = self.store.root.parent
        if not root.is_dir():
            return
        for journal in root.glob(".*-edit-journal.json"):
            try:
                record = json.loads(journal.read_text(encoding="utf-8"))
                directory = Path(record["directory"]).resolve()
                rollback_dir = Path(record["rollback_dir"]).resolve()
                relatives = record["files"]
                if self.store.root != directory.parent or root != rollback_dir.parent:
                    raise ValueError("提交恢复路径越界")
                if not isinstance(relatives, list) or not all(isinstance(item, str) for item in relatives):
                    raise ValueError("提交恢复文件列表无效")
                self._restore_from_rollback(directory, rollback_dir, {item: None for item in relatives})
                self._fsync_dir(directory)
                journal.unlink()
                self._fsync_dir(root)
                shutil.rmtree(rollback_dir, ignore_errors=True)
                for stale in root.glob(f".{directory.name}-edit-*"):
                    shutil.rmtree(stale, ignore_errors=True)
            except Exception as exc:
                raise MapPackageError(f"无法恢复中断的地图提交 {journal.name}：{exc}") from exc

    # 编辑页要读的必需图层。这里不用 store.manifest()（那会先跑整包校验），
    # 因为编辑页正是拿来修坏地图的地方，校验不过也得能打开。
    SNAPSHOT_LAYERS = ("hex_grid", "road_graph", "nodes")

    def snapshot(self, map_id: str) -> dict[str, Any]:
        with self.store._lock:
            directory = self.store.map_dir(map_id)
            manifest = deepcopy(self.store._read_json(directory / "manifest.json"))
            if not isinstance(manifest, dict):
                raise MapPackageError(f"{map_id} 的 manifest.json 必须是 JSON 对象")
            files = manifest.get("files")
            if not isinstance(files, dict):
                raise MapPackageError(f"{map_id} 的 manifest.json 缺少 files 对象")
            missing = [key for key in self.SNAPSHOT_LAYERS if not files.get(key)]
            if missing:
                raise MapPackageError(f"{map_id} 的 manifest.json 缺少文件条目：{'、'.join(missing)}")
            matrix = {"semantics": MATRIX_SEMANTICS, "row_node_ids": [], "column_node_ids": [], "matrix": []}
            matrix_source = "default"
            if isinstance(files.get("matrix"), str):
                matrix = deepcopy(self.store._read_json(self.store._safe_child(directory, files["matrix"])))
                matrix_source = "local"
            return {
                "revision": self._revision(directory, manifest),
                "manifest": manifest,
                "hex_grid": deepcopy(self.store._read_json(self.store._safe_child(directory, files["hex_grid"]))),
                "road_graph": deepcopy(self.store._read_json(self.store._safe_child(directory, files["road_graph"]))),
                "nodes": deepcopy(self.store._read_json(self.store._safe_child(directory, files["nodes"]))),
                "matrix": matrix.get("matrix", matrix),
                "matrix_row_node_ids": matrix.get("row_node_ids", []),
                "matrix_column_node_ids": matrix.get("column_node_ids", []),
                "matrix_source": matrix_source,
            }

    def commit(self, map_id: str, base_revision: str, operations: list[Any], note: str = "") -> dict[str, Any]:
        if not isinstance(base_revision, str) or not base_revision:
            raise ValueError("缺少地图 revision，请重新加载编辑页")
        if not isinstance(operations, list) or not operations:
            raise ValueError("没有待保存的地图修改")
        if len(operations) > 500:
            raise ValueError("一次最多提交 500 个编辑操作")
        note = str(note or "").strip()[:200]

        with self.store._lock:
            directory = self.store.map_dir(map_id)
            manifest = deepcopy(self.store._read_json(directory / "manifest.json"))
            current_revision = self._revision(directory, manifest)
            if current_revision != base_revision:
                raise MapRevisionConflict("地图已被其他人修改，请重新加载后再编辑")

            files = manifest["files"]
            hex_grid = deepcopy(self.store._read_json(self.store._safe_child(directory, files["hex_grid"])))
            graph = deepcopy(self.store._read_json(self.store._safe_child(directory, files["road_graph"])))
            nodes = deepcopy(self.store._read_json(self.store._safe_child(directory, files["nodes"])))
            matrix = {"semantics": MATRIX_SEMANTICS, "row_node_ids": [], "column_node_ids": [], "matrix": []}
            if isinstance(files.get("matrix"), str):
                matrix = deepcopy(self.store._read_json(self.store._safe_child(directory, files["matrix"])))

            self._normalize_hex_types(hex_grid)
            mqtt_actions: list[dict[str, Any]] = []
            for index, operation in enumerate(operations):
                if not isinstance(operation, dict):
                    raise ValueError(f"第 {index + 1} 个编辑操作必须是对象")
                self._apply_operation(manifest, hex_grid, graph, nodes, matrix, operation, mqtt_actions)

            aligned_matrix, matrix_changed = self._aligned_matrix(matrix, hex_grid, manifest["mine_id"])
            if matrix_changed:
                matrix.clear()
                matrix.update(aligned_matrix)
                mqtt_actions = [action for action in mqtt_actions if action.get("action") != "set_matrix"]
                mqtt_actions.append({"action": "set_matrix", "payload": deepcopy(aligned_matrix)})

            self._check_graph_matches_hexes(hex_grid, graph)
            roads = self._roads_from_graph(graph)
            manifest["files"]["matrix"] = "matrix.json"
            manifest.setdefault("counts", {})["hexagons"] = len(hex_grid["features"])
            manifest["counts"]["road_edges"] = len(graph["edges"])
            manifest["counts"]["static_nodes"] = len(nodes["features"])
            manifest["edited_at"] = utc_iso()
            manifest["editor_revision"] = int(manifest.get("editor_revision", 0)) + 1
            manifest["last_edit_note"] = note
            self._update_bounds(manifest, hex_grid)

            payloads = {
                files["hex_grid"]: hex_grid,
                files["roads"]: roads,
                files["road_graph"]: graph,
                files["nodes"]: nodes,
                "matrix.json": matrix,
                "manifest.json": manifest,
            }
            self._validated_replace(directory, payloads)
            self.store.invalidate(directory)
            result = self.snapshot(map_id)
            result.update({"ok": True, "mqtt_actions": mqtt_actions})
            return result

    def _apply_operation(
        self,
        manifest: dict[str, Any],
        hex_grid: dict[str, Any],
        graph: dict[str, Any],
        nodes: dict[str, Any],
        matrix: dict[str, Any],
        operation: dict[str, Any],
        mqtt_actions: list[dict[str, Any]],
    ) -> None:
        kind = str(operation.get("op", "")).strip()
        if kind == "add_hex":
            self._add_hex(manifest, hex_grid, graph, operation)
        elif kind == "set_hex":
            self._set_hex(hex_grid, nodes, operation, manifest, mqtt_actions)
        elif kind == "delete_hex":
            self._delete_hex(hex_grid, graph, nodes, identifier(operation.get("hex_id"), "hex_id"), manifest, mqtt_actions)
        elif kind == "connect_hexes":
            self._connect(graph, operation, connect=True)
        elif kind == "disconnect_hexes":
            self._connect(graph, operation, connect=False)
        elif kind == "upsert_node":
            raw = operation.get("node")
            if not isinstance(raw, dict):
                raise ValueError("upsert_node.node 必须是对象")
            payload = validate_node({**raw, "mine_id": manifest["mine_id"]})
            self._upsert_node(nodes, payload)
            mqtt_actions.append({"action": "upsert_node", "payload": payload})
        elif kind == "delete_node":
            node_type = str(operation.get("node_type", "")).strip()
            if node_type not in NODE_TYPES:
                raise ValueError("node_type 必须是 loading、unloading 或 charging")
            node_id = identifier(operation.get("node_id"), "node_id")
            self._delete_node(nodes, node_type, node_id)
            mqtt_actions.append(
                {"action": "delete_node", "mine_id": manifest["mine_id"], "node_type": node_type, "node_id": node_id}
            )
        elif kind == "set_matrix":
            raw_matrix: dict[str, Any] = {"mine_id": manifest["mine_id"], "matrix": operation.get("matrix")}
            if "row_node_ids" in operation or "column_node_ids" in operation:
                raw_matrix["row_node_ids"] = operation.get("row_node_ids")
                raw_matrix["column_node_ids"] = operation.get("column_node_ids")
            validated = validate_matrix(raw_matrix)
            if "row_node_ids" in validated:
                expected_rows, expected_columns = self._matrix_node_ids(hex_grid)
                if validated["row_node_ids"] != expected_rows or validated["column_node_ids"] != expected_columns:
                    raise ValueError("矩阵行列节点 ID 与当前装货点、卸货点不一致，请刷新矩阵后重试")
            matrix.clear()
            matrix.update(validated)
            mqtt_actions.append({"action": "set_matrix", "payload": validated})
        else:
            raise ValueError(f"未知编辑操作：{kind or '(空)'}")

    @staticmethod
    def _normalize_hex_types(hex_grid: dict[str, Any]) -> None:
        for feature in hex_grid.get("features", []):
            props = feature.setdefault("properties", {})
            value = props.get("type")
            if value in (None, ""):
                props["type"] = "road"
            elif value not in {"road", *NODE_TYPES}:
                raise ValueError(f"六边形 {props.get('hex_id')} 的 type 无效：{value}")

    @staticmethod
    def _matrix_node_ids(hex_grid: dict[str, Any]) -> tuple[list[str], list[str]]:
        result: dict[str, list[str]] = {"loading": [], "unloading": []}
        for feature in hex_grid.get("features", []):
            props = feature.get("properties") or {}
            node_type = props.get("type")
            if node_type not in result:
                continue
            node_id = identifier(props.get("node_id"), f"{node_type} node_id")
            result[node_type].append(node_id)
        for node_type, values in result.items():
            if len(set(values)) != len(values):
                raise ValueError(f"{node_type} 功能区的 node_id 不能重复")
            values.sort()
        return result["loading"], result["unloading"]

    def _aligned_matrix(
        self, matrix: dict[str, Any], hex_grid: dict[str, Any], mine_id: str
    ) -> tuple[dict[str, Any], bool]:
        row_ids, column_ids = self._matrix_node_ids(hex_grid)
        old_rows = matrix.get("row_node_ids") if isinstance(matrix.get("row_node_ids"), list) else []
        old_columns = matrix.get("column_node_ids") if isinstance(matrix.get("column_node_ids"), list) else []
        old_values = matrix.get("matrix") if isinstance(matrix.get("matrix"), list) else []
        has_labels = bool(old_rows or old_columns)
        values: list[list[int]] = []
        for row_index, row_id in enumerate(row_ids):
            row: list[int] = []
            for column_index, column_id in enumerate(column_ids):
                source_row = old_rows.index(row_id) if has_labels and row_id in old_rows else (-1 if has_labels else row_index)
                source_column = (
                    old_columns.index(column_id) if has_labels and column_id in old_columns else (-1 if has_labels else column_index)
                )
                value = 0
                if source_row >= 0 and source_column >= 0 and source_row < len(old_values):
                    source = old_values[source_row]
                    if isinstance(source, list) and source_column < len(source) and source[source_column] in (1, True):
                        value = 1
                row.append(value)
            values.append(row)
        changed = old_rows != row_ids or old_columns != column_ids or old_values != values
        if not changed:
            return deepcopy(matrix), False
        return validate_matrix(
            {
                "mine_id": mine_id,
                "row_node_ids": row_ids,
                "column_node_ids": column_ids,
                "matrix": values,
            }
        ), True

    def _add_hex(
        self, manifest: dict[str, Any], hex_grid: dict[str, Any], graph: dict[str, Any], operation: dict[str, Any]
    ) -> None:
        # 前端按六边形网格（轴向坐标 q/r）生成严格对齐的顶点，后端校验后直接采用。
        vertices = operation.get("vertices")
        if not isinstance(vertices, list) or len(vertices) < 6:
            raise ValueError("add_hex.vertices 必须是至少 6 个顶点的数组")
        ring: list[list[float]] = []
        for point in vertices:
            if not isinstance(point, (list, tuple)) or len(point) < 2:
                raise ValueError("add_hex.vertices 顶点必须是 [lng, lat]")
            ring.append([round(number(point[0], "longitude", -180, 180), 8), round(number(point[1], "latitude", -90, 90), 8)])
        if ring[0] != ring[-1]:
            ring.append(ring[0])
        center_longitude = sum(point[0] for point in ring[:6]) / 6
        center_latitude = sum(point[1] for point in ring[:6]) / 6
        requested_id = operation.get("hex_id") or f"manual_{uuid.uuid4().hex[:12]}"
        hex_id = identifier(requested_id, "hex_id")
        existing_ids = {str((feature.get("properties") or {}).get("hex_id")) for feature in hex_grid["features"]}
        if hex_id in existing_ids:
            raise ValueError(f"六边形 {hex_id} 已存在")
        size_m = number((manifest.get("build_parameters") or {}).get("hex_size_m", 10), "hex_size_m", 1, 1000)
        for node in graph["nodes"]:
            if haversine_m(center_longitude, center_latitude, float(node["longitude"]), float(node["latitude"])) < size_m * 0.35:
                raise ValueError("新增六边形与现有六边形中心过近")
        properties: dict[str, Any] = {"hex_id": hex_id, "observations": 0, "manual": True, "type": "road"}
        for key in ("q", "r"):
            if operation.get(key) is not None:
                coordinate = number(operation[key], key)
                if not coordinate.is_integer():
                    raise ValueError(f"{key} 必须是整数")
                properties[key] = int(coordinate)
        if "q" in properties and "r" in properties:
            for feature in hex_grid["features"]:
                current = feature.get("properties") or {}
                if current.get("q") is not None and current.get("r") is not None:
                    if (int(current["q"]), int(current["r"])) == (properties["q"], properties["r"]):
                        raise ValueError(f"网格坐标 q={properties['q']}, r={properties['r']} 已有六边形")
        hex_grid["features"].append(
            {
                "type": "Feature",
                "geometry": {"type": "Polygon", "coordinates": [ring]},
                "properties": properties,
            }
        )
        graph["nodes"].append(
            {
                "id": hex_id,
                "longitude": round(center_longitude, 8),
                "latitude": round(center_latitude, 8),
                "observations": 0,
                "manual": True,
            }
        )
        if "q" in properties and "r" in properties:
            neighbor_coordinates = {
                (properties["q"] + dq, properties["r"] + dr)
                for dq, dr in ((1, 0), (1, -1), (0, -1), (-1, 0), (-1, 1), (0, 1))
            }
            feature_by_coordinate = {
                (int(props["q"]), int(props["r"])): str(props["hex_id"])
                for feature in hex_grid["features"]
                if (props := feature.get("properties") or {}).get("q") is not None and props.get("r") is not None
            }
            node_map = {str(node["id"]): node for node in graph["nodes"]}
            for coordinate in sorted(neighbor_coordinates):
                neighbor_id = feature_by_coordinate.get(coordinate)
                if not neighbor_id or neighbor_id == hex_id:
                    continue
                neighbor = node_map[neighbor_id]
                graph["edges"].append(
                    {
                        "from": hex_id,
                        "to": neighbor_id,
                        "distance_m": round(
                            haversine_m(center_longitude, center_latitude, neighbor["longitude"], neighbor["latitude"]), 2
                        ),
                        "traversals": 0,
                        "manual": True,
                    }
                )

    def _set_hex(
        self,
        hex_grid: dict[str, Any],
        nodes: dict[str, Any],
        operation: dict[str, Any],
        manifest: dict[str, Any],
        mqtt_actions: list[dict[str, Any]],
    ) -> None:
        hex_id = identifier(operation.get("hex_id"), "hex_id")
        feature = next(
            (item for item in hex_grid["features"] if str((item.get("properties") or {}).get("hex_id")) == hex_id),
            None,
        )
        if feature is None:
            raise ValueError(f"六边形 {hex_id} 不存在")
        props = feature.setdefault("properties", {})
        previous_type = props.get("type")
        previous_node_id = props.get("node_id")
        raw_type = operation.get("type")
        if raw_type not in {"road", *NODE_TYPES}:
            raise ValueError("色块 type 必须是 road、loading、unloading 或 charging")

        if raw_type == "road":
            if previous_type in NODE_TYPES and previous_node_id:
                self._delete_node(nodes, previous_type, previous_node_id, missing_ok=True)
                mqtt_actions.append(
                    {
                        "action": "delete_node",
                        "mine_id": manifest["mine_id"],
                        "node_type": previous_type,
                        "node_id": previous_node_id,
                    }
                )
            for key in ("node_id", "servers", "max_queue", "average_time_min", "priority", "status"):
                props.pop(key, None)
            props["type"] = "road"
            return

        node_type = str(raw_type)
        params = operation.get("params") if isinstance(operation.get("params"), dict) else {}
        node_id = str(operation.get("node_id") or "").strip()
        if not node_id and previous_type == node_type:
            node_id = str(previous_node_id or "")
        if not node_id:
            existing_ids = {
                (item.get("properties") or {}).get("node_id") for item in hex_grid["features"]
                if (item.get("properties") or {}).get("type") == node_type
            }
            counter = 1
            while f"{node_type}_{counter:03d}" in existing_ids:
                counter += 1
            node_id = f"{node_type}_{counter:03d}"
        node_id = identifier(node_id, "node_id")
        for item in hex_grid["features"]:
            other_props = item.get("properties") or {}
            if str(other_props.get("hex_id")) == hex_id:
                continue
            if other_props.get("type") == node_type and other_props.get("node_id") == node_id:
                raise ValueError(f"功能区 {node_type}/{node_id} 已绑定到另一个六边形")

        coordinates = (feature.get("geometry") or {}).get("coordinates", [[]])[0]
        center_lng = sum(point[0] for point in coordinates[:6]) / 6
        center_lat = sum(point[1] for point in coordinates[:6]) / 6
        same_type = previous_type == node_type
        payload = validate_node(
            {
                "mine_id": manifest["mine_id"],
                "node_type": node_type,
                "node_id": node_id,
                "longitude": round(center_lng, 8),
                "latitude": round(center_lat, 8),
                "altitude": 0.0,
                "servers": params.get("servers", props.get("servers", 1) if same_type else 1),
                "max_queue": params.get("max_queue", props.get("max_queue", 1) if same_type else 1),
                "average_time_min": params.get(
                    "average_time_min", props.get("average_time_min", 0) if same_type else 0
                ),
                "priority": params.get("priority", props.get("priority", 1) if same_type else 1),
                "status": params.get("status", props.get("status", "open") if same_type else "open"),
            }
        )
        if previous_type in NODE_TYPES and previous_node_id and (previous_type, previous_node_id) != (node_type, node_id):
            self._delete_node(nodes, previous_type, previous_node_id, missing_ok=True)
            mqtt_actions.append(
                {
                    "action": "delete_node",
                    "mine_id": manifest["mine_id"],
                    "node_type": previous_type,
                    "node_id": previous_node_id,
                }
            )
        for key in ("node_id", "servers", "max_queue", "average_time_min", "priority", "status"):
            props[key] = payload[key]
        props["type"] = node_type
        self._upsert_node(nodes, payload)
        mqtt_actions.append({"action": "upsert_node", "payload": payload})

    def _delete_hex(
        self,
        hex_grid: dict[str, Any],
        graph: dict[str, Any],
        nodes: dict[str, Any],
        hex_id: str,
        manifest: dict[str, Any],
        mqtt_actions: list[dict[str, Any]],
    ) -> None:
        original = len(hex_grid["features"])
        if original <= 1:
            raise ValueError("地图至少需要保留一个六边形")
        deleted = next(
            (feature for feature in hex_grid["features"] if str((feature.get("properties") or {}).get("hex_id")) == hex_id),
            None,
        )
        hex_grid["features"] = [
            feature for feature in hex_grid["features"] if str((feature.get("properties") or {}).get("hex_id")) != hex_id
        ]
        if len(hex_grid["features"]) == original:
            raise ValueError(f"六边形 {hex_id} 不存在")
        graph["nodes"] = [node for node in graph["nodes"] if str(node.get("id")) != hex_id]
        graph["edges"] = [edge for edge in graph["edges"] if hex_id not in {str(edge.get("from")), str(edge.get("to"))}]
        # 同步删除该色块关联的功能区节点，避免 nodes.geojson 残留孤儿节点
        if deleted is not None:
            props = deleted.get("properties") or {}
            node_type = props.get("type")
            node_id = props.get("node_id")
            if node_type in NODE_TYPES and node_id:
                self._delete_node(nodes, node_type, node_id, missing_ok=True)
                mqtt_actions.append(
                    {"action": "delete_node", "mine_id": manifest["mine_id"], "node_type": node_type, "node_id": node_id}
                )

    @staticmethod
    def _connect(graph: dict[str, Any], operation: dict[str, Any], connect: bool) -> None:
        start = identifier(operation.get("from"), "from")
        end = identifier(operation.get("to"), "to")
        if start == end:
            raise ValueError("道路两端不能是同一个六边形")
        node_map = {str(node.get("id")): node for node in graph["nodes"]}
        if start not in node_map or end not in node_map:
            raise ValueError("道路端点引用了不存在的六边形")
        pair = frozenset((start, end))
        matching = [edge for edge in graph["edges"] if frozenset((str(edge.get("from")), str(edge.get("to")))) == pair]
        if connect:
            if matching:
                raise ValueError("这两个六边形已经连通")
            a, b = node_map[start], node_map[end]
            graph["edges"].append(
                {
                    "from": start,
                    "to": end,
                    "distance_m": round(haversine_m(a["longitude"], a["latitude"], b["longitude"], b["latitude"]), 2),
                    "traversals": 0,
                    "manual": True,
                }
            )
        else:
            if not matching:
                raise ValueError("这两个六边形之间没有道路")
            graph["edges"] = [
                edge for edge in graph["edges"] if frozenset((str(edge.get("from")), str(edge.get("to")))) != pair
            ]

    @staticmethod
    def _upsert_node(nodes: dict[str, Any], payload: dict[str, Any]) -> None:
        node_type, node_id = payload["node_type"], payload["node_id"]
        feature = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [payload["longitude"], payload["latitude"]]},
            "properties": {**payload, "type": node_type},
        }
        for index, current in enumerate(nodes["features"]):
            props = current.get("properties") or {}
            if (props.get("node_type") or props.get("type")) == node_type and props.get("node_id") == node_id:
                nodes["features"][index] = feature
                return
        nodes["features"].append(feature)

    @staticmethod
    def _delete_node(nodes: dict[str, Any], node_type: str, node_id: str, missing_ok: bool = False) -> None:
        original = len(nodes["features"])
        nodes["features"] = [
            feature
            for feature in nodes["features"]
            if not (
                ((feature.get("properties") or {}).get("node_type") or (feature.get("properties") or {}).get("type")) == node_type
                and (feature.get("properties") or {}).get("node_id") == node_id
            )
        ]
        if len(nodes["features"]) == original and not missing_ok:
            raise ValueError(f"功能区 {node_type}/{node_id} 不存在")

    @staticmethod
    def _check_graph_matches_hexes(hex_grid: dict[str, Any], graph: dict[str, Any]) -> None:
        hex_ids = {str((feature.get("properties") or {}).get("hex_id")) for feature in hex_grid.get("features", [])}
        graph_ids = {str(node.get("id")) for node in graph.get("nodes", [])}
        if "None" in hex_ids or len(hex_ids) != len(hex_grid.get("features", [])):
            raise ValueError("六边形 ID 缺失或重复")
        if hex_ids != graph_ids:
            raise ValueError("六边形图层与道路图节点不一致")

    @staticmethod
    def _roads_from_graph(graph: dict[str, Any]) -> dict[str, Any]:
        node_map = {str(node["id"]): node for node in graph["nodes"]}
        features = []
        for edge in graph["edges"]:
            start, end = node_map[str(edge["from"])], node_map[str(edge["to"])]
            features.append(
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "LineString",
                        "coordinates": [
                            [start["longitude"], start["latitude"]],
                            [end["longitude"], end["latitude"]],
                        ],
                    },
                    "properties": deepcopy(edge),
                }
            )
        return {"type": "FeatureCollection", "features": features}

    @staticmethod
    def _update_bounds(manifest: dict[str, Any], hex_grid: dict[str, Any]) -> None:
        coordinates = []
        for feature in hex_grid["features"]:
            coordinates.extend((feature.get("geometry") or {}).get("coordinates", [[]])[0])
        if coordinates:
            longitudes = [float(point[0]) for point in coordinates]
            latitudes = [float(point[1]) for point in coordinates]
            manifest["bounds"] = [min(longitudes), min(latitudes), max(longitudes), max(latitudes)]
            manifest["center"] = [(min(longitudes) + max(longitudes)) / 2, (min(latitudes) + max(latitudes)) / 2]

    def _revision(self, directory: Path, manifest: dict[str, Any]) -> str:
        digest = hashlib.sha256()
        files = manifest.get("files", {})
        for key in self.EDITABLE_KEYS:
            relative = files.get(key)
            if not isinstance(relative, str):
                continue
            path = (directory / relative).resolve()
            if path.is_file() and (path == directory or directory in path.parents):
                digest.update(key.encode("utf-8"))
                digest.update(path.read_bytes())
        return digest.hexdigest()[:20]

    def _validated_replace(
        self,
        directory: Path,
        payloads: dict[str, Any],
    ) -> None:
        # 暂存目录必须和 map_data 在同一个文件系统上（os.replace 跨文件系统会失败），
        # 但绝不能建在 map_data 里面：那里会被 MapStore.discover() 扫描，
        # 提交中途或进程被杀时残留的目录会变成一个"幽灵地图包"。所以放到它上一级。
        staging_root = self.store.root.parent
        temp_dir = Path(tempfile.mkdtemp(prefix=f".{directory.name}-edit-", dir=staging_root))
        rollback_dir = Path(tempfile.mkdtemp(prefix=f".{directory.name}-rollback-", dir=staging_root))
        journal_path = staging_root / f".{directory.name}-edit-journal.json"
        journal_temp = staging_root / f".{directory.name}-edit-journal.tmp"
        try:
            shutil.copytree(directory, temp_dir, dirs_exist_ok=True)
            for relative, payload in payloads.items():
                target = (temp_dir / relative).resolve()
                if temp_dir != target and temp_dir not in target.parents:
                    raise ValueError("地图文件路径越界")
                target.parent.mkdir(parents=True, exist_ok=True)
                # 写完立刻落盘：断电/崩溃时不要留下一个空文件被 os.replace 换到正式包里。
                with open(target, "w", encoding="utf-8") as handle:
                    handle.write(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
                    handle.flush()
                    os.fsync(handle.fileno())
            errors = validate_map_package(temp_dir)
            if errors:
                raise ValueError("地图修改未通过校验：" + "；".join(errors))

            # 旧文件只保留在本次提交使用的临时回滚目录中，成功后立即清理，
            # 不在 map_data 下创建或保留历史版本。
            for relative in payloads:
                source = directory / relative
                if source.is_file():
                    target = rollback_dir / relative
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, target)

            with journal_temp.open("w", encoding="utf-8") as handle:
                json.dump(
                    {
                        "directory": str(directory),
                        "rollback_dir": str(rollback_dir),
                        "files": list(payloads),
                    },
                    handle,
                    ensure_ascii=False,
                )
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.rename(journal_temp, journal_path)
            self._fsync_dir(staging_root)

            # manifest 最后替换；同一 Flask 进程中的读取由 MapStore 的锁隔离。
            ordered = [relative for relative in payloads if relative != "manifest.json"] + ["manifest.json"]
            try:
                for relative in ordered:
                    source = temp_dir / relative
                    target = directory / relative
                    target.parent.mkdir(parents=True, exist_ok=True)
                    os.replace(source, target)
                self._fsync_dir(directory)
                errors = validate_map_package(directory)
                if errors:
                    raise ValueError("替换后校验失败：" + "；".join(errors))
                journal_path.unlink()
                self._fsync_dir(staging_root)
            except Exception:
                # 逐个 os.replace 只能保证单个文件原子，整批不是。
                # 中途失败会留下"新 hex_grid + 旧 manifest"这类混合包，所有接口都读不了。
                # 用本次提交的临时副本恢复，避免留下混合版本地图包。
                self._restore_from_rollback(directory, rollback_dir, payloads)
                self._fsync_dir(directory)
                journal_path.unlink(missing_ok=True)
                self._fsync_dir(staging_root)
                raise
        finally:
            journal_temp.unlink(missing_ok=True)
            shutil.rmtree(temp_dir, ignore_errors=True)
            # journal 仍在说明恢复尚未确认完成，必须保留 rollback 到下次启动。
            if not journal_path.exists():
                shutil.rmtree(rollback_dir, ignore_errors=True)

    @staticmethod
    def _fsync_dir(directory: Path) -> None:
        """把目录项的改动刷到磁盘，保证 os.replace 的结果不会因断电丢失。"""
        try:
            fd = os.open(directory, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(fd)
        except OSError:
            pass  # 有些文件系统不支持对目录 fsync，不影响正确性
        finally:
            os.close(fd)

    @staticmethod
    def _restore_from_rollback(directory: Path, rollback_dir: Path, payloads: dict[str, Any]) -> None:
        for relative in payloads:
            source = rollback_dir / relative
            target = directory / relative
            if source.is_file():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
            elif target.is_file():
                # 提交前本来不存在的新文件，回滚时删掉
                target.unlink()
