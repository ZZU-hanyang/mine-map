from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, request, send_from_directory
from psycopg import Error as PsycopgError

from backend.config import Settings
from backend.map_editor import MapEditor, MapRevisionConflict
from backend.map_store import MapNotFoundError, MapPackageError, MapStore
from backend.postgres_editor import PostgresMapEditor
from backend.postgres_store import PostgresMapStore
from backend.mqtt_bridge import MqttBridge
from backend.road_router import RoadRouter
from backend.validators import validate_matrix, validate_node

LOGGER = logging.getLogger(__name__)


def json_body() -> dict[str, Any]:
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        raise ValueError("请求体必须是 JSON 对象")
    return body


def route_point(body: dict[str, Any], key: str) -> tuple[float, float]:
    value = body.get(key)
    if not isinstance(value, dict):
        raise ValueError(f"{key} 必须包含 longitude 和 latitude")
    try:
        longitude = float(value["longitude"])
        latitude = float(value["latitude"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"{key} 经纬度不正确") from exc
    if not (-180 <= longitude <= 180 and -90 <= latitude <= 90):
        raise ValueError(f"{key} 经纬度越界")
    return longitude, latitude


def map_revision(store: Any, map_id: str | None) -> int | None:
    """读地图包当前版本号（manifest.editor_revision）；缺失或不可解析时返回 None。

    地图包缺失、损坏或 editor_revision 不是数字时一律降级为 None，
    不能让一个版本号把接口打成 500，更不能把服务端数据问题误报成 400。
    """
    if not map_id:
        return None
    try:
        return int(store.manifest(map_id).get("editor_revision", 0) or 0)
    except (MapNotFoundError, MapPackageError, OSError, KeyError, TypeError, ValueError):
        LOGGER.warning("地图 %s 的 editor_revision 不可用，按无版本号处理", map_id)
        return None


def stamp_revision(store: Any, payload: dict[str, Any], map_id: str | None) -> dict[str, Any]:
    """给对外发布的配置消息盖一个版本号，消费方据此判断新旧。

    必须在 validate_node/validate_matrix 之后调用——它们会重建 dict 丢掉未知键。
    """
    revision = map_revision(store, map_id)
    return payload if revision is None else {**payload, "revision": revision}


def create_app(settings: Settings | None = None, start_mqtt: bool = True) -> Flask:
    settings = settings or Settings.from_env()
    frontend_dir = settings.project_root / "frontend"
    app = Flask(__name__, static_folder=None)
    app.config["JSON_AS_ASCII"] = False
    # 编辑提交会在内存中解析完整 JSON；限制请求体，避免异常客户端耗尽内存。
    app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024
    if settings.map_storage == "postgres":
        if not settings.database_url:
            raise RuntimeError("MAP_STORAGE=postgres 时必须配置 DATABASE_URL")
        store = PostgresMapStore(
            settings.database_url,
            min_size=settings.database_pool_min_size,
            max_size=settings.database_pool_max_size,
            timeout_s=settings.database_connect_timeout_s,
        )
        editor = PostgresMapEditor(store)
    else:
        store = MapStore(settings.map_data_root)
        editor = MapEditor(store)
    bridge = MqttBridge(settings, store.mine_ids())
    if start_mqtt:
        bridge.start()
    app.extensions["map_store"] = store
    app.extensions["map_editor"] = editor
    app.extensions["mqtt_bridge"] = bridge
    app.extensions["settings"] = settings

    @app.after_request
    def security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        return response

    def map_id_for_mine(mine_id: str) -> str | None:
        return store.map_id_for_mine(mine_id, settings.active_map_id)

    def safe_layer(map_id: str | None, layer: str) -> tuple[Any | None, str | None]:
        """读图层，失败时返回 (None, 原因) 而不是抛异常。

        /api/runtime 的两个接口跟前端的 /trucks 请求打包在同一个 Promise.all 里，
        任何一个抛错都会让整批结果被丢弃——车辆和功能区会同时从界面消失。
        所以这里降级成空数据，并把原因放进响应体，避免静默。
        """
        if not map_id:
            return None, None
        try:
            return store.layer(map_id, layer), None
        except (MapNotFoundError, MapPackageError, KeyError) as exc:
            LOGGER.warning("读取 %s 的 %s 图层失败：%s", map_id, layer, exc)
            return None, str(exc) or "地图包不可读"

    @app.get("/api/health")
    def health():
        maps = store.discover()
        return jsonify(
            {
                "ok": any(item["valid"] for item in maps),
                "maps": len(maps),
                "valid_maps": sum(1 for item in maps if item["valid"]),
                "map_storage": settings.map_storage,
                "mqtt": bridge.status(),
            }
        )

    @app.get("/api/config")
    def config():
        return jsonify(settings.public_config())

    @app.get("/api/maps")
    def maps():
        return jsonify({"maps": store.discover(), "active_map_id": settings.active_map_id})

    @app.get("/api/maps/<map_id>/manifest")
    def manifest(map_id: str):
        return jsonify(store.manifest(map_id))

    @app.get("/api/maps/<map_id>/layers/<layer>")
    def map_layer(map_id: str, layer: str):
        allowed = {"boundary", "hex_grid", "roads", "nodes", "history_tracks"}
        if layer not in allowed:
            return jsonify({"error": "未知地图图层"}), 404
        return jsonify(store.layer(map_id, layer))

    @app.post("/api/maps/<map_id>/route")
    def route(map_id: str):
        # 只接受起点和终点。车速由服务端固定（.env 的 DEFAULT_SPEED_KMH），
        # 调用方传不传、传什么都不影响结果。
        body = json_body()
        start = route_point(body, "start")
        end = route_point(body, "end")
        router = RoadRouter(store.graph(map_id))
        return jsonify(router.route(start, end, settings.default_speed_kmh))

    @app.get("/api/maps/<map_id>/editor")
    def editor_snapshot(map_id: str):
        # 矩阵以地图包文件为唯一权威，不再用 MQTT 内存副本覆盖
        return jsonify(editor.snapshot(map_id))

    @app.post("/api/maps/<map_id>/editor/commit")
    def editor_commit(map_id: str):
        body = json_body()
        result = editor.commit(
            map_id,
            str(body.get("revision", "")),
            body.get("operations"),
            str(body.get("note", "")),
        )
        warnings: list[str] = []
        published_topics: list[str] = []
        if body.get("publish_mqtt"):
            for action in result.pop("mqtt_actions", []):
                try:
                    if action["action"] == "upsert_node":
                        published_topics.append(bridge.publish_node(stamp_revision(store, action["payload"], map_id)))
                    elif action["action"] == "delete_node":
                        published_topics.append(
                            bridge.delete_node(action["mine_id"], action["node_type"], action["node_id"])
                        )
                    elif action["action"] == "set_matrix":
                        published_topics.append(bridge.publish_matrix(stamp_revision(store, action["payload"], map_id)))
                except Exception as exc:
                    # 地图包此刻已经落盘成功，发布只是尽力而为。这里若冒出去会变成 500，
                    # 客户端以为保存失败去重试，反而撞上 revision 冲突。
                    warnings.append(f"{action.get('action')} 发布失败：{exc}")
        else:
            result.pop("mqtt_actions", None)
        result["published_topics"] = published_topics
        result["warnings"] = warnings
        return jsonify(result)

    @app.get("/api/runtime/<mine_id>/trucks")
    def runtime_trucks(mine_id: str):
        return jsonify({"trucks": bridge.trucks(mine_id)})

    @app.get("/api/runtime/<mine_id>/nodes")
    def runtime_nodes(mine_id: str):
        # 功能区以地图包文件为唯一权威，接口与界面读同一份数据。
        # 未知 mine_id、地图包损坏都返回 200 + 空列表：这个接口跟 /trucks 在同一个
        # Promise.all 里，报错会让车辆数据一起消失。
        map_id = map_id_for_mine(mine_id)
        collection, error = safe_layer(map_id, "nodes")
        if not isinstance(collection, dict):
            return jsonify({"nodes": [], "map_id": map_id, "revision": None, "error": error})
        return jsonify(
            {
                "nodes": [feature.get("properties") or {} for feature in collection.get("features", [])],
                "map_id": map_id,
                "revision": map_revision(store, map_id),
            }
        )

    @app.get("/api/runtime/<mine_id>/matrix")
    def runtime_matrix(mine_id: str):
        map_id = map_id_for_mine(mine_id)
        matrix, error = safe_layer(map_id, "matrix")
        if matrix is None:
            return jsonify({"matrix": None, "map_id": map_id, "revision": None, "error": error})
        return jsonify({"matrix": matrix, "map_id": map_id, "revision": map_revision(store, map_id)})

    @app.get("/api/mqtt/status")
    def mqtt_status():
        return jsonify(bridge.status())

    @app.post("/api/mqtt/nodes")
    def publish_node():
        body = json_body()
        map_id = map_id_for_mine(str(body.get("mine_id", "")))
        payload = stamp_revision(store, validate_node(body), map_id)
        topic = bridge.publish_node(payload)
        return jsonify({"ok": True, "topic": topic, "payload": payload})

    @app.post("/api/mqtt/matrix")
    def publish_matrix():
        body = json_body()
        map_id = map_id_for_mine(str(body.get("mine_id", "")))
        payload = stamp_revision(store, validate_matrix(body), map_id)
        topic = bridge.publish_matrix(payload)
        return jsonify({"ok": True, "topic": topic, "payload": payload})

    @app.get("/")
    def index():
        return send_from_directory(frontend_dir, "index.html")

    @app.get("/<path:filename>")
    def frontend_file(filename: str):
        return send_from_directory(frontend_dir, filename)

    @app.errorhandler(MapNotFoundError)
    def map_not_found(exc: MapNotFoundError):
        return jsonify({"error": f"没有找到地图：{exc.args[0]}"}), 404

    @app.errorhandler(MapPackageError)
    def invalid_map(exc: MapPackageError):
        return jsonify({"error": str(exc)}), 422

    @app.errorhandler(MapRevisionConflict)
    def revision_conflict(exc: MapRevisionConflict):
        return jsonify({"error": str(exc), "code": "revision_conflict"}), 409

    @app.errorhandler(ValueError)
    def bad_request(exc: ValueError):
        return jsonify({"error": str(exc)}), 400

    @app.errorhandler(RuntimeError)
    def runtime_error(exc: RuntimeError):
        return jsonify({"error": str(exc)}), 503

    @app.errorhandler(PsycopgError)
    def database_error(exc: PsycopgError):
        LOGGER.exception("PostgreSQL 操作失败")
        return jsonify({"error": "地图数据库暂时不可用"}), 503

    @app.errorhandler(OSError)
    def os_error(exc: OSError):
        # 磁盘满、权限、文件被占用等。状态码仍然是 500，但要返回 JSON，
        # 否则前端只能看到一个空的错误页，编辑页提交失败时完全不知道发生了什么。
        LOGGER.exception("文件系统操作失败")
        return jsonify({"error": f"文件系统操作失败：{exc}"}), 500

    return app


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    settings = Settings.from_env()
    if settings.host not in {"127.0.0.1", "localhost", "::1"} and not settings.allow_unauthenticated_remote:
        raise RuntimeError(
            "后端包含地图写入接口且尚未实现用户鉴权，默认拒绝监听非本机地址；"
            "应通过带鉴权的反向代理访问。确需直接开放时显式设置 "
            "ALLOW_UNAUTHENTICATED_REMOTE=true"
        )
    app = create_app(settings)
    maps = app.extensions["map_store"].discover()
    if not any(item["valid"] for item in maps):
        LOGGER.warning("没有可用地图包，请先执行建图工具")
    print(f"电子地图：http://{settings.host}:{settings.port}")
    app.run(host=settings.host, port=settings.port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
