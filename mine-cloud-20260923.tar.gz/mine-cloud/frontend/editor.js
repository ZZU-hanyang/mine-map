"use strict";

var editorState = {
  config: null,
  maps: [],
  mapId: null,
  snapshot: null,
  working: null,
  map: null,
  boundaryOverlays: [],
  hexOverlays: new Map(),
  hexLabelOverlays: [],
  candidateOverlays: [],
  candidates: new Map(),   // hexId -> {q, r, hasRoad}
  pendingNewHexId: null,
  paintType: 'road',
  operations: [],      // 每项带 section: 'paint' | 'matrix'
  overlayClickUntil: 0,
};

var TYPE_NAMES = { loading: '装货点', unloading: '卸货点', charging: '充电区', road: '道路' };
var NODE_TYPES = { loading: 1, unloading: 1, charging: 1 };
var HEX_COLORS = { road: '#eeb852', loading: '#2196f3', unloading: '#ef5350', charging: '#ff9800' };
var DEFAULT_PARAMS = { servers: 1, max_queue: 1, average_time_min: 0, priority: 1, status: 'open' };

function $(selector) { return document.querySelector(selector); }
function $$(selector) { return Array.from(document.querySelectorAll(selector)); }
function clone(value) { return JSON.parse(JSON.stringify(value)); }

function escapeHtml(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function toast(message) {
  var el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(function () { el.classList.remove('show'); }, 3500);
}

async function api(url, options) {
  options = options || {};
  var controller = new AbortController();
  var timer = setTimeout(function () { controller.abort(); }, 15000);
  var response;
  try {
    response = await fetch(url, {
      headers: options.body ? { 'Content-Type': 'application/json' } : undefined,
      ...options,
      signal: options.signal || controller.signal,
    });
  } catch (error) {
    if (error && error.name === 'AbortError') throw new Error('请求超时');
    throw error;
  } finally {
    clearTimeout(timer);
  }
  var body;
  try { body = await response.json(); } catch (e) { body = {}; }
  if (!response.ok) {
    var error = new Error(body.error || (response.status + ' ' + response.statusText));
    error.code = body.code;
    throw error;
  }
  return body;
}

function showMessage(message) {
  var el = $('#editorMessage');
  el.textContent = message;
  el.classList.toggle('show', !!message);
}

// ========== WGS84 ↔ 百度坐标（保存仍为 WGS84）==========
var PI = Math.PI, AXIS = 6378245.0, EE = 0.006693421622965943;
function outsideChina(lon, lat) { return lon < 72.004 || lon > 137.8347 || lat < .8293 || lat > 55.8271; }
function transformLat(x, y) {
  var v = -100 + 2 * x + 3 * y + .2 * y * y + .1 * x * y + .2 * Math.sqrt(Math.abs(x));
  v += (20 * Math.sin(6 * x * PI) + 20 * Math.sin(2 * x * PI)) * 2 / 3;
  v += (20 * Math.sin(y * PI) + 40 * Math.sin(y / 3 * PI)) * 2 / 3;
  return v + (160 * Math.sin(y / 12 * PI) + 320 * Math.sin(y * PI / 30)) * 2 / 3;
}
function transformLon(x, y) {
  var v = 300 + x + 2 * y + .1 * x * x + .1 * x * y + .1 * Math.sqrt(Math.abs(x));
  v += (20 * Math.sin(6 * x * PI) + 20 * Math.sin(2 * x * PI)) * 2 / 3;
  v += (20 * Math.sin(x * PI) + 40 * Math.sin(x / 3 * PI)) * 2 / 3;
  return v + (150 * Math.sin(x / 12 * PI) + 300 * Math.sin(x / 30 * PI)) * 2 / 3;
}
function wgsToGcj(lon, lat) {
  if (outsideChina(lon, lat)) return [lon, lat];
  var dLat = transformLat(lon - 105, lat - 35), dLon = transformLon(lon - 105, lat - 35);
  var radLat = lat / 180 * PI, magic = 1 - EE * Math.sin(radLat) * Math.sin(radLat);
  var sqrtMagic = Math.sqrt(magic);
  dLat = dLat * 180 / ((AXIS * (1 - EE)) / (magic * sqrtMagic) * PI);
  dLon = dLon * 180 / (AXIS / sqrtMagic * Math.cos(radLat) * PI);
  return [lon + dLon, lat + dLat];
}
function gcjToBd(lon, lat) {
  var z = Math.sqrt(lon * lon + lat * lat) + .00002 * Math.sin(lat * Math.PI * 3000 / 180);
  var theta = Math.atan2(lat, lon) + .000003 * Math.cos(lon * Math.PI * 3000 / 180);
  return [z * Math.cos(theta) + .0065, z * Math.sin(theta) + .006];
}
function bdToGcj(lon, lat) {
  var x = lon - .0065, y = lat - .006;
  var z = Math.sqrt(x * x + y * y) - .00002 * Math.sin(y * Math.PI * 3000 / 180);
  var theta = Math.atan2(y, x) - .000003 * Math.cos(x * Math.PI * 3000 / 180);
  return [z * Math.cos(theta), z * Math.sin(theta)];
}
function wgsToBd(lon, lat) { return gcjToBd.apply(null, wgsToGcj(lon, lat)); }
function bdToWgs(lon, lat) {
  var target = bdToGcj(lon, lat), guess = target.slice();
  for (var i = 0; i < 3; i++) {
    var converted = wgsToGcj(guess[0], guess[1]);
    guess = [guess[0] - (converted[0] - target[0]), guess[1] - (converted[1] - target[1])];
  }
  return guess;
}
function pointWgs(coordinate) {
  var point = wgsToBd(Number(coordinate[0]), Number(coordinate[1]));
  return new BMapGL.Point(point[0], point[1]);
}
function eventPoint(event) { return event && (event.latlng || event.point); }

async function loadBaiduMap(ak) {
  if (window.BMapGL) return;
  if (!ak) throw new Error('未设置 BAIDU_MAP_AK，请编辑 .env 后重启程序');
  await new Promise(function (resolve, reject) {
    var callback = 'baiduEditorReady_' + Date.now();
    window[callback] = function () { delete window[callback]; resolve(); };
    var script = document.createElement('script');
    script.src = 'https://api.map.baidu.com/api?v=1.0&type=webgl&ak=' + encodeURIComponent(ak) + '&callback=' + callback;
    script.onerror = function () { reject(new Error('百度地图脚本加载失败，请检查网络和AK')); };
    document.head.appendChild(script);
  });
}

function initMap() {
  editorState.map = new BMapGL.Map('editorMap');
  try { editorState.map.setDisplayOptions({ building: false }); } catch (e) {}   // 关闭3D建筑，避免遮挡六边形
  editorState.map.enableScrollWheelZoom(true);
  editorState.map.enableDragging(true);
  editorState.map.addControl(new BMapGL.NavigationControl3D());
  editorState.map.addEventListener('mousemove', function (event) {
    var point = eventPoint(event);
    if (!point) return;
    var wgs = bdToWgs(point.lng, point.lat);
    $('#editorMouseCoord').textContent = '经度 ' + wgs[0].toFixed(7) + '　纬度 ' + wgs[1].toFixed(7);
  });
  editorState.map.addEventListener('click', mapClick);
}

// ========== 六边形网格（严格对齐）==========
// 以已有带 q/r 的六边形为锚点，用与离线建图相同的轴向六边形公式生成网格单元。
var GRID_R = 6371000;

function gridAnchor() {
  var w = editorState.working;
  var nodeMap = new Map((w.road_graph.nodes || []).map(function (node) { return [String(node.id), node]; }));
  var anchor = null;
  (w.hex_grid.features || []).forEach(function (feature) {
    if (anchor) return;
    var props = feature.properties || {};
    if (props.q != null && props.r != null) {
      var node = nodeMap.get(String(props.hex_id));
      if (node) anchor = { q: Number(props.q), r: Number(props.r), lng: Number(node.longitude), lat: Number(node.latitude) };
    }
  });
  if (!anchor) {
    var center = w.manifest.center || [0, 0];
    anchor = { q: 0, r: 0, lng: Number(center[0]), lat: Number(center[1]) };
  }
  anchor.size = Number((w.manifest.build_parameters || {}).hex_size_m || 10);
  return anchor;
}

function gridToXY(anchor, lng, lat) {
  var x = (lng - anchor.lng) * Math.PI / 180 * GRID_R * Math.cos(anchor.lat * Math.PI / 180);
  var y = (lat - anchor.lat) * Math.PI / 180 * GRID_R;
  return [x, y];
}

function gridFromXY(anchor, x, y) {
  var lng = anchor.lng + x / (GRID_R * Math.cos(anchor.lat * Math.PI / 180)) * 180 / Math.PI;
  var lat = anchor.lat + y / GRID_R * 180 / Math.PI;
  return [lng, lat];
}

function gridXYToHex(anchor, x, y) {
  var size = anchor.size;
  var q = (Math.sqrt(3) / 3 * x - y / 3) / size;
  var r = (2 * y / 3) / size;
  var rx = Math.round(q), rz = Math.round(r);
  var ry = -rx - rz;
  var dq = Math.abs(rx - q), dr = Math.abs(rz - r), dy = Math.abs(ry - (-q - r));
  if (dq > dy && dq > dr) rx = -ry - rz;
  else if (dy > dr) ry = -rx - rz;
  else rz = -rx - ry;
  return [rx + anchor.q, rz + anchor.r];
}

function gridHexCenter(anchor, q, r) {
  var relativeQ = q - anchor.q, relativeR = r - anchor.r;
  return [anchor.size * Math.sqrt(3) * (relativeQ + relativeR / 2), anchor.size * 1.5 * relativeR];
}

function gridHexVertices(anchor, q, r) {
  var center = gridHexCenter(anchor, q, r);
  var ring = [];
  for (var i = 0; i < 6; i++) {
    var angle = (60 * i - 30) * Math.PI / 180;
    var point = gridFromXY(anchor, center[0] + anchor.size * Math.cos(angle), center[1] + anchor.size * Math.sin(angle));
    ring.push([Number(point[0].toFixed(8)), Number(point[1].toFixed(8))]);
  }
  ring.push(ring[0].slice());
  return ring;
}

// ========== 统一操作应用（供保存/取消回滚重放）==========
function hexFeatureById(working, hexId) {
  return (working.hex_grid.features || []).find(function (feature) {
    return String((feature.properties || {}).hex_id) === hexId;
  });
}

function hexCenterOf(feature) {
  var ring = ((feature.geometry || {}).coordinates || [[]])[0];
  var lng = 0, lat = 0, count = Math.min(6, ring.length);
  for (var i = 0; i < count; i++) { lng += ring[i][0]; lat += ring[i][1]; }
  return [lng / count, lat / count];
}

function axialNeighborIds(working, q, r) {
  var offsets = [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]];
  var byCoordinate = new Map();
  (working.hex_grid.features || []).forEach(function (feature) {
    var props = feature.properties || {};
    if (props.q != null && props.r != null) byCoordinate.set(Number(props.q) + ',' + Number(props.r), String(props.hex_id));
  });
  return offsets.map(function (offset) {
    return byCoordinate.get((Number(q) + offset[0]) + ',' + (Number(r) + offset[1]));
  }).filter(Boolean);
}

function applyOperation(working, operation) {
  var kind = operation.op;
  if (kind === 'add_hex') {
    var neighborIds = axialNeighborIds(working, operation.q, operation.r);
    var properties = { hex_id: operation.hex_id, observations: 0, manual: true, type: 'road' };
    if (operation.q != null) properties.q = operation.q;
    if (operation.r != null) properties.r = operation.r;
    working.hex_grid.features.push({
      type: 'Feature',
      geometry: { type: 'Polygon', coordinates: [operation.vertices.map(function (p) { return [p[0], p[1]]; })] },
      properties: properties,
    });
    var center = operation.center || operation.vertices.slice(0, 6).reduce(function (sum, p) { return [sum[0] + p[0], sum[1] + p[1]]; }, [0, 0]).map(function (v) { return v / 6; });
    working.road_graph.nodes.push({ id: operation.hex_id, longitude: center[0], latitude: center[1], observations: 0, manual: true });
    var nodeMap = new Map(working.road_graph.nodes.map(function (node) { return [String(node.id), node]; }));
    neighborIds.forEach(function (neighborId) {
      var first = nodeMap.get(operation.hex_id), second = nodeMap.get(neighborId);
      if (!first || !second) return;
      working.road_graph.edges.push({
        from: operation.hex_id, to: neighborId,
        distance_m: Number(approximateDistance(first.longitude, first.latitude, second.longitude, second.latitude).toFixed(2)),
        traversals: 0, manual: true,
      });
    });
  } else if (kind === 'set_hex') {
    var feature = hexFeatureById(working, operation.hex_id);
    if (!feature) return;
    var props = feature.properties;
    var type = operation.type || null;
    ['type', 'node_id', 'servers', 'max_queue', 'average_time_min', 'priority', 'status'].forEach(function (key) { delete props[key]; });
    if (type) {
      props.type = type;
      if (type !== 'road') {
        props.node_id = operation.node_id || (type + '_' + String(props.hex_id || ''));
        if (operation.params) {
          var params = operation.params;
          if (params.servers != null) props.servers = Number(params.servers);
          if (params.max_queue != null) props.max_queue = Number(params.max_queue);
          if (params.average_time_min != null) props.average_time_min = Number(params.average_time_min);
          if (params.priority != null) props.priority = Number(params.priority);
          if (params.status != null) props.status = params.status;
        }
      }
    }
  } else if (kind === 'delete_hex') {
    var id = operation.hex_id;
    working.hex_grid.features = working.hex_grid.features.filter(function (f) { return String((f.properties || {}).hex_id) !== id; });
    working.road_graph.nodes = working.road_graph.nodes.filter(function (n) { return String(n.id) !== id; });
    working.road_graph.edges = working.road_graph.edges.filter(function (e) { return String(e.from) !== id && String(e.to) !== id; });
  } else if (kind === 'connect_hexes' || kind === 'disconnect_hexes') {
    var a = operation.from, b = operation.to;
    var exists = working.road_graph.edges.some(function (e) {
      return (String(e.from) === a && String(e.to) === b) || (String(e.from) === b && String(e.to) === a);
    });
    if (kind === 'connect_hexes' && !exists) {
      var nodeMap = new Map(working.road_graph.nodes.map(function (n) { return [String(n.id), n]; }));
      var first = nodeMap.get(a), second = nodeMap.get(b);
      working.road_graph.edges.push({
        from: a, to: b,
        distance_m: Number(approximateDistance(first.longitude, first.latitude, second.longitude, second.latitude).toFixed(2)),
        traversals: 0, manual: true,
      });
    } else if (kind === 'disconnect_hexes' && exists) {
      working.road_graph.edges = working.road_graph.edges.filter(function (e) {
        return !((String(e.from) === a && String(e.to) === b) || (String(e.from) === b && String(e.to) === a));
      });
    }
  } else if (kind === 'upsert_node') {
    var payload = operation.node;
    var key = payload.node_type + '/' + payload.node_id;
    var index = working.nodes.features.findIndex(function (f) {
      var p = f.properties || {};
      return ((p.node_type || p.type) + '/' + p.node_id) === key;
    });
    var feature = { type: 'Feature', geometry: { type: 'Point', coordinates: [payload.longitude, payload.latitude] }, properties: Object.assign({}, payload, { type: payload.node_type }) };
    if (index >= 0) working.nodes.features[index] = feature;
    else working.nodes.features.push(feature);
  } else if (kind === 'delete_node') {
    working.nodes.features = working.nodes.features.filter(function (f) {
      var p = f.properties || {};
      return !(((p.node_type || p.type)) === operation.node_type && p.node_id === operation.node_id);
    });
  } else if (kind === 'set_matrix') {
    working.matrix = clone(operation.matrix);
    working.matrix_row_node_ids = clone(operation.row_node_ids || []);
    working.matrix_column_node_ids = clone(operation.column_node_ids || []);
  }
}

// ========== 交互操作 ==========
function operationAddHex(hexId, q, r, vertices) {
  var center = vertices.slice(0, 6).reduce(function (sum, p) { return [sum[0] + p[0], sum[1] + p[1]]; }, [0, 0]).map(function (v) { return v / 6; });
  var operation = { op: 'add_hex', hex_id: hexId, q: q, r: r, vertices: vertices, center: center, section: 'paint' };
  applyOperation(editorState.working, operation);
  editorState.operations.push(operation);
}

function operationSetHex(hexId, type, nodeId, params) {
  var feature = hexFeatureById(editorState.working, hexId);
  if (!feature) return;
  var props = feature.properties || {};
  var nextType = type === 'erase' ? null : type;
  var resolvedNodeId = nodeId || props.node_id;
  if (nextType && nextType !== 'road' && !resolvedNodeId) {
    resolvedNodeId = nextType + '_' + String(props.hex_id || hexId).replace(/[^0-9]/g, '');
  }
  var operation = {
    op: 'set_hex', hex_id: hexId, type: nextType, node_id: resolvedNodeId || undefined,
    params: params || undefined, section: 'paint',
  };
  applyOperation(editorState.working, operation);
  editorState.operations.push(operation);
}

function operationDeleteHex(hexId) {
  applyOperation(editorState.working, { op: 'delete_hex', hex_id: hexId, section: 'paint' });
  editorState.operations.push({ op: 'delete_hex', hex_id: hexId, section: 'paint' });
}

// ========== 功能区设置弹窗 ==========
var modalHexId = null;

function nextNodeId(type, excludingHexId) {
  var used = new Set();
  typedHexes(type).forEach(function (feature) {
    var props = feature.properties || {};
    if (String(props.hex_id) !== String(excludingHexId) && props.node_id) used.add(String(props.node_id));
  });
  var counter = 1, candidate = '';
  do { candidate = type + '_' + String(counter++).padStart(3, '0'); } while (used.has(candidate));
  return candidate;
}

function openNodeModal(hexId, type) {
  var feature = hexFeatureById(editorState.working, hexId);
  if (!feature) return;
  var props = feature.properties || {};
  modalHexId = hexId;
  var form = $('#nodeModalForm');
  form.elements.node_type.value = type || 'loading';
  form.elements.node_id.value = props.type === type && props.node_id ? props.node_id : nextNodeId(type || 'loading', hexId);
  ['servers', 'max_queue', 'average_time_min', 'priority'].forEach(function (name) {
    form.elements[name].value = props.type === type && props[name] != null ? props[name] : DEFAULT_PARAMS[name];
  });
  form.elements.status.value = props.type === type ? (props.status || 'open') : 'open';
  $('#nodeModal').classList.remove('hidden');
  $('#nodeModalType').textContent = TYPE_NAMES[type || 'loading'];
}

function closeNodeModal() {
  // 取消弹窗时回收半成品：若该格是本次刚新增、尚未设成功能区的道路格，撤销它
  var pending = editorState.pendingNewHexId;
  if (pending && modalHexId === pending) {
    var feature = hexFeatureById(editorState.working, pending);
    if (feature && ((feature.properties || {}).type || 'road') === 'road') {
      editorState.operations = editorState.operations.filter(function (operation) {
        return !(operation.op === 'add_hex' && String(operation.hex_id) === String(pending));
      });
      rebuildWorking();
    }
  }
  editorState.pendingNewHexId = null;
  modalHexId = null;
  $('#nodeModal').classList.add('hidden');
}

function saveNodeModal(event) {
  event.preventDefault();
  if (!modalHexId) return;
  var form = $('#nodeModalForm');
  var type = form.elements.node_type.value;
  var nodeId = form.elements.node_id.value.trim();
  if (!nodeId) { toast('节点ID不能为空'); return; }
  if (!/^[A-Za-z0-9_-]{1,64}$/.test(nodeId)) { toast('节点ID只能包含字母、数字、下划线和短横线'); return; }
  var duplicate = typedHexes(type).some(function (feature) {
    var props = feature.properties || {};
    return String(props.hex_id) !== String(modalHexId) && String(props.node_id) === nodeId;
  });
  if (duplicate) { toast('节点ID ' + nodeId + ' 已被使用'); return; }
  var params = {
    servers: Number(form.elements.servers.value) || 0,
    max_queue: Number(form.elements.max_queue.value) || 0,
    average_time_min: Number(form.elements.average_time_min.value) || 0,
    priority: Number(form.elements.priority.value) || 1,
    status: form.elements.status.value,
  };
  operationSetHex(modalHexId, type, nodeId, params);
  closeNodeModal();
  redrawAll();
  toast('功能区参数已保存（待提交）');
}

// 点击已有六边形：用 hex_id 直接定位（不从顶点坐标反算，避免边界漂移）
function paintHex(hexId) {
  var existing = hexFeatureById(editorState.working, hexId);
  if (!existing) return;
  var paintType = editorState.paintType;
  if (paintType === 'delete') {
    operationDeleteHex(hexId);
    toast('已删除 ' + hexId + '（顶部保存前可撤销）');
    redrawAll();
    return;
  }
  if (paintType === 'road') {
    operationSetHex(hexId, 'road', null, null);
    toast('已设置 ' + hexId + ' 为道路');
    redrawAll();
    return;
  }
  // 功能区只有在弹窗确认后才写入，取消弹窗不会留下半成品节点。
  openNodeModal(hexId, paintType);
}

// 点击地图空白：只允许点透明的候选六边形，保证新增格子紧邻现有路网
function paintAt(lng, lat) {
  var anchor = gridAnchor();
  var xy = gridToXY(anchor, lng, lat);
  var qr = gridXYToHex(anchor, xy[0], xy[1]);
  var hexId = 'h_' + qr[0] + '_' + qr[1];
  if (hexFeatureById(editorState.working, hexId)) { paintHex(hexId); return; }
  var candidate = editorState.candidates.get(hexId);
  if (candidate) { paintCandidate(hexId, candidate.q, candidate.r, candidate.hasRoad); return; }
  toast('只能点击透明六边形添加，新格子必须紧邻现有道路或功能区');
}

function mapClick(event) {
  if (Date.now() < editorState.overlayClickUntil) return;
  var point = eventPoint(event);
  if (!point) return;
  var wgs = bdToWgs(point.lng, point.lat);
  var longitude = Number(wgs[0].toFixed(8)), latitude = Number(wgs[1].toFixed(8));
  paintAt(longitude, latitude);
}

// ========== 绘制 ==========
function clearOverlays(list) {
  list.forEach(function (overlay) { editorState.map.removeOverlay(overlay); });
  list.length = 0;
}

function drawBoundary(collection) {
  clearOverlays(editorState.boundaryOverlays);
  (collection.features || []).forEach(function (feature) {
    var geometry = feature.geometry || {};
    var polygons = geometry.type === 'Polygon' ? [geometry.coordinates] : (geometry.coordinates || []);
    polygons.forEach(function (polygon) {
      var overlay = new BMapGL.Polygon(polygon[0].map(pointWgs), {
        strokeColor: '#cf3341', strokeWeight: 3, strokeOpacity: .8, fillColor: '#cf3341', fillOpacity: .025,
      });
      editorState.map.addOverlay(overlay);
      editorState.boundaryOverlays.push(overlay);
    });
  });
}

function hexStyle(feature) {
  var props = feature.properties || {};
  var type = props.type || 'road';
  var color = HEX_COLORS[type] || HEX_COLORS.road;
  return {
    strokeColor: '#333',
    strokeWeight: 1,
    strokeOpacity: .5,
    fillColor: color,
    fillOpacity: type === 'road' ? .28 : .55,
  };
}

function drawHexes() {
  editorState.hexOverlays.forEach(function (overlay) { editorState.map.removeOverlay(overlay); });
  editorState.hexOverlays.clear();
  clearOverlays(editorState.hexLabelOverlays);
  (editorState.working.hex_grid.features || []).forEach(function (feature) {
    var props = feature.properties || {};
    var id = String(props.hex_id || '');
    var type = props.type || 'road';
    var style = hexStyle(feature);
    var overlay = new BMapGL.Polygon(feature.geometry.coordinates[0].map(pointWgs), {
      strokeColor: style.strokeColor,
      strokeWeight: style.strokeWeight,
      strokeOpacity: style.strokeOpacity,
      fillColor: style.fillColor,
      fillOpacity: style.fillOpacity,
    });
    overlay.addEventListener('click', function (event) {
      editorState.overlayClickUntil = Date.now() + 250;
      if (event && event.domEvent && event.domEvent.stopPropagation) event.domEvent.stopPropagation();
      paintHex(id);
    });
    editorState.map.addOverlay(overlay);
    editorState.hexOverlays.set(id, overlay);
    if (type !== 'road') {
      var center = hexCenterOf(feature);
      var label = new BMapGL.Label(props.name || props.node_id || TYPE_NAMES[type] || '功能区', {
        position: pointWgs(center), offset: new BMapGL.Size(0, -6),
      });
      label.setStyle({
        color: '#fff', backgroundColor: 'rgba(0,0,0,0.6)', border: 'none',
        borderRadius: '3px', padding: '1px 5px', fontSize: '11px',
        whiteSpace: 'nowrap', pointerEvents: 'none',
      });
      editorState.map.addOverlay(label);
      editorState.hexLabelOverlays.push(label);
    }
  });
}

var AXIAL_OFFSETS = [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]];

// 候选格 = 紧邻现有道路/功能区的空格；点它新增，保证新格与现有路网相连
function buildCandidates() {
  var byCoord = new Map();
  (editorState.working.hex_grid.features || []).forEach(function (feature) {
    var props = feature.properties || {};
    if (props.q == null || props.r == null) return;
    byCoord.set(Number(props.q) + ',' + Number(props.r), feature);
  });
  var candidates = new Map();
  byCoord.forEach(function (feature, key) {
    var parts = key.split(',');
    var q = Number(parts[0]), r = Number(parts[1]);
    AXIAL_OFFSETS.forEach(function (offset) {
      var nq = q + offset[0], nr = r + offset[1];
      if (byCoord.has(nq + ',' + nr)) return;
      var hexId = 'h_' + nq + '_' + nr;
      var hasRoad = AXIAL_OFFSETS.some(function (probe) {
        var neighbor = byCoord.get((nq + probe[0]) + ',' + (nr + probe[1]));
        return neighbor && ((neighbor.properties || {}).type || 'road') === 'road';
      });
      var known = candidates.get(hexId);
      if (!known || (!known.hasRoad && hasRoad)) candidates.set(hexId, { q: nq, r: nr, hasRoad: hasRoad });
    });
  });
  return candidates;
}

function drawCandidates() {
  clearOverlays(editorState.candidateOverlays);
  editorState.candidates = buildCandidates();
  var anchor = gridAnchor();
  editorState.candidates.forEach(function (candidate, hexId) {
    var overlay = new BMapGL.Polygon(gridHexVertices(anchor, candidate.q, candidate.r).map(pointWgs), {
      strokeColor: '#8c8c8c', strokeWeight: 1, strokeOpacity: .6,
      fillColor: '#5b9bd5', fillOpacity: .06,
    });
    overlay.addEventListener('click', function (event) {
      editorState.overlayClickUntil = Date.now() + 250;
      if (event && event.domEvent && event.domEvent.stopPropagation) event.domEvent.stopPropagation();
      paintCandidate(hexId, candidate.q, candidate.r, candidate.hasRoad);
    });
    editorState.map.addOverlay(overlay);
    editorState.candidateOverlays.push(overlay);
  });
}

function paintCandidate(hexId, q, r, hasRoad) {
  var paintType = editorState.paintType;
  if (paintType === 'delete') { toast('该位置还没有六边形'); return; }
  if (paintType !== 'road' && !hasRoad) { toast('功能区必须紧邻道路，请先在此处铺设道路'); return; }
  var vertices = gridHexVertices(gridAnchor(), q, r);
  operationAddHex(hexId, q, r, vertices);
  if (paintType === 'road') {
    toast('已新增道路 ' + hexId);
  } else {
    editorState.pendingNewHexId = hexId;
    openNodeModal(hexId, paintType);
  }
  redrawAll();
}

function redrawAll() {
  drawCandidates();
  drawHexes();
  refreshMatrixSize();
  markDirty();
}

// ========== 功能区类型统计 ==========
function typedHexes(type) {
  return (editorState.working.hex_grid.features || []).filter(function (feature) {
    return (feature.properties || {}).type === type;
  });
}

// ========== 装卸匹配矩阵（行=装货点ID，列=卸货点ID）==========
function typedNodeIds(type) {
  return typedHexes(type).map(function (feature) {
    return String((feature.properties || {}).node_id || '');
  }).filter(Boolean).sort();
}

function matrixForNodes(rowIds, columnIds) {
  var oldMatrix = editorState.working.matrix || [];
  var oldRows = editorState.working.matrix_row_node_ids || [];
  var oldColumns = editorState.working.matrix_column_node_ids || [];
  var hasLabels = oldRows.length > 0 || oldColumns.length > 0;
  return rowIds.map(function (rowId, rowIndex) {
    return columnIds.map(function (columnId, columnIndex) {
      var oldRowIndex = hasLabels ? oldRows.indexOf(rowId) : rowIndex;
      var oldColumnIndex = hasLabels ? oldColumns.indexOf(columnId) : columnIndex;
      return oldRowIndex >= 0 && oldColumnIndex >= 0 && (oldMatrix[oldRowIndex] || [])[oldColumnIndex] === 1 ? 1 : 0;
    });
  });
}

// 弹窗草稿与 working 分离，取消不会影响已应用的修改。
var matrixDraft = null;

function matrixCount(matrix) {
  return matrix.reduce(function (total, row) {
    return total + row.reduce(function (sum, value) { return sum + value; }, 0);
  }, 0);
}

function refreshMatrixSize() {
  if (!editorState.working) return;
  var rowIds = typedNodeIds('loading'), columnIds = typedNodeIds('unloading');
  var available = rowIds.length > 0 && columnIds.length > 0;
  $('#matrixSource').textContent = rowIds.length + ' 个装货区 × ' + columnIds.length + ' 个卸货区';
  var staged = editorState.operations.some(function (op) { return op.section === 'matrix'; });
  $('#matrixPreview').textContent = available
    ? '已匹配 ' + matrixCount(matrixForNodes(rowIds, columnIds)) + ' 组装卸关系' + (staged ? ' · 待保存' : '')
    : '请先设置至少一个装货区和一个卸货区';
  $('#openMatrix').disabled = !available;
  $('#discardMatrix').disabled = !staged;
}

function matrixNodeLabels(type, ids) {
  var names = new Map();
  (editorState.working.nodes.features || []).forEach(function (feature) {
    var p = feature.properties || {};
    if ((p.node_type || p.type) === type && p.name) names.set(String(p.node_id), p.name);
  });
  typedHexes(type).forEach(function (feature) {
    var p = feature.properties || {};
    if (p.name) names.set(String(p.node_id), p.name);
  });
  return ids.map(function (id) { return { id: id, name: String(names.get(id) || id) }; });
}

function openMatrix() {
  if (!editorState.working) return;
  var rows = typedNodeIds('loading'), columns = typedNodeIds('unloading');
  if (!rows.length || !columns.length) return;
  var values = matrixForNodes(rows, columns);
  matrixDraft = {
    rows: rows, columns: columns, values: values, initial: clone(values), history: [],
    rowLabels: matrixNodeLabels('loading', rows), columnLabels: matrixNodeLabels('unloading', columns),
  };
  renderMatrix();
  $('#matrixModal').showModal();
  $('#editorMatrix').focus();
}

function closeMatrix() {
  $('#matrixModal').close();
  matrixDraft = null;
  $('#openMatrix').focus();
}

function matrixLabel(node) {
  return '<span class="matrix-node-name">' + escapeHtml(node.name) + '</span>' +
    (node.name !== node.id ? '<small>' + escapeHtml(node.id) + '</small>' : '');
}

function matrixBulkButtons(axis, index) {
  return '<div class="matrix-bulk"><button type="button" data-bulk-axis="' + axis + '" data-bulk-index="' + index + '" data-value="1">全部匹配</button>' +
    '<button type="button" data-bulk-axis="' + axis + '" data-bulk-index="' + index + '" data-value="0">全部取消</button></div>';
}

function renderMatrix() {
  if (!matrixDraft) return;
  var d = matrixDraft;
  var rowIndexes = d.rows.map(function (_, i) { return i; });
  var columnIndexes = d.columns.map(function (_, i) { return i; });
  var html = '<table class="matrix-table"><caption class="matrix-sr-only">装货点与卸货点的匹配关系</caption><thead><tr>' +
      '<th class="matrix-axis" scope="col" aria-label="行是装货点，列是卸货点">' +
      '<span class="matrix-axis-column">卸货点</span><span class="matrix-axis-row">装货点</span></th>';
    columnIndexes.forEach(function (c) {
      html += '<th scope="col" data-column="' + c + '">' + matrixLabel(d.columnLabels[c]) + matrixBulkButtons('column', c) + '</th>';
    });
    html += '</tr></thead><tbody>';
    rowIndexes.forEach(function (r) {
      html += '<tr><th scope="row" data-row="' + r + '">' + matrixLabel(d.rowLabels[r]) + matrixBulkButtons('row', r) + '</th>';
      columnIndexes.forEach(function (c) {
        var on = d.values[r][c] === 1;
        var label = d.rowLabels[r].name + ' 与 ' + d.columnLabels[c].name + '：' + (on ? '已匹配' : '未匹配');
        html += '<td data-row="' + r + '" data-column="' + c + '"><button type="button" class="matrix-cell' + (on ? ' allowed' : '') + '" data-matrix-row="' + r + '" data-matrix-column="' + c + '" aria-pressed="' + on + '" aria-label="' + escapeHtml(label) + '" title="' + escapeHtml(label) + '"><span aria-hidden="true">' + (on ? '✓' : '—') + '</span></button></td>';
      });
      html += '</tr>';
    });
  $('#editorMatrix').innerHTML = html + '</tbody></table>';
  updateMatrixPreview();
}

function updateMatrixPreview() {
  if (!matrixDraft) return;
  var changed = 0;
  matrixDraft.values.forEach(function (row, r) { row.forEach(function (value, c) {
    if (value !== matrixDraft.initial[r][c]) changed++;
  }); });
  $('#matrixUndo').disabled = !matrixDraft.history.length;
  $('#stageMatrix').disabled = changed === 0;
}

function changeMatrix(cells, value) {
  var changes = cells.filter(function (cell) { return matrixDraft.values[cell[0]][cell[1]] !== value; }).map(function (cell) {
    return { row: cell[0], column: cell[1], previous: matrixDraft.values[cell[0]][cell[1]] };
  });
  if (!changes.length) return;
  matrixDraft.history.push(changes);
  changes.forEach(function (cell) { matrixDraft.values[cell.row][cell.column] = value; });
  renderMatrix();
}

function undoMatrix() {
  if (!matrixDraft || !matrixDraft.history.length) return;
  matrixDraft.history.pop().forEach(function (cell) { matrixDraft.values[cell.row][cell.column] = cell.previous; });
  renderMatrix();
}

function highlightMatrix(target) {
  $$('#editorMatrix .matrix-highlight').forEach(function (el) { el.classList.remove('matrix-highlight'); });
  if (!target) return;
  var cell = target.closest('[data-row], [data-column]');
  if (!cell) return;
  $$('#editorMatrix [data-row], #editorMatrix [data-column]').forEach(function (el) {
    if ((cell.dataset.row !== undefined && cell.dataset.row === el.dataset.row) ||
        (cell.dataset.column !== undefined && cell.dataset.column === el.dataset.column)) el.classList.add('matrix-highlight');
  });
}

function stageMatrix() {
  if (!matrixDraft || $('#stageMatrix').disabled) return;
  var operation = { op: 'set_matrix', matrix: clone(matrixDraft.values), row_node_ids: matrixDraft.rows.slice(), column_node_ids: matrixDraft.columns.slice(), section: 'matrix' };
  editorState.operations = editorState.operations.filter(function (op) { return op.section !== 'matrix'; });
  editorState.operations.push(operation);
  applyOperation(editorState.working, operation);
  closeMatrix();
  redrawAll();
  toast('矩阵已应用，请点击“保存到地图包”完成保存');
}

function discardMatrix() {
  var before = editorState.operations.length;
  editorState.operations = editorState.operations.filter(function (op) { return op.section !== 'matrix'; });
  if (editorState.operations.length === before) { toast('本部分没有待取消的修改'); return; }
  rebuildWorking();
  toast('已取消矩阵修改');
}

function discardPaint() {
  var before = editorState.operations.length;
  editorState.operations = editorState.operations.filter(function (op) { return op.section !== 'paint'; });
  if (editorState.operations.length === before) { toast('本部分没有待取消的修改'); return; }
  rebuildWorking();
  toast('已取消色块修改');
}

function rebuildWorking() {
  var working = clone(editorState.snapshot);
  editorState.operations.forEach(function (operation) { applyOperation(working, operation); });
  editorState.working = working;
  redrawAll();
}

// ========== 提交 ==========
function operationText(operation) {
  var labels = {
    add_hex: '新增对齐六边形 ', set_hex: '设置色块 ',
    delete_hex: '删除六边形 ', connect_hexes: '连接道路 ', disconnect_hexes: '断开道路 ',
    upsert_node: '新增/更新功能区 ', delete_node: '删除功能区 ', set_matrix: '更新装卸匹配矩阵',
  };
  if (operation.op === 'add_hex') return labels[operation.op] + operation.hex_id;
  if (operation.op === 'set_hex') return labels[operation.op] + operation.hex_id + (operation.type ? ' → ' + (TYPE_NAMES[operation.type] || operation.type) : ' → 空白');
  if (operation.op === 'delete_hex') return labels[operation.op] + operation.hex_id;
  if (operation.op === 'connect_hexes' || operation.op === 'disconnect_hexes') return labels[operation.op] + operation.from + ' ↔ ' + operation.to;
  if (operation.op === 'upsert_node') return labels[operation.op] + operation.node.node_type + '/' + operation.node.node_id;
  if (operation.op === 'delete_node') return labels[operation.op] + operation.node_type + '/' + operation.node_id;
  return labels[operation.op] || operation.op;
}

function markDirty() {
  var dirty = editorState.operations.length > 0;
  $('#saveState').textContent = dirty ? editorState.operations.length + ' 项未保存' : '修改已保存';
  $('#saveState').className = 'save-state ' + (dirty ? 'dirty' : 'clean');
  $('#commitSummary').innerHTML = dirty
    ? '<ol>' + editorState.operations.map(function (operation) { return '<li>' + escapeHtml(operationText(operation)) + '</li>'; }).join('') + '</ol>'
    : '当前没有待保存操作。';
  $('#commitDraft').disabled = !dirty;
  $('#discardDraft').disabled = !dirty;
}

function discardDraft() {
  if (editorState.operations.length && !window.confirm('放弃全部未保存修改？')) return;
  editorState.operations = [];
  rebuildWorking();
  toast('已恢复到最近一次保存的版本');
}

async function commitDraft() {
  if (!editorState.operations.length) return;
  if (!window.confirm('确认校验并保存这 ' + editorState.operations.length + ' 项修改？')) return;
  var button = $('#commitDraft');
  button.disabled = true;
  $('#commitResult').textContent = '正在校验并保存...';
  try {
    var payload = [];
    editorState.operations.forEach(function (operation) {
      if (operation.op === 'upsert_node' || operation.op === 'delete_node' || operation.op === 'set_matrix') {
        payload.push({
          op: operation.op, node: operation.node, node_type: operation.node_type, node_id: operation.node_id,
          matrix: operation.matrix, row_node_ids: operation.row_node_ids, column_node_ids: operation.column_node_ids,
        });
      } else {
        payload.push({ op: operation.op, hex_id: operation.hex_id, q: operation.q, r: operation.r, vertices: operation.vertices, type: operation.type, node_id: operation.node_id, params: operation.params, from: operation.from, to: operation.to });
      }
    });
    var result = await api('/api/maps/' + encodeURIComponent(editorState.mapId) + '/editor/commit', {
      method: 'POST',
      body: JSON.stringify({
        revision: editorState.snapshot.revision,
        operations: payload,
        note: $('#editNote').value,
        publish_mqtt: $('#publishMqtt').checked,
      }),
    });
    editorState.snapshot = result;
    editorState.operations = [];
    $('#editNote').value = '';
    rebuildWorking();
    var message = '保存成功';
    if (result.published_topics && result.published_topics.length) message += '\n已发布：' + result.published_topics.join(', ');
    if (result.warnings && result.warnings.length) message += '\n警告：' + result.warnings.join('；');
    $('#commitResult').textContent = message;
    toast('地图保存成功');
    $('#commitModal').classList.add('hidden');
  } catch (error) {
    $('#commitResult').textContent = error.message;
    toast(error.message);
    if (error.code === 'revision_conflict') $('#commitResult').textContent += '\n请刷新页面获取最新地图。';
  } finally {
    button.disabled = editorState.operations.length === 0;
  }
}

function approximateDistance(lon1, lat1, lon2, lat2) {
  var p1 = lat1 * Math.PI / 180, p2 = lat2 * Math.PI / 180;
  var dp = (lat2 - lat1) * Math.PI / 180, dl = (lon2 - lon1) * Math.PI / 180;
  var a = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0, 1 - a)));
}

// ========== 页面切换 ==========
function switchEditorPage(id) {
  $$('.editor-tab').forEach(function (tab) { tab.classList.toggle('active', tab.dataset.editorPage === id); });
  $$('.editor-page').forEach(function (page) { page.classList.toggle('active', page.id === id); });
  if (id === 'matrixEditorPage') refreshMatrixSize();
}

// ========== 加载 ==========
async function loadEditor(mapId) {
  editorState.mapId = mapId;
  showMessage('');
  try {
    var payloads = await Promise.all([
      api('/api/maps/' + encodeURIComponent(mapId) + '/editor'),
      api('/api/maps/' + encodeURIComponent(mapId) + '/layers/boundary'),
    ]);
    editorState.snapshot = payloads[0];
    editorState.working = clone(payloads[0]);
    $('#editorMineName').textContent = editorState.snapshot.manifest.name || mapId;
    editorState.map.centerAndZoom(pointWgs(editorState.snapshot.manifest.center), Number(editorState.snapshot.manifest.suggested_zoom || 17));
    drawBoundary(payloads[1]);
    redrawAll();
  } catch (error) {
    showMessage(error.message);
    toast(error.message);
  }
}

function setupEvents() {
  $('#editorMenuBtn').addEventListener('click', function (event) {
    event.stopPropagation();
    var open = $('#editorMenuDropdown').classList.toggle('show');
    this.setAttribute('aria-expanded', String(open));
  });
  document.addEventListener('click', function () {
    $('#editorMenuDropdown').classList.remove('show');
    $('#editorMenuBtn').setAttribute('aria-expanded', 'false');
  });
  $('#editorMenuHome').addEventListener('click', function () { window.location.href = '/'; });
  $('#editorMenuMap').addEventListener('click', function () {
    window.location.href = '/map.html?map=' + encodeURIComponent(editorState.mapId || '');
  });
  $('#editorMenuEditor').addEventListener('click', function () {
    $('#editorMenuDropdown').classList.remove('show');
    $('#editorMenuBtn').setAttribute('aria-expanded', 'false');
  });
  $$('.editor-tab').forEach(function (tab) {
    tab.addEventListener('click', function () { switchEditorPage(tab.dataset.editorPage); });
  });
  $('#editorMapSelect').addEventListener('change', function () {
    if (editorState.operations.length && !window.confirm('切换地图会放弃未保存修改，是否继续？')) {
      this.value = editorState.mapId;
      return;
    }
    window.location.href = 'editor.html?map=' + encodeURIComponent(this.value);
  });
  $$('.palette-swatch').forEach(function (swatch) {
    swatch.addEventListener('click', function () {
      $$('.palette-swatch').forEach(function (s) { s.classList.remove('active'); });
      swatch.classList.add('active');
      editorState.paintType = swatch.dataset.paintType;
    });
  });
  $('#discardPaint').addEventListener('click', discardPaint);
  $('#openMatrix').addEventListener('click', openMatrix);
  $('#closeMatrix').addEventListener('click', closeMatrix);
  $('#cancelMatrix').addEventListener('click', closeMatrix);
  $('#matrixModal').addEventListener('cancel', function (event) { event.preventDefault(); closeMatrix(); });
  $('#matrixUndo').addEventListener('click', undoMatrix);
  $('#editorMatrix').addEventListener('click', function (event) {
    if (!matrixDraft) return;
    var button = event.target.closest('button');
    if (!button) return;
    var selector;
    if (button.dataset.matrixRow !== undefined) {
      var r = Number(button.dataset.matrixRow), c = Number(button.dataset.matrixColumn);
      selector = '[data-matrix-row="' + r + '"][data-matrix-column="' + c + '"]';
      changeMatrix([[r, c]], matrixDraft.values[r][c] ? 0 : 1);
    } else if (button.dataset.bulkAxis) {
      var axis = button.dataset.bulkAxis, index = Number(button.dataset.bulkIndex), value = Number(button.dataset.value);
      var cells = axis === 'row'
        ? matrixDraft.columns.map(function (_, c) { return [index, c]; })
        : matrixDraft.rows.map(function (_, r) { return [r, index]; });
      selector = '[data-bulk-axis="' + axis + '"][data-bulk-index="' + index + '"][data-value="' + value + '"]';
      changeMatrix(cells, value);
    }
    if (selector) { var next = $('#editorMatrix ' + selector); if (next) next.focus({ preventScroll: true }); }
  });
  $('#editorMatrix').addEventListener('mouseover', function (event) { highlightMatrix(event.target); });
  $('#editorMatrix').addEventListener('focusin', function (event) { highlightMatrix(event.target); });
  $('#editorMatrix').addEventListener('mouseleave', function () { highlightMatrix(null); });
  $('#stageMatrix').addEventListener('click', stageMatrix);
  $('#discardMatrix').addEventListener('click', discardMatrix);
  $('#saveTop').addEventListener('click', function () {
    if (!editorState.operations.length) { toast('没有待保存的修改'); return; }
    $('#commitResult').textContent = '';
    $('#commitModal').classList.remove('hidden');
  });
  $('#discardDraft').addEventListener('click', function () {
    discardDraft();
    $('#commitModal').classList.add('hidden');
  });
  $('#commitDraft').addEventListener('click', commitDraft);
  $('#commitModal').addEventListener('click', function (event) {
    if (event.target === this) $('#commitModal').classList.add('hidden');
  });
  $('#nodeModalForm').addEventListener('submit', saveNodeModal);
  $('#nodeModalCancel').addEventListener('click', closeNodeModal);
  $('#nodeModal').addEventListener('click', function (event) {
    if (event.target === this) closeNodeModal();
  });
  window.addEventListener('beforeunload', function (event) {
    if (!editorState.operations.length && (!matrixDraft || JSON.stringify(matrixDraft.values) === JSON.stringify(matrixDraft.initial))) return;
    event.preventDefault();
    event.returnValue = '';
  });
}

async function init() {
  setupEvents();
  try {
    var payloads = await Promise.all([api('/api/config'), api('/api/maps')]);
    editorState.config = payloads[0];
    editorState.maps = (payloads[1].maps || []).filter(function (item) { return item.valid; });
    if (!editorState.maps.length) throw new Error('没有通过校验的地图包');
    var params = new URLSearchParams(window.location.search), preferred = params.get('map');
    if (!editorState.maps.some(function (item) { return item.map_id === preferred; })) {
      preferred = editorState.maps.some(function (item) { return item.map_id === editorState.config.active_map_id; })
        ? editorState.config.active_map_id : editorState.maps[0].map_id;
    }
    $('#editorMapSelect').innerHTML = editorState.maps.map(function (item) {
      return '<option value="' + escapeHtml(item.map_id) + '">' + escapeHtml(item.name) + '</option>';
    }).join('');
    $('#editorMapSelect').value = preferred;
    $('#publishMqtt').checked = !!editorState.config.mqtt_enabled;
    await loadBaiduMap(editorState.config.baidu_map_ak);
    initMap();
    await loadEditor(preferred);
  } catch (error) {
    showMessage(error.message);
    toast(error.message);
  }
}

window.addEventListener('DOMContentLoaded', init);
