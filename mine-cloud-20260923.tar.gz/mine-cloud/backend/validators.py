from __future__ import annotations

import math
import re
from typing import Any

from tools.common import utc_iso

NODE_TYPES = {"loading", "unloading", "charging"}
MATRIX_SEMANTICS = "loading_unloading_match"


def number(value: Any, name: str, minimum: float | None = None, maximum: float | None = None) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} 必须是数字")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} 必须是数字") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} 必须是有限数字")
    if minimum is not None and result < minimum:
        raise ValueError(f"{name} 不能小于 {minimum}")
    if maximum is not None and result > maximum:
        raise ValueError(f"{name} 不能大于 {maximum}")
    return result


def integer(value: Any, name: str, minimum: int = 0) -> int:
    result = number(value, name, minimum=minimum)
    if not result.is_integer():
        raise ValueError(f"{name} 必须是整数")
    return int(result)


def identifier(value: Any, name: str) -> str:
    result = str(value or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", result):
        raise ValueError(f"{name} 只能包含字母、数字、下划线和短横线，长度 1～64")
    return result


def validate_node(body: dict[str, Any]) -> dict[str, Any]:
    node_type = str(body.get("node_type", "")).strip()
    if node_type not in NODE_TYPES:
        raise ValueError("node_type 必须是 loading、unloading 或 charging")
    status = str(body.get("status", "")).strip().lower()
    if status not in {"open", "closed"}:
        raise ValueError("status 必须是 open 或 closed")
    return {
        "mine_id": identifier(body.get("mine_id"), "mine_id"),
        "node_type": node_type,
        "node_id": identifier(body.get("node_id"), "node_id"),
        "longitude": number(body.get("longitude"), "longitude", -180, 180),
        "latitude": number(body.get("latitude"), "latitude", -90, 90),
        "altitude": number(body.get("altitude", 0), "altitude"),
        "servers": integer(body.get("servers", 0), "servers"),
        "max_queue": integer(body.get("max_queue", 0), "max_queue"),
        "average_time_min": number(body.get("average_time_min", 0), "average_time_min", 0),
        "priority": integer(body.get("priority", 1), "priority", 1),
        "status": status,
        "timestamp": utc_iso(),
    }


def validate_matrix(body: dict[str, Any]) -> dict[str, Any]:
    matrix = body.get("matrix")
    has_rows = "row_node_ids" in body
    has_columns = "column_node_ids" in body
    if has_rows != has_columns:
        raise ValueError("row_node_ids 和 column_node_ids 必须同时提供")
    row_node_ids: list[str] | None = None
    column_node_ids: list[str] | None = None
    if has_rows:
        raw_rows, raw_columns = body.get("row_node_ids"), body.get("column_node_ids")
        if not isinstance(raw_rows, list) or not isinstance(raw_columns, list):
            raise ValueError("row_node_ids 和 column_node_ids 必须是数组")
        row_node_ids = [identifier(value, "row_node_ids") for value in raw_rows]
        column_node_ids = [identifier(value, "column_node_ids") for value in raw_columns]
        if len(set(row_node_ids)) != len(row_node_ids) or len(set(column_node_ids)) != len(column_node_ids):
            raise ValueError("矩阵行列节点 ID 不能重复")
    if not isinstance(matrix, list) or (not has_rows and not matrix):
        raise ValueError("matrix 必须是二维数组")
    if row_node_ids is not None and len(matrix) != len(row_node_ids):
        raise ValueError("matrix 行数必须等于 row_node_ids 数量")
    normalized = []
    column_count: int | None = len(column_node_ids) if column_node_ids is not None else None
    for row_index, row in enumerate(matrix):
        if not isinstance(row, list) or (column_node_ids is None and not row):
            raise ValueError(f"matrix 第 {row_index + 1} 行必须是数组")
        if column_count is None:
            column_count = len(row)
        if len(row) != column_count:
            raise ValueError(f"matrix 第 {row_index + 1} 行列数与第一行不一致")
        normalized_row = []
        for value in row:
            if value not in (0, 1, False, True):
                raise ValueError("matrix 中只能包含 0 或 1")
            normalized_row.append(int(value))
        normalized.append(normalized_row)
    result = {
        "mine_id": identifier(body.get("mine_id"), "mine_id"),
        "semantics": MATRIX_SEMANTICS,
        "matrix": normalized,
        "timestamp": utc_iso(),
    }
    if row_node_ids is not None and column_node_ids is not None:
        result["row_node_ids"] = row_node_ids
        result["column_node_ids"] = column_node_ids
    return result
