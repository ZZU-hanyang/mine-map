from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from psycopg import connect
from psycopg.types.json import Jsonb

from backend.postgres_store import REQUIRED_LAYERS, canonical_sha256
from tools.validate_map import validate_map_package


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_package(directory: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    directory = directory.resolve()
    errors = validate_map_package(directory)
    if errors:
        raise ValueError("地图包校验失败：" + "；".join(errors))
    manifest = read_json(directory / "manifest.json")
    files = manifest.get("files")
    if not isinstance(files, dict):
        raise ValueError("manifest.json 缺少 files 对象")
    layers: dict[str, Any] = {}
    for name in sorted(REQUIRED_LAYERS):
        relative = files.get(name)
        if not isinstance(relative, str) or not relative:
            raise ValueError(f"manifest.json 缺少 {name} 文件声明")
        path = (directory / relative).resolve()
        if directory not in path.parents:
            raise ValueError(f"{name} 文件路径越出地图包")
        layers[name] = read_json(path)
    return manifest, layers


def import_package(database_url: str, manifest: dict[str, Any], layers: dict[str, Any], replace: bool) -> None:
    map_id = str(manifest["map_id"])
    mine_id = str(manifest["mine_id"])
    revision = int(manifest.get("editor_revision", 0) or 0)
    hex_size_m = (manifest.get("build_parameters") or {}).get("hex_size_m")
    with connect(database_url) as conn:
        conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", (map_id,))
        exists = conn.execute("SELECT 1 FROM maps WHERE map_id = %s", (map_id,)).fetchone() is not None
        if exists and not replace:
            raise ValueError(f"数据库中已经存在地图 {map_id}；确认替换时请增加 --replace")
        if exists:
            conn.execute("DELETE FROM maps WHERE map_id = %s", (map_id,))
        conn.execute(
            """
            INSERT INTO maps (
                map_id, mine_id, name, revision, schema_version,
                coordinate_system, hex_size_m, manifest, generated_at
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                map_id, mine_id, str(manifest.get("name") or map_id), revision,
                str(manifest.get("schema_version") or "1.0"), str(manifest.get("crs") or "WGS84"),
                hex_size_m, Jsonb(manifest), manifest.get("generated_at"),
            ),
        )
        with conn.cursor() as cursor:
            cursor.executemany(
                "INSERT INTO map_layers (map_id, layer_name, content, content_sha256) VALUES (%s, %s, %s, %s)",
                [(map_id, name, Jsonb(content), canonical_sha256(content)) for name, content in layers.items()],
            )


def verify_import(database_url: str, map_id: str, layers: dict[str, Any]) -> None:
    with connect(database_url) as conn:
        rows = conn.execute(
            "SELECT layer_name, content, content_sha256 FROM map_layers WHERE map_id = %s",
            (map_id,),
        ).fetchall()
    stored = {name: (content, digest.strip()) for name, content, digest in rows}
    if set(stored) != set(layers):
        raise RuntimeError("数据库图层集合与地图包不一致")
    for name, expected in layers.items():
        content, digest = stored[name]
        expected_digest = canonical_sha256(expected)
        if digest != expected_digest or canonical_sha256(content) != expected_digest:
            raise RuntimeError(f"数据库图层 {name} 与地图包不一致")


def main() -> None:
    parser = argparse.ArgumentParser(description="将标准地图包导入 PostgreSQL")
    parser.add_argument("--map-dir", type=Path, required=True)
    parser.add_argument("--database-url", default=os.getenv("DATABASE_URL", ""))
    parser.add_argument("--replace", action="store_true")
    args = parser.parse_args()
    if not args.database_url:
        raise ValueError("缺少 --database-url 或 DATABASE_URL")
    manifest, layers = load_package(args.map_dir)
    import_package(args.database_url, manifest, layers, args.replace)
    verify_import(args.database_url, str(manifest["map_id"]), layers)
    counts = manifest.get("counts") or {}
    print(f"已导入并校验地图：{manifest['map_id']}")
    print(f"图层：{len(layers)}，六边形：{counts.get('hexagons', 0)}，道路边：{counts.get('road_edges', 0)}")


if __name__ == "__main__":
    main()
