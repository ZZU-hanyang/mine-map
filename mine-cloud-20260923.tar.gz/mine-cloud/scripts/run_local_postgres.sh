#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

if [ ! -x .venv/bin/python ]; then
  echo "请先创建 .venv 并安装 requirements.txt" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1091
if [ -f .env.local ]; then
  source .env.local
else
  source .env.local.example
fi
set +a
unset PYTHONPATH

exec .venv/bin/python -m backend.app
