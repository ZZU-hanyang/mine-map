from __future__ import annotations

import json
import logging
from pathlib import Path
from threading import RLock
from typing import Any

from tools.validate_map import validate_map_package

LOGGER = logging.getLogger(__name__)


class MapNotFoundError(KeyError):
    pass


class MapPackageError(RuntimeError):
    pass


class MapStore:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self._lock = RLock()
        self._cache: dict[Path, tuple[int, Any]] = {}
        self._validation_cache: dict[Path, tuple[tuple[tuple[str, int, int], ...], list[str]]] = {}

    def _manifest_object(self, path: Path) -> dict[str, Any]:
        """读取 manifest，并保证返回的是对象。

        manifest.json 是合法 JSON 但不是对象（`[]`、`"x"`、`123`）时，
        直接 .get() 会抛 AttributeError 并一路冒到 create_app，导致整个服务起不来。
        这里统一拦成 ValueError，交给调用方的既有异常分支处理。
        """
        manifest = self._read_json(path)
        if not isinstance(manifest, dict):
            raise ValueError(f"{path.name} 必须是 JSON 对象")
        return manifest

    def _package_dirs(self) -> list[Path]:
        """map_data 下的地图包目录。

        跳过 `.` 开头的目录：那是历史目录或编辑提交暂存目录的去处，
        里面可能躺着一份完整的 manifest，不排除的话会被当成一个"幽灵地图包"。
        """
        if not self.root.is_dir():
            return []
        return sorted(
            path for path in self.root.iterdir() if path.is_dir() and not path.name.startswith(".")
        )

    def discover(self) -> list[dict[str, Any]]:
        maps = []
        for directory in self._package_dirs():
            manifest_path = directory / "manifest.json"
            if not manifest_path.is_file():
                continue
            try:
                manifest = self._manifest_object(manifest_path)
                errors = self.validate(directory)
                maps.append(
                    {
                        "map_id": manifest.get("map_id", directory.name),
                        "mine_id": manifest.get("mine_id"),
                        "name": manifest.get("name", directory.name),
                        "generated_at": manifest.get("generated_at"),
                        "valid": not errors,
                        "errors": errors,
                    }
                )
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                maps.append(
                    {
                        "map_id": directory.name,
                        "mine_id": None,
                        "name": directory.name,
                        "generated_at": None,
                        "valid": False,
                        "errors": [str(exc)],
                    }
                )
        return maps

    def map_dir(self, map_id: str) -> Path:
        if not isinstance(map_id, str) or not map_id or map_id.startswith("."):
            raise MapNotFoundError(map_id)
        direct = (self.root / map_id).resolve()
        if direct.is_dir() and self.root in direct.parents:
            try:
                if self._manifest_object(direct / "manifest.json").get("map_id") == map_id:
                    return direct
            except (OSError, ValueError, json.JSONDecodeError):
                pass
        for candidate in self._package_dirs():
            try:
                manifest = self._manifest_object(candidate / "manifest.json")
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            if manifest.get("map_id") == map_id:
                return candidate.resolve()
        raise MapNotFoundError(map_id)

    def manifest(self, map_id: str) -> dict[str, Any]:
        directory = self.map_dir(map_id)
        errors = self.validate(directory)
        if errors:
            raise MapPackageError("；".join(errors))
        return self._manifest_object(directory / "manifest.json")

    def layer(self, map_id: str, layer: str) -> Any:
        manifest = self.manifest(map_id)
        files = manifest.get("files")
        if not isinstance(files, dict):
            raise MapPackageError("manifest.json 缺少 files 对象")
        relative = files.get(layer)
        # matrix 之类不是必填图层，缺了属于"包内容不完整"而不是"程序错误"。
        # 抛 KeyError 会绕过 app.py 注册的异常处理器变成 500 HTML，所以统一成 MapPackageError。
        if not relative:
            raise MapPackageError(f"地图包 {map_id} 里没有 {layer} 图层")
        path = self._safe_child(self.map_dir(map_id), relative)
        return self._read_json(path)

    def graph(self, map_id: str) -> dict[str, Any]:
        return self.layer(map_id, "road_graph")

    def mine_ids(self) -> list[str]:
        return sorted(
            {
                item["mine_id"]
                for item in self.discover()
                if item.get("valid") and isinstance(item.get("mine_id"), str)
            }
        )

    def map_id_for_mine(self, mine_id: str, preferred_map_id: str | None = None) -> str | None:
        """按 mine_id 找到地图包，只读 manifest，不跑整包校验。

        `/api/runtime/<mine_id>/nodes` 这类接口会被前端高频轮询，
        用 discover() 会每次 iterdir + stat + validate，代价没必要。
        """
        if not isinstance(mine_id, str) or not mine_id:
            return None
        matches: list[str] = []
        for directory in self._package_dirs():
            manifest_path = directory / "manifest.json"
            try:
                manifest = self._manifest_object(manifest_path)
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            if manifest.get("mine_id") != mine_id:
                continue
            map_id = manifest.get("map_id", directory.name)
            if isinstance(map_id, str) and map_id:
                matches.append(map_id)
        if not matches:
            return None
        if len(matches) > 1:
            LOGGER.warning("mine_id %s 对应多个地图包：%s", mine_id, ", ".join(matches))
        if preferred_map_id in matches:
            return preferred_map_id
        return matches[0]

    def invalidate(self, directory: Path | None = None) -> None:
        """Drop cached JSON/validation entries after a committed map edit."""
        with self._lock:
            if directory is None:
                self._cache.clear()
                self._validation_cache.clear()
                return
            directory = directory.resolve()
            self._cache = {
                path: value for path, value in self._cache.items() if path != directory and directory not in path.parents
            }
            self._validation_cache.pop(directory, None)

    def validate(self, directory: Path) -> list[str]:
        signature = self._package_signature(directory)
        with self._lock:
            cached = self._validation_cache.get(directory)
            if cached and cached[0] == signature:
                return list(cached[1])
        errors = validate_map_package(directory)
        with self._lock:
            self._validation_cache[directory] = (signature, list(errors))
        return errors

    def _package_signature(self, directory: Path) -> tuple[tuple[str, int, int], ...]:
        paths = [directory / "manifest.json"]
        try:
            manifest = self._manifest_object(paths[0])
            if isinstance(manifest.get("files"), dict):
                paths.extend(directory / value for value in manifest["files"].values() if isinstance(value, str))
        except (OSError, ValueError, json.JSONDecodeError):
            pass
        result = []
        for path in sorted(set(paths)):
            try:
                stat = path.stat()
                result.append((str(path), stat.st_mtime_ns, stat.st_size))
            except OSError:
                result.append((str(path), -1, -1))
        return tuple(result)

    def _safe_child(self, directory: Path, relative: str) -> Path:
        path = (directory / relative).resolve()
        if directory != path and directory not in path.parents:
            raise MapPackageError("地图包中的文件路径越界")
        if not path.is_file():
            raise MapPackageError(f"地图包缺少文件：{relative}")
        return path

    def _read_json(self, path: Path) -> Any:
        stat = path.stat()
        version = stat.st_mtime_ns
        with self._lock:
            cached = self._cache.get(path)
            if cached and cached[0] == version:
                return cached[1]
            data = json.loads(path.read_text(encoding="utf-8"))
            self._cache[path] = (version, data)
            return data
