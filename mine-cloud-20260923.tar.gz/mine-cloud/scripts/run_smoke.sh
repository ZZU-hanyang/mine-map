#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"
unset PYTHONPATH

if [ ! -x .venv/bin/python ]; then
  echo "请先创建虚拟环境并安装 requirements.txt" >&2
  exit 1
fi

exec .venv/bin/python -m backend.app
