# 标准地图数据包 1.0

每个矿区地图是 `map_data/` 下的独立目录。后端只依赖这个契约，不依赖月山平台，也不依赖轨迹CSV的文件名。

```text
map_data/mine-a/
├── manifest.json
├── boundary.geojson
├── hex_grid.geojson
├── roads.geojson
├── road_graph.json
├── nodes.geojson
├── matrix.json
└── history_tracks.geojson
```

## 基本规则

- 所有经纬度统一为 WGS84，顺序统一为 `[longitude, latitude]`。
- `manifest.json` 是入口，保存 `map_id`、`mine_id`、名称、范围、中心、生成时间、文件名和数量。
- `boundary.geojson` 是矿区边界。自动生成的是轨迹凸包，后续可以单独换成准确测绘边界。
- `hex_grid.geojson` 是六边形地图单元，每个色块的 `type` 必须是 `road`、`loading`、`unloading` 或 `charging`。
- `roads.geojson` 只包含真实连续轨迹形成的六边形连接线。
- `road_graph.json` 是路径规划使用的节点和边，必须与 `roads.geojson` 同版本。轨迹建图生成的边可带 `time_stats`，其中 `from_to` 和 `to_from` 分别保存两个方向的样本数、历史中位通行时间、P75通行时间和中位速度；没有该字段的边按服务端默认15 km/h估时。
- `nodes.geojson` 保存静态功能区；MQTT收到的动态功能区不写回这里。
- `matrix.json` 保存0/1装卸匹配矩阵：`row_node_ids` 是装货点ID，`column_node_ids` 是卸货点ID，`matrix` 的行列顺序与这两个数组严格对应。`semantics=loading_unloading_match` 用来防止下游把它误解为道路通行权限。编辑页可选择同步发布到MQTT。
- `history_tracks.geojson` 仅用于检查建图效果，可以在页面关闭。

更换地图时，应整体新增一个地图目录，再执行 `tools/validate_map.py`。不要只替换 `road_graph.json` 或 `hex_grid.geojson` 中的一个，否则版本会不一致。

人工编辑道路时，浏览器只提交“新增、删除、连接、断开”等操作，后端根据 `road_graph.json`
重新生成 `roads.geojson`。保存前会检查六边形ID、道路节点、边以及数量是否一致。每次保存都会更新
`manifest.json` 的 `edited_at`、`editor_revision` 和数量，不保留旧版地图。

矩阵示例：

```json
{
  "semantics": "loading_unloading_match",
  "row_node_ids": ["loading_001", "loading_002"],
  "column_node_ids": ["unloading_001"],
  "matrix": [[1], [0]]
}
```

这里表示 `loading_001` 与 `unloading_001` 已匹配，`loading_002` 未匹配。它不表达道路能否通行；路径可达性由 `road_graph.json` 决定。功能区节点被新增、改名或删除时，后端会自动对齐矩阵行列，并保留仍能按节点ID匹配的旧勾选值。
