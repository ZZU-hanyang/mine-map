#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

if [ ! -x .venv/bin/python ]; then
  echo "请先创建 .venv 并安装 requirements.txt" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1091
if [ -f .env.local ]; then
  source .env.local
else
  source .env.local.example
fi
set +a

psql -v ON_ERROR_STOP=1 -d mine_map_local -f database/schema.sql
.venv/bin/python -m tools.import_map_to_postgres \
  --map-dir map_data/mine-a \
  --database-url "$DATABASE_URL" \
  --replace

psql -d mine_map_local -P pager=off -c \
  "SELECT m.map_id, m.name, m.revision, count(l.layer_name) AS layers
   FROM maps AS m
   LEFT JOIN map_layers AS l ON l.map_id = m.map_id
   GROUP BY m.map_id, m.name, m.revision
   ORDER BY m.map_id;"

echo "本地 PostgreSQL 初始化完成。"
