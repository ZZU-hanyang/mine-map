# mine-a 云端交付包

本目录只包含云端运行一号矿区电子地图所需的后端、前端、正式地图包、校验工具和接口文档。月山 API 拉取、原始 CSV、离线建图工具、真实密码、虚拟环境、缓存、其他矿区和旧地图备份不在交付范围内。

## 目录内容

```text
backend/             HTTP API、PostgreSQL/文件存储、地图编辑、路径规划和 MQTT 桥接
database/schema.sql  PostgreSQL表结构（当前使用JSONB，不要求PostGIS）
frontend/            首页、运行监控和地图编辑页面
map_data/mine-a/     已验收的一号矿区正式地图包
tools/               地图校验和 PostgreSQL 导入工具
docs/                HTTP API、MQTT 和地图包格式说明
scripts/run_smoke.sh 回环地址冒烟测试入口
.env.example         云端配置模板，不含密码
requirements.txt     Python 运行依赖
SHA256SUMS           交付文件完整性校验值
```

## 收到后先校验

```bash
cd mine-cloud
sha256sum -c SHA256SUMS
python3 tools/validate_map.py map_data/mine-a
```

两项都通过后再进行部署或数据库导入。

## PostgreSQL 部署（生产推荐）

云端以 PostgreSQL 为地图权威数据源。当前图层以 JSONB 保存，路径计算在 Python 中完成，
因此部署不要求安装 PostGIS。数据库管理员应先创建独立数据库和专用账号，
不要让地图后端长期使用共享账号或超级管理员账号。

安装依赖并创建配置：

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
cp .env.example .env
```

保护真实配置：

```bash
chmod 600 .env
```

使用数据库所有者执行表结构：

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f database/schema.sql
```

导入随包交付的正式地图。数据库已有 `mine-a` 且确认要整体替换时才增加 `--replace`：

```bash
.venv/bin/python -m tools.import_map_to_postgres \
  --map-dir map_data/mine-a \
  --database-url "$DATABASE_URL"
```

`.env` 的关键配置：

```dotenv
MAP_STORAGE=postgres
DATABASE_URL=postgresql://mine_map_app:真实密码@127.0.0.1:5432/mine_map
DATABASE_POOL_MIN_SIZE=1
DATABASE_POOL_MAX_SIZE=10
DATABASE_CONNECT_TIMEOUT_S=10
ACTIVE_MAP_ID=mine-a
```

密码含有 `@`、`:`、`/`、`#` 等字符时必须进行 URL 编码，或改用 PostgreSQL service/password
文件。真实连接串禁止写入 Git、前端或公开文档。

## 本地模拟云服务器

Ubuntu 本机已经创建 `mine_map_local` 后，可以在不接触云服务器的情况下演练完整上线流程。
本地配置使用 Unix Socket 和 Peer 认证，不保存数据库密码。

第一次运行：

```bash
cd /home/user/mine-map/mine-cloud
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
cp .env.local.example .env.local
chmod 600 .env.local
chmod +x scripts/*.sh
./scripts/bootstrap_local_postgres.sh
```

在启动服务前，将百度地图 AK 填入 `.env.local` 的 `BAIDU_MAP_AK`。`.env.local` 已被忽略，
不得加入交付校验清单或提交到代码仓库。

初始化脚本会重复执行安全的建表语句，并使用一个事务把随包的 `mine-a` 替换进本地数据库。
它只连接 `mine_map_local`，不访问云端。

启动本地服务：

```bash
./scripts/run_local_postgres.sh
```

浏览器访问：

```text
http://127.0.0.1:8000/
http://127.0.0.1:8000/map.html
http://127.0.0.1:8000/editor.html
```

另开终端检查：

```bash
curl -sS http://127.0.0.1:8000/api/health
curl -sS http://127.0.0.1:8000/api/maps
curl -sS http://127.0.0.1:8000/api/maps/mine-a/editor
```

练习环境验证成功后，上云时保留相同代码，只把 `.env` 中的 `DATABASE_URL`、百度地图 AK、
MQTT 和域名相关配置换成云端值。不要把 `.env.local.example` 的本机连接方式用于远程数据库。

## 回环地址冒烟测试

数据库和地图导入完成后启动：

```bash
./scripts/run_smoke.sh
```

另开终端检查：

```bash
curl -sS http://127.0.0.1:8000/api/health
curl -sS http://127.0.0.1:8000/api/maps
curl -sS http://127.0.0.1:8000/api/maps/mine-a/manifest
curl -sS http://127.0.0.1:8000/api/runtime/mine-a/nodes
curl -sS http://127.0.0.1:8000/api/runtime/mine-a/matrix
```

健康检查应包含：

```json
{"ok":true,"map_storage":"postgres","valid_maps":1}
```

`run_smoke.sh` 使用 Flask 内置服务，只供验收，不是公网生产启动方案。

生产环境启动：

```bash
chmod +x scripts/*.sh
./scripts/run_production.sh
```

生产脚本使用 Gunicorn，固定一个 Worker 和多个线程。当前 MQTT 车辆状态保存在进程内，不能通过
增加 Gunicorn Worker 数量横向扩容；需要扩容时应先拆分 MQTT Worker 并引入 Redis。

## 生产部署要求

- 后端应监听回环地址或受控容器网络，由 Nginx/API Gateway 提供 HTTPS、鉴权、限流和日志。
- 当前写接口没有内建用户鉴权，不得直接暴露到公网。
- `MAP_STORAGE=postgres` 时 PostgreSQL 是唯一运行时权威数据源；地图读取、路径查询和地图编辑均访问数据库。
- 地图编辑使用行锁、版本号和数据库事务；五个关联图层及 manifest 会一起提交或一起回滚。
- `MAP_STORAGE=file` 仅用于离线排障。不要同时运行 file 与 postgres 两套可写服务。
- 多 Web 进程不能各自保存 MQTT 实时车辆状态。正式扩容时应将 MQTT 订阅拆成单例 Worker，并把当前车辆状态放入 Redis。
- 地图重新导入后，需要同步清理 EMQX 中旧功能区 retained 消息，避免 HTTP 新地图与 MQTT 旧配置不一致。

## 数据库结构

| 地图文件 | 建议数据库内容 |
|---|---|
| `manifest.json` | 地图元数据、版本和构建参数 |
| `boundary.geojson` | 矿区边界 |
| `hex_grid.geojson` | 六边形道路和功能区色块 |
| `road_graph.json` | 道路节点、道路边及双向历史 ETA |
| `nodes.geojson` | 装货区、卸货区和充电区参数 |
| `matrix.json` | 装卸匹配关系 |
| `history_tracks.geojson` | 可选的历史轨迹展示数据 |

`maps` 保存地图元数据、manifest 和乐观锁版本；`map_layers` 以 JSONB 保存七个完整图层。
这种结构保持现有 HTTP API 返回格式不变，前端无需了解数据库。`roads` 在编辑提交时根据
`road_graph` 重建。

## 文件模式排障

临时验证随包地图文件时可配置：

```dotenv
MAP_STORAGE=file
MAP_DATA_ROOT=map_data
```

文件模式与数据库模式是相互独立的数据源。生产环境切回 PostgreSQL 前，应确认数据库中已经
导入最新地图。

## 文档

- `docs/API.md`：HTTP API
- `docs/MQTT_TOPICS.md`：MQTT 话题和消息契约
- `docs/MAP_PACKAGE_SPEC.md`：地图包数据格式

所有空间数据均为 WGS84，经纬度顺序为 `[longitude, latitude]`。地图接口使用 `map_id=mine-a`，运行时车辆、功能区和矩阵接口使用 `mine_id=mine-a`。
