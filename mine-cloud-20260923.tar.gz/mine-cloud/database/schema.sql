CREATE TABLE IF NOT EXISTS maps (
    map_id              text PRIMARY KEY,
    mine_id             text NOT NULL UNIQUE,
    name                text NOT NULL,
    revision            bigint NOT NULL DEFAULT 0 CHECK (revision >= 0),
    schema_version      text NOT NULL,
    coordinate_system   text NOT NULL DEFAULT 'WGS84',
    hex_size_m          double precision CHECK (hex_size_m IS NULL OR hex_size_m > 0),
    manifest            jsonb NOT NULL CHECK (jsonb_typeof(manifest) = 'object'),
    generated_at        timestamptz,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS map_layers (
    map_id          text NOT NULL REFERENCES maps(map_id) ON DELETE CASCADE,
    layer_name      text NOT NULL CHECK (
        layer_name IN ('boundary', 'hex_grid', 'roads', 'road_graph', 'nodes', 'history_tracks', 'matrix')
    ),
    content         jsonb NOT NULL,
    content_sha256  char(64) NOT NULL,
    updated_at      timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (map_id, layer_name)
);

CREATE INDEX IF NOT EXISTS idx_map_layers_map_id ON map_layers(map_id);

COMMENT ON TABLE maps IS 'Map metadata and manifest.';
COMMENT ON TABLE map_layers IS 'Complete JSON/GeoJSON map layers.';
COMMENT ON COLUMN maps.revision IS 'Optimistic-lock version used by the map editor.';
