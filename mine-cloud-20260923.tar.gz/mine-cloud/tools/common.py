from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def load_env_file(path: Path) -> None:
    """读取简单 KEY=VALUE 格式文件，但不覆盖已存在的环境变量。"""
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if value and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            os.environ.setdefault(key, value)


def utc_iso(ts_ms: int | None = None) -> str:
    if ts_ms is None:
        value = datetime.now(timezone.utc)
    else:
        value = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
    return value.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def safe_filename(value: str, fallback: str = "device") -> str:
    value = re.sub(r"[\\/:*?\"<>|\s]+", "_", value.strip())
    value = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fff]", "", value)
    return value.strip("_-") or fallback


def dump_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)

