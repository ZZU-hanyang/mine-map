from __future__ import annotations

import logging
import math
import os
from dataclasses import dataclass
from pathlib import Path

from tools.common import load_env_file

LOGGER = logging.getLogger(__name__)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


def env_float(name: str, default: float, minimum: float = 1e-6, maximum: float | None = None) -> float:
    """读浮点配置，并挡掉会让下游算坏的取值。

    除了空串/非法文本，还必须拒绝 nan 和 inf；而且必须限定区间——
    `DEFAULT_SPEED_KMH=1e-320` 这种"大于 0 但实际等于 0"的值会让
    时间计算除以极小数溢出成 inf，Flask 会把它原样输出成非法 JSON。
    """
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default
    if not math.isfinite(value) or value < minimum:
        LOGGER.warning("%s=%r 不是有效取值（需 >= %s），回退到 %s", name, value, minimum, default)
        return default
    if maximum is not None and value > maximum:
        LOGGER.warning("%s=%r 超出上限 %s，回退到 %s", name, value, maximum, default)
        return default
    return value


def resolve_path(raw: str, base: Path = PROJECT_ROOT) -> Path:
    path = Path(raw).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


@dataclass
class Settings:
    project_root: Path
    map_data_root: Path
    active_map_id: str
    map_storage: str = "file"
    database_url: str = ""
    database_pool_min_size: int = 1
    database_pool_max_size: int = 10
    database_connect_timeout_s: float = 10.0
    host: str = "127.0.0.1"
    port: int = 8000
    allow_unauthenticated_remote: bool = False
    baidu_map_ak: str = ""
    # 到达时间估算用的固定车速（km/h）。接口不再接收调用方传速度。
    default_speed_kmh: float = 15.0
    truck_offline_timeout_s: float = 45.0
    mqtt_publish_timeout_s: float = 5.0
    mqtt_enabled: bool = False
    mqtt_host: str = "127.0.0.1"
    mqtt_port: int = 1883
    mqtt_username: str = ""
    mqtt_password: str = ""
    mqtt_sub_username: str = ""
    mqtt_sub_password: str = ""
    mqtt_pub_username: str = ""
    mqtt_pub_password: str = ""
    mqtt_client_id: str = "mine-map-local"
    mqtt_keepalive: int = 60
    mqtt_tls: bool = False
    mqtt_ca_file: str = ""
    mqtt_cert_file: str = ""
    mqtt_key_file: str = ""
    mqtt_tls_insecure: bool = False

    @classmethod
    def from_env(cls, env_path: Path | None = None) -> "Settings":
        load_env_file(env_path or PROJECT_ROOT / ".env")
        base_username = os.getenv("MQTT_USERNAME", "").strip()
        base_password = os.getenv("MQTT_PASSWORD", "")
        map_storage = os.getenv("MAP_STORAGE", "file").strip().lower()
        if map_storage not in {"file", "postgres"}:
            raise ValueError("MAP_STORAGE 只能是 file 或 postgres")
        database_pool_min_size = env_int("DATABASE_POOL_MIN_SIZE", 1)
        database_pool_max_size = env_int("DATABASE_POOL_MAX_SIZE", 10)
        if database_pool_min_size < 1 or database_pool_max_size < database_pool_min_size:
            raise ValueError("数据库连接池大小配置无效")
        return cls(
            project_root=PROJECT_ROOT,
            map_data_root=resolve_path(os.getenv("MAP_DATA_ROOT", "map_data")),
            active_map_id=os.getenv("ACTIVE_MAP_ID", "demo_mine").strip(),
            map_storage=map_storage,
            database_url=os.getenv("DATABASE_URL", "").strip(),
            database_pool_min_size=database_pool_min_size,
            database_pool_max_size=database_pool_max_size,
            database_connect_timeout_s=env_float(
                "DATABASE_CONNECT_TIMEOUT_S", 10.0, minimum=1.0, maximum=60.0
            ),
            host=os.getenv("APP_HOST", "127.0.0.1").strip(),
            port=env_int("APP_PORT", 8000),
            allow_unauthenticated_remote=env_bool("ALLOW_UNAUTHENTICATED_REMOTE", False),
            baidu_map_ak=os.getenv("BAIDU_MAP_AK", "").strip(),
            # 矿车车速合理区间 1～200 km/h，超出说明配置写错了，回退默认值
            default_speed_kmh=env_float("DEFAULT_SPEED_KMH", 15.0, minimum=1.0, maximum=200.0),
            truck_offline_timeout_s=env_float(
                "TRUCK_OFFLINE_TIMEOUT_S", 45.0, minimum=5.0, maximum=3600.0
            ),
            mqtt_publish_timeout_s=env_float(
                "MQTT_PUBLISH_TIMEOUT_S", 5.0, minimum=0.1, maximum=60.0
            ),
            mqtt_enabled=env_bool("MQTT_ENABLED", False),
            mqtt_host=os.getenv("MQTT_HOST", "127.0.0.1").strip(),
            mqtt_port=env_int("MQTT_PORT", 1883),
            mqtt_username=base_username,
            mqtt_password=base_password,
            # 订阅连接与发布连接可分别指定账号；未指定时回退到 MQTT_USERNAME/MQTT_PASSWORD
            mqtt_sub_username=os.getenv("MQTT_SUB_USERNAME", "").strip() or base_username,
            mqtt_sub_password=os.getenv("MQTT_SUB_PASSWORD", "") or base_password,
            mqtt_pub_username=os.getenv("MQTT_PUB_USERNAME", "").strip() or base_username,
            mqtt_pub_password=os.getenv("MQTT_PUB_PASSWORD", "") or base_password,
            mqtt_client_id=os.getenv("MQTT_CLIENT_ID", "mine-map-local").strip(),
            mqtt_keepalive=env_int("MQTT_KEEPALIVE", 60),
            mqtt_tls=env_bool("MQTT_TLS", False),
            mqtt_ca_file=os.getenv("MQTT_CA_FILE", "").strip(),
            mqtt_cert_file=os.getenv("MQTT_CERT_FILE", "").strip(),
            mqtt_key_file=os.getenv("MQTT_KEY_FILE", "").strip(),
            mqtt_tls_insecure=env_bool("MQTT_TLS_INSECURE", False),
        )

    def public_config(self) -> dict[str, object]:
        return {
            "active_map_id": self.active_map_id,
            "map_storage": self.map_storage,
            "baidu_map_ak": self.baidu_map_ak,
            "mqtt_enabled": self.mqtt_enabled,
            "mqtt_host": self.mqtt_host if self.mqtt_enabled else None,
            "mqtt_port": self.mqtt_port if self.mqtt_enabled else None,
        }
