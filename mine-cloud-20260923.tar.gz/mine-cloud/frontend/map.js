"use strict";

// ========== 状态 ==========
var state = {
  config: null,
  maps: [],
  mapId: null,
  manifest: null,
  map: null,
  layers: new Map(),
  truckMarkers: new Map(),
  nodeMarkers: new Map(),
  staticNodes: new Map(),
  runtimeNodes: new Map(),
  nodeList: [],               // 功能区下拉列表 [{lng,lat,name,type,node_id}]
  hexFeatures: [],            // 六边形原始要素（q/r/type），用于功能区详情
  hexByCoord: new Map(),      // "q,r" -> 六边形 properties
  hexByNode: new Map(),       // "type/node_id" -> 六边形 properties
  hexCenterByNode: new Map(), // "type/node_id" -> 色块中心 [lng, lat]
  nodeLabelsVisible: true,    // 功能区名字开关
  overlayClickUntil: 0,       // 刚点过覆盖物的时间戳，避免同一次点击又触发地图选点
  hexInfoWindow: null,
  routeMode: null,            // 'start' | 'end'
  qStart: null,
  qEnd: null,
  qMarkers: [],
  qPathPoly: null,
  historyLoaded: false,
  refreshing: false,
};

var TYPE_NAMES = { loading: '装货区', unloading: '卸货区', charging: '充电区', road: '道路' };
var NODE_COLORS = { loading: '#2196f3', unloading: '#f44336', charging: '#ff9800' };

// 静态节点与实时节点共用同一套命名，避免同一功能区出现两种显示名
function nodeDisplayName(props) {
  var type = props.node_type || props.type || 'node';
  var label = TYPE_NAMES[type] || type;
  return props.name || (props.node_id ? label + ' ' + props.node_id : label);
}

// ========== 工具函数 ==========
function $(selector) { return document.querySelector(selector); }
function $$(selector) { return Array.from(document.querySelectorAll(selector)); }

function toast(message) {
  var el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(function () { el.classList.remove('show'); }, 3500);
}

function escapeHtml(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

async function api(url, options) {
  options = options || {};
  var controller = new AbortController();
  var timer = setTimeout(function () { controller.abort(); }, 10000);
  var response;
  try {
    response = await fetch(url, {
      headers: options.body ? { 'Content-Type': 'application/json' } : undefined,
      ...options,
      signal: options.signal || controller.signal,
    });
  } catch (error) {
    if (error && error.name === 'AbortError') throw new Error('请求超时');
    throw error;
  } finally {
    clearTimeout(timer);
  }
  var body;
  try { body = await response.json(); } catch (e) { body = {}; }
  if (!response.ok) throw new Error(body.error || (response.status + ' ' + response.statusText));
  return body;
}

function setStatus(text) { $('#mapStatus').textContent = text; }

function showMessage(message) {
  var el = $('#mapMessage');
  el.textContent = message;
  el.classList.toggle('show', !!message);
}

// ========== 百度地图加载与坐标适配 ==========
async function loadBaiduMap(ak) {
  if (window.BMapGL) return;
  if (!ak) throw new Error('未设置 BAIDU_MAP_AK，请编辑 .env 后重启程序');
  await new Promise(function (resolve, reject) {
    var callbackName = 'baiduReady_' + Date.now();
    window[callbackName] = function () { delete window[callbackName]; resolve(); };
    var script = document.createElement('script');
    script.src = 'https://api.map.baidu.com/api?v=1.0&type=webgl&ak=' + encodeURIComponent(ak) + '&callback=' + callbackName;
    script.onerror = function () { reject(new Error('百度地图脚本加载失败，请检查网络和AK')); };
    document.head.appendChild(script);
  });
}

var PI = Math.PI, AXIS = 6378245.0, EE = 0.006693421622965943;
function outsideChina(lon, lat) { return lon < 72.004 || lon > 137.8347 || lat < 0.8293 || lat > 55.8271; }
function transformLat(x, y) {
  var v = -100 + 2 * x + 3 * y + .2 * y * y + .1 * x * y + .2 * Math.sqrt(Math.abs(x));
  v += (20 * Math.sin(6 * x * PI) + 20 * Math.sin(2 * x * PI)) * 2 / 3;
  v += (20 * Math.sin(y * PI) + 40 * Math.sin(y / 3 * PI)) * 2 / 3;
  return v + (160 * Math.sin(y / 12 * PI) + 320 * Math.sin(y * PI / 30)) * 2 / 3;
}
function transformLon(x, y) {
  var v = 300 + x + 2 * y + .1 * x * x + .1 * x * y + .1 * Math.sqrt(Math.abs(x));
  v += (20 * Math.sin(6 * x * PI) + 20 * Math.sin(2 * x * PI)) * 2 / 3;
  v += (20 * Math.sin(x * PI) + 40 * Math.sin(x / 3 * PI)) * 2 / 3;
  return v + (150 * Math.sin(x / 12 * PI) + 300 * Math.sin(x / 30 * PI)) * 2 / 3;
}
function wgsToGcj(lon, lat) {
  if (outsideChina(lon, lat)) return [lon, lat];
  var dLat = transformLat(lon - 105, lat - 35), dLon = transformLon(lon - 105, lat - 35);
  var radLat = lat / 180 * PI, magic = 1 - EE * Math.sin(radLat) * Math.sin(radLat);
  var sqrtMagic = Math.sqrt(magic);
  dLat = dLat * 180 / ((AXIS * (1 - EE)) / (magic * sqrtMagic) * PI);
  dLon = dLon * 180 / (AXIS / sqrtMagic * Math.cos(radLat) * PI);
  return [lon + dLon, lat + dLat];
}
function gcjToBd(lon, lat) {
  var z = Math.sqrt(lon * lon + lat * lat) + .00002 * Math.sin(lat * Math.PI * 3000 / 180);
  var theta = Math.atan2(lat, lon) + .000003 * Math.cos(lon * Math.PI * 3000 / 180);
  return [z * Math.cos(theta) + .0065, z * Math.sin(theta) + .006];
}
function bdToGcj(lon, lat) {
  var x = lon - .0065, y = lat - .006;
  var z = Math.sqrt(x * x + y * y) - .00002 * Math.sin(y * Math.PI * 3000 / 180);
  var theta = Math.atan2(y, x) - .000003 * Math.cos(x * Math.PI * 3000 / 180);
  return [z * Math.cos(theta), z * Math.sin(theta)];
}
function wgsToBd(lon, lat) { return gcjToBd.apply(null, wgsToGcj(lon, lat)); }
function bdToWgs(lon, lat) {
  var g = bdToGcj(lon, lat);
  var guess = g.slice();
  for (var i = 0; i < 3; i++) {
    var converted = wgsToGcj(guess[0], guess[1]);
    guess = [guess[0] - (converted[0] - g[0]), guess[1] - (converted[1] - g[1])];
  }
  return guess;
}
function pointWgs(coordinate) {
  var bd = wgsToBd(Number(coordinate[0]), Number(coordinate[1]));
  return new BMapGL.Point(bd[0], bd[1]);
}

function eventBdPoint(event) {
  return event && (event.latlng || event.point);
}

// ========== 地图初始化 ==========
function initMap() {
  state.map = new BMapGL.Map('map');
  try { state.map.setDisplayOptions({ building: false }); } catch (e) {}   // 关闭3D建筑，避免遮挡六边形
  state.nodeLabelsVisible = layerVisible('node_labels');   // 跟随浏览器可能恢复的勾选状态
  state.map.enableScrollWheelZoom(true);
  state.map.enableDragging(true);
  state.map.addControl(new BMapGL.NavigationControl3D());
  state.map.addEventListener('mousemove', function (e) {
    var point = eventBdPoint(e);
    if (!point) return;
    var wgs = bdToWgs(point.lng, point.lat);
    $('#mouseCoord').textContent = '经度 ' + wgs[0].toFixed(7) + '　纬度 ' + wgs[1].toFixed(7);
  });
  state.map.addEventListener('click', mapClick);
  var resizeTimer;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () { try { state.map.resize(); } catch (e) {} }, 200);
  });
}

// ========== 图层 ==========
function layerVisible(name) {
  var input = document.querySelector('[data-layer="' + name + '"]');
  return !input || input.checked;
}

function setLayer(name, overlays) {
  clearLayer(name);
  state.layers.set(name, overlays);
  overlays.forEach(function (o) {
    state.map.addOverlay(o);
    if (!layerVisible(name)) o.hide();
  });
}

function clearLayer(name) {
  (state.layers.get(name) || []).forEach(function (o) { state.map.removeOverlay(o); });
  state.layers.set(name, []);
}

function toggleLayer(name, visible) {
  (state.layers.get(name) || []).forEach(function (o) { visible ? o.show() : o.hide(); });
  if (name === 'trucks') state.truckMarkers.forEach(function (m) { visible ? m.show() : m.hide(); });
  if (name === 'node_labels') setNodeLabels(visible);
}

// 挂在 marker 上的 label 没有 hide()，用清空内容 + display 控制显隐（官方示例做法）
function applyNodeLabel(marker, visible) {
  var label = marker._mineLabel;
  if (!label) return;
  label.setContent(visible ? (marker._mineLabelText || '') : '');
  label.setStyle({ display: visible ? 'block' : 'none' });
}

function setNodeLabels(visible) {
  state.nodeLabelsVisible = visible;
  state.nodeMarkers.forEach(function (marker) { applyNodeLabel(marker, visible); });
}

function lineOverlays(geometry, style) {
  var lines = geometry.type === 'LineString' ? [geometry.coordinates] : geometry.coordinates;
  return lines.map(function (line) { return new BMapGL.Polyline(line.map(pointWgs), style); });
}

function polygonOverlays(geometry, style) {
  var polygons = geometry.type === 'Polygon' ? [geometry.coordinates] : geometry.coordinates;
  return polygons.map(function (polygon) { return new BMapGL.Polygon(polygon[0].map(pointWgs), style); });
}

var HEX_FILL = { road: '#eeb852', loading: '#2196f3', unloading: '#ef5350', charging: '#ff9800' };

function firstRing(geometry) {
  var coords = geometry.coordinates || [];
  var polygon = geometry.type === 'Polygon' ? coords : (coords[0] || []);
  return polygon[0] || [];
}

function polygonCentroid(geometry) {
  var ring = firstRing(geometry);
  var count = Math.min(6, ring.length), lng = 0, lat = 0;
  for (var i = 0; i < count; i++) { lng += Number(ring[i][0]); lat += Number(ring[i][1]); }
  return count ? [lng / count, lat / count] : [0, 0];
}

function indexHexes(collection) {
  state.hexFeatures = (collection && collection.features) || [];
  state.hexByCoord = new Map();
  state.hexByNode = new Map();
  state.hexCenterByNode = new Map();
  state.hexFeatures.forEach(function (feature) {
    var props = feature.properties || {};
    if (props.q != null && props.r != null) state.hexByCoord.set(Number(props.q) + ',' + Number(props.r), props);
    if (props.node_id && (props.type || 'road') !== 'road') {
      var key = props.type + '/' + props.node_id;
      state.hexByNode.set(key, props);
      state.hexCenterByNode.set(key, polygonCentroid(feature.geometry || {}));
    }
  });
}

function facilityRecord(props) {
  var key = (props.type || '') + '/' + (props.node_id || '');
  return state.runtimeNodes.get(key) || state.staticNodes.get(key) || null;
}

// 覆盖在六边形之上的功能区图标会挡住色块，所以详情同时挂在图标和名字标签上
function openFacilityDetail(props, center) {
  var record = props ? facilityRecord(props) : null;
  var data = Object.assign({}, props || {});
  if (record) {
    // 实时节点记录比地图包里的色块参数更新，逐字段覆盖
    ['status', 'servers', 'max_queue', 'average_time_min', 'priority'].forEach(function (field) {
      if (record.data && record.data[field] != null) data[field] = record.data[field];
      if (field === 'status' && record.status != null) data.status = record.status;
    });
  }
  var hexCenter = state.hexCenterByNode.get((data.type || '') + '/' + (data.node_id || ''));
  var anchor = (record && Number.isFinite(record.lng)) ? [record.lng, record.lat] : (center || hexCenter || null);
  var lng = anchor ? anchor[0] : null;
  var lat = anchor ? anchor[1] : null;
  var status = data.status === 'open' ? '开放' : (data.status === 'closed' ? '已关闭' : (data.status || '-'));
  var rows = [
    ['类型', TYPE_NAMES[data.type] || data.type || '-'],
    ['节点ID', data.node_id || '-'],
    ['状态', status],
    ['服务台数', data.servers == null ? '-' : data.servers],
    ['最大排队', data.max_queue == null ? '-' : data.max_queue],
    ['平均耗时', data.average_time_min == null ? '-' : data.average_time_min + ' 分钟'],
    ['优先级', data.priority == null ? '-' : data.priority],
    ['经度', lng == null ? '-' : Number(lng).toFixed(7)],
    ['纬度', lat == null ? '-' : Number(lat).toFixed(7)],
  ];
  var html = '<div class="hex-detail"><table>' + rows.map(function (row) {
    return '<tr><th>' + escapeHtml(row[0]) + '</th><td>' + escapeHtml(String(row[1])) + '</td></tr>';
  }).join('') + '</table></div>';

  if (state.hexInfoWindow) state.map.closeInfoWindow();
  state.hexInfoWindow = new BMapGL.InfoWindow(html, { width: 230, enableAutoPan: true });
  if (lng != null && lat != null) state.map.openInfoWindow(state.hexInfoWindow, pointWgs([lng, lat]));
}

function closeHexDetail() {
  if (state.hexInfoWindow) { state.map.closeInfoWindow(); state.hexInfoWindow = null; }
}

function drawGeoJson(name, collection) {
  var overlays = [];
  var styles = {
    boundary: { strokeColor: '#cf3341', strokeWeight: 3, strokeOpacity: .9, fillColor: '#cf3341', fillOpacity: .04 },
    hex_grid: { strokeColor: '#d28b16', strokeWeight: 1, strokeOpacity: .55, fillColor: '#eeb852', fillOpacity: .08 },
    roads: { strokeColor: '#177a58', strokeWeight: 3, strokeOpacity: .72 },
    history_tracks: { strokeColor: '#7a4eb3', strokeWeight: 2, strokeOpacity: .45 },
  };
  (collection.features || []).forEach(function (feature) {
    var geometry = feature.geometry || {};
    if (name === 'hex_grid' && (geometry.type === 'Polygon' || geometry.type === 'MultiPolygon')) {
      // 色块与编辑器统一：按六边形类型着色
      var hexType = (feature.properties || {}).type || 'road';
      var fill = HEX_FILL[hexType] || HEX_FILL.road;
      var center = polygonCentroid(geometry);
      var hexPolygons = polygonOverlays(geometry, {
        strokeColor: '#333', strokeWeight: 1, strokeOpacity: .5,
        fillColor: fill, fillOpacity: hexType === 'road' ? .28 : .55,
      });
      // 只有功能区色块可点击查看详情，道路色块不响应
      if (hexType !== 'road') {
        hexPolygons.forEach(function (polygon) {
          polygon.addEventListener('click', function (event) {
            if (state.routeMode) return;   // 选点模式下这一点击用于确定起终点
            state.overlayClickUntil = Date.now() + 250;   // 别让同一次点击又走到地图空白点击逻辑
            if (event && event.domEvent && event.domEvent.stopPropagation) event.domEvent.stopPropagation();
            openFacilityDetail(feature.properties || {}, center);
          });
        });
      }
      overlays.push.apply(overlays, hexPolygons);
      return;
    }
    if (geometry.type === 'LineString' || geometry.type === 'MultiLineString') overlays.push.apply(overlays, lineOverlays(geometry, styles[name]));
    if (geometry.type === 'Polygon' || geometry.type === 'MultiPolygon') overlays.push.apply(overlays, polygonOverlays(geometry, styles[name]));
    if (geometry.type === 'Point') {
      var props = feature.properties || {};
      var type = props.type || 'road';
      var marker = new BMapGL.Marker(pointWgs(geometry.coordinates));
      var label = new BMapGL.Label(props.name || props.node_id || TYPE_NAMES[type] || '功能区', { offset: new BMapGL.Size(14, -12) });
      label.setStyle({ color: '#333', backgroundColor: 'rgba(255,255,255,0.9)', border: 'none', borderRadius: '3px', padding: '1px 5px', fontSize: '11px' });
      marker.setLabel(label);
      overlays.push(marker);
    }
  });
  setLayer(name, overlays);
}

// ========== 加载地图包 ==========
async function loadMap(mapId) {
  state.mapId = mapId;
  state.layers.forEach(function (_, name) { clearLayer(name); });
  clearRuntimeMarkers();
  state.staticNodes.clear();
  state.runtimeNodes.clear();
  state.historyLoaded = false;
  state.hexInfoWindow = null;
  clearQuery();
  try {
    var manifest = await api('/api/maps/' + encodeURIComponent(mapId) + '/manifest');
    state.manifest = manifest;
    $('#mineName').textContent = manifest.name || mapId;
    var center = pointWgs(manifest.center);
    state.map.centerAndZoom(center, Number(manifest.suggested_zoom || 17));

    var layerNames = ['boundary', 'hex_grid', 'roads', 'nodes'];
    var layers = await Promise.all(layerNames.map(function (name) {
      return api('/api/maps/' + encodeURIComponent(mapId) + '/layers/' + name);
    }));
    layerNames.slice(0, 3).forEach(function (name, index) { drawGeoJson(name, layers[index]); });
    indexHexes(layers[1]);
    buildStaticNodes(layers[3]);
    renderNodes();
    await refreshRuntime();
    setStatus('地图正常');
    showMessage('');
  } catch (err) {
    setStatus('地图错误');
    showMessage(err.message);
    toast(err.message);
  }
}

function buildStaticNodes(nodesCollection) {
  state.staticNodes.clear();
  (nodesCollection.features || []).forEach(function (feature) {
    var props = feature.properties || {};
    var c = feature.geometry && feature.geometry.coordinates;
    if (!c) return;
    var item = {
      lng: Number(c[0]), lat: Number(c[1]),
      name: nodeDisplayName(props),
      type: props.node_type || props.type || 'node', node_id: props.node_id || '',
      status: props.status || 'open', data: props,
    };
    state.staticNodes.set(item.type + '/' + item.node_id, item);
  });
}

function fillFacSelects() {
  var s1 = $('#facSelStart'), s2 = $('#facSelEnd');
  // 这个函数每次轮询都会被调到。重建 <select> 会关掉用户正打开的选项弹层，
  // 所以内容没变就直接返回，避免每 1.5 秒把下拉框砸了重建一次。
  var signature = state.mapId + '#' + state.nodeList.map(function (node) {
    return node.type + '/' + node.node_id + '|' + node.name;
  }).join(',');
  if (signature === fillFacSelects.signature) return;
  fillFacSelects.signature = signature;

  var oldStart = s1.value, oldEnd = s2.value;
  var options = state.nodeList.map(function (node) {
    var key = node.type + '/' + node.node_id;
    return '<option value="' + escapeHtml(key) + '">' + escapeHtml(node.name) + '</option>';
  }).join('');
  s1.innerHTML = '<option value="">— 起 —</option>' + options;
  s2.innerHTML = '<option value="">— 终 —</option>' + options;
  if (state.nodeList.some(function (node) { return node.type + '/' + node.node_id === oldStart; })) s1.value = oldStart;
  if (state.nodeList.some(function (node) { return node.type + '/' + node.node_id === oldEnd; })) s2.value = oldEnd;
}

async function loadHistoryLayer() {
  if (state.historyLoaded) return;
  setStatus('正在加载建图轨迹');
  try {
    var data = await api('/api/maps/' + encodeURIComponent(state.mapId) + '/layers/history_tracks');
    drawGeoJson('history_tracks', data);
    state.historyLoaded = true;
    setStatus('建图轨迹已加载');
  } catch (err) { toast(err.message); }
}

// ========== 实时数据 ==========
function clearRuntimeMarkers() {
  state.truckMarkers.forEach(function (m) { state.map.removeOverlay(m); });
  state.nodeMarkers.forEach(function (m) { state.map.removeOverlay(m); });
  state.truckMarkers.clear();
  state.nodeMarkers.clear();
}

function nodeIconUrl(nodeType) {
  var map = { loading: 'Loading', unloading: 'Unloading', charging: 'Charging' };
  return 'icon/' + (map[nodeType] || 'Truck') + '.svg';
}

function iconMarker(coordinate, iconUrl, size, text, borderColor) {
  var icon = new BMapGL.Icon(iconUrl, new BMapGL.Size(size, size));
  var marker = new BMapGL.Marker(pointWgs(coordinate), { icon: icon });
  var label = new BMapGL.Label(text, { offset: new BMapGL.Size(0, -(size + 12)) });
  label.setStyle({ color: '#fff', backgroundColor: '#1a1a2e', border: '2px solid ' + borderColor, borderRadius: '4px', padding: '1px 6px', fontSize: '11px', fontWeight: 'bold' });
  marker.setLabel(label);
  marker._mineLabel = label;
  marker._mineLabelText = text;
  state.map.addOverlay(marker);
  return marker;
}

function updateTrucks(trucks) {
  var seen = new Set();
  trucks.forEach(function (truck) {
    var lon = Number(truck.longitude), lat = Number(truck.latitude);
    if (!Number.isFinite(lon) || !Number.isFinite(lat)) return;
    var id = String(truck.truck_id || 'unknown');
    seen.add(id);
    var soc = pickSoc(truck);
    var socColor = soc == null ? '#9e9e9e' : (soc > 70 ? '#28a745' : soc > 40 ? '#ffc107' : '#dc3545');
    var marker = state.truckMarkers.get(id);
    if (!marker) {
      marker = iconMarker([lon, lat], 'icon/Truck.svg', 22, id, socColor);
      state.truckMarkers.set(id, marker);
    } else {
      marker.setPosition(pointWgs([lon, lat]));
      if (marker._mineLabel) marker._mineLabel.setStyle({ border: '2px solid ' + socColor });
    }
    layerVisible('trucks') ? marker.show() : marker.hide();
  });
  state.truckMarkers.forEach(function (marker, id) {
    if (!seen.has(id)) { state.map.removeOverlay(marker); state.truckMarkers.delete(id); }
  });
  renderTruckList(trucks);
}

// 兼容多种电量字段写法（soc / SOC / stateOfCharge / battery）
function pickSoc(obj) {
  if (!obj) return null;
  var value = obj.soc;
  if (value == null) value = obj.SOC;
  if (value == null) value = obj.stateOfCharge;
  if (value == null) value = obj.battery;
  if (value == null || value === '') return null;
  var num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function renderTruckList(trucks) {
  var html = '';
  trucks.forEach(function (t) {
    var lon = Number(t.longitude), lat = Number(t.latitude);
    var hasPos = Number.isFinite(lon) && Number.isFinite(lat);
    var soc = pickSoc(t);
    var speed = t.speed_kmh == null ? 0 : Number(t.speed_kmh);
    var socColor = soc == null ? '#ccc' : (soc > 70 ? '#28a745' : soc > 40 ? '#ffc107' : '#dc3545');
    // fault_code / rtk_status / connection.reason 都来自 MQTT 载荷，由外部设备写入，
    // 进 innerHTML 前必须转义，否则可被注入脚本。
    var fault = t.fault_code || '00000000';
    var faultText = fault === '00000000' ? '' : ' ⚠️' + escapeHtml(String(fault));
    var rtkText = t.rtk_status != null ? 'RTK ' + escapeHtml(String(t.rtk_status)) : 'RTK -';
    var conn = t.connection || {};
    var connText = conn.reason ? ' · ' + escapeHtml(String(conn.reason)) : '';
    html += '<div class="truck-card" data-name="' + escapeHtml(t.truck_id || '') + '">' +
      '<div class="name"><span class="soc-dot" style="background:' + socColor + ';"></span>' + escapeHtml(t.truck_name || t.gateway_name || t.truck_id || '未知车辆') + faultText + connText + '</div>' +
      '<div class="detail">电量 ' + (soc == null ? 'null' : Math.round(soc) + '%') + '</div>' +
      '<div class="detail">速度 ' + speed + ' km/h</div>' +
      '<div class="coord">位置: ' + (hasPos ? '(' + lon.toFixed(4) + ', ' + lat.toFixed(4) + ')' : '-') + '　' + rtkText + '</div>' +
      '</div>';
  });
  $('#truckList').innerHTML = html || '<div style="color:#999;font-size:12px;padding:12px;text-align:center;">当前矿区无实时矿车</div>';
  $('#truckCount').textContent = trucks.length + ' 辆';
  $$('#truckList .truck-card').forEach(function (card) {
    card.addEventListener('click', function () {
      var name = card.getAttribute('data-name');
      var truck = trucks.find(function (t) { return String(t.truck_id) === name; });
      if (truck && Number.isFinite(Number(truck.longitude))) {
        state.map.centerAndZoom(pointWgs([Number(truck.longitude), Number(truck.latitude)]), 18);
      }
    });
  });
}

function updateRuntimeNodes(nodes) {
  state.runtimeNodes.clear();
  nodes.forEach(function (node) {
    var lon = Number(node.longitude), lat = Number(node.latitude);
    if (!Number.isFinite(lon) || !Number.isFinite(lat)) return;
    var type = node.node_type;
    var key = type + '/' + node.node_id;
    state.runtimeNodes.set(key, {
      lng: lon, lat: lat, name: nodeDisplayName(node),
      type: type, node_id: node.node_id, status: node.status || 'open', data: node,
    });
  });
  renderNodes();
}

// 功能区图标（24px）比 10m 的六边形色块大得多，会把色块盖住，
// 所以点击入口同时挂在图标和名字标签上，否则左键很难点中。
function bindFacilityClick(marker, key) {
  function handle(event) {
    if (state.routeMode) return;   // 选点模式下这一点击用于确定起终点
    var record = state.runtimeNodes.get(key) || state.staticNodes.get(key);
    var props = state.hexByNode.get(key) || { type: key.split('/')[0], node_id: key.split('/')[1] };
    state.overlayClickUntil = Date.now() + 250;
    if (event && event.domEvent && event.domEvent.stopPropagation) event.domEvent.stopPropagation();
    openFacilityDetail(props, record ? [record.lng, record.lat] : null);
  }
  marker.addEventListener('click', handle);
  if (marker._mineLabel) marker._mineLabel.addEventListener('click', handle);
}

function renderNodes() {
  var merged = new Map(state.staticNodes);
  state.runtimeNodes.forEach(function (runtime, key) {
    var base = merged.get(key) || {};
    merged.set(key, Object.assign({}, base, runtime, { data: Object.assign({}, base.data || {}, runtime.data || {}) }));
  });
  state.nodeMarkers.forEach(function (marker, key) {
    if (!merged.has(key)) { state.map.removeOverlay(marker); state.nodeMarkers.delete(key); }
  });
  merged.forEach(function (node, key) {
    var color = node.status === 'closed' ? '#c83f49' : (NODE_COLORS[node.type] || '#666');
    var marker = state.nodeMarkers.get(key);
    if (!marker) {
      marker = iconMarker([node.lng, node.lat], nodeIconUrl(node.type), 24, node.name, color);
      bindFacilityClick(marker, key);
      state.nodeMarkers.set(key, marker);
    } else {
      marker.setPosition(pointWgs([node.lng, node.lat]));
      marker._mineLabelText = node.name;
      if (marker._mineLabel) marker._mineLabel.setStyle({ border: '2px solid ' + color });
    }
    applyNodeLabel(marker, state.nodeLabelsVisible);
    marker.show();
  });
  state.nodeList = Array.from(merged.values()).sort(function (a, b) { return a.name.localeCompare(b.name, 'zh-CN'); });
  fillFacSelects();
}

async function refreshRuntime() {
  if (!state.manifest || state.refreshing) return;
  state.refreshing = true;
  try {
    var mine = encodeURIComponent(state.manifest.mine_id || '');
    var payloads = await Promise.all([
      api('/api/runtime/' + mine + '/trucks'),
      api('/api/runtime/' + mine + '/nodes'),
    ]);
    var trucks = payloads[0], nodes = payloads[1];
    updateTrucks(trucks.trucks || []);
    updateRuntimeNodes(nodes.nodes || []);
  } catch (err) { console.warn('实时数据刷新失败', err); }
  finally { state.refreshing = false; }
}

async function refreshMqttStatus() {
  try {
    var status = await api('/api/mqtt/status');
    var dot = $('#connDot'), text = $('#connStatus');
    if (!status.enabled) { dot.className = 'dot off'; text.textContent = 'MQTT未启用'; }
    else if (status.connected) { dot.className = 'dot on'; text.textContent = 'MQTT收发已连接'; }
    else if (status.partially_connected) {
      dot.className = 'dot err';
      text.textContent = status.sub_connected ? 'MQTT仅订阅已连接' : 'MQTT仅发布已连接';
    }
    else { dot.className = 'dot err'; text.textContent = 'MQTT未连接'; }
  } catch (e) {
    $('#connDot').className = 'dot err';
    $('#connStatus').textContent = 'MQTT状态错误';
  }
  $('#updateTime').textContent = '最后更新: ' + new Date().toLocaleTimeString('zh-CN');
}

// ========== 路径查询 ==========
function setQueryPoint(mode, lng, lat, name, autoRun) {
  var point = { lng: lng, lat: lat, name: name };
  if (mode === 'start') { state.qStart = point; $('#sCoord').textContent = lng.toFixed(4) + ', ' + lat.toFixed(4); }
  else { state.qEnd = point; $('#eCoord').textContent = lng.toFixed(4) + ', ' + lat.toFixed(4); }
  state.routeMode = null;
  $$('#qStart,#qEnd').forEach(function (b) { b.style.background = '#fff'; });
  redrawQuery();
  if (autoRun !== false && state.qStart && state.qEnd) runQuery();
}

function redrawQuery() {
  state.qMarkers.forEach(function (m) { state.map.removeOverlay(m); });
  state.qMarkers = [];
  if (state.qPathPoly) { state.map.removeOverlay(state.qPathPoly); state.qPathPoly = null; }
  if (state.qStart) {
    var m1 = new BMapGL.Marker(pointWgs([state.qStart.lng, state.qStart.lat]));
    var l1 = new BMapGL.Label('起点', { offset: new BMapGL.Size(0, -30) });
    l1.setStyle({ color: '#fff', backgroundColor: '#1e88e5', border: 'none', borderRadius: '3px', padding: '2px 6px', fontSize: '12px' });
    m1.setLabel(l1);
    state.map.addOverlay(m1); state.qMarkers.push(m1);
  }
  if (state.qEnd) {
    var m2 = new BMapGL.Marker(pointWgs([state.qEnd.lng, state.qEnd.lat]));
    var l2 = new BMapGL.Label('终点', { offset: new BMapGL.Size(0, -30) });
    l2.setStyle({ color: '#fff', backgroundColor: '#e53935', border: 'none', borderRadius: '3px', padding: '2px 6px', fontSize: '12px' });
    m2.setLabel(l2);
    state.map.addOverlay(m2); state.qMarkers.push(m2);
  }
}

async function runQuery() {
  if (!state.qStart || !state.qEnd || !state.manifest) return;
  try {
    var result = await api('/api/maps/' + encodeURIComponent(state.mapId) + '/route', {
      method: 'POST',
      body: JSON.stringify({
        start: { longitude: state.qStart.lng, latitude: state.qStart.lat },
        end: { longitude: state.qEnd.lng, latitude: state.qEnd.lat },
      }),
    });
    if (state.qPathPoly) state.map.removeOverlay(state.qPathPoly);
    state.qPathPoly = new BMapGL.Polyline(result.path.map(pointWgs), { strokeColor: '#e53935', strokeWeight: 5, strokeOpacity: .9 });
    state.map.addOverlay(state.qPathPoly);
    if (result.path.length > 1) state.map.setViewport(result.path.map(pointWgs), { margins: [80, 80, 80, 80] });

    var d = Number(result.distance_km) * 1000;
    var mins = Number(result.time_min);
    var html = '<div style="font-weight:bold;margin-bottom:3px;">' + escapeHtml((state.qStart.name || '起点')) + ' → ' + escapeHtml((state.qEnd.name || '终点')) + '</div>' +
      '距离: <span class="val">' + (d >= 1000 ? (d / 1000).toFixed(2) + ' km' : d.toFixed(0) + ' m') + '</span><br>' +
      '时间: <span class="val">' + mins.toFixed(1) + ' 分钟</span>';
    var box = $('#resultBox');
    box.innerHTML = html;
    box.style.display = 'block';
    setStatus('路径计算完成');
  } catch (err) {
    setStatus('路径计算失败');
    toast(err.message);
  }
}

function clearQuery() {
  state.qStart = null; state.qEnd = null; state.routeMode = null;
  state.qMarkers.forEach(function (m) { state.map.removeOverlay(m); });
  state.qMarkers = [];
  if (state.qPathPoly) { state.map.removeOverlay(state.qPathPoly); state.qPathPoly = null; }
  $('#sCoord').textContent = '-';
  $('#eCoord').textContent = '-';
  $('#resultBox').style.display = 'none';
  $$('#qStart,#qEnd').forEach(function (b) { b.style.background = '#fff'; });
}

function mapClick(e) {
  if (Date.now() < state.overlayClickUntil) return;   // 这一击在覆盖物上，已由覆盖物处理
  if (!state.routeMode) { closeHexDetail(); return; }
  var point = eventBdPoint(e);
  if (!point) return;
  var wgs = bdToWgs(point.lng, point.lat);
  setQueryPoint(state.routeMode, wgs[0], wgs[1], '地图选点');
}

// ========== 事件绑定 ==========
function setupEvents() {
  $('#menuBtn').addEventListener('click', function (e) {
    e.stopPropagation();
    $('#menuDropdown').classList.toggle('show');
  });
  document.addEventListener('click', function () { $('#menuDropdown').classList.remove('show'); });
  $('#menuHome').addEventListener('click', function () { window.location.href = '/'; });
  $('#menuMap').addEventListener('click', function () { window.location.reload(); });
  $('#menuEditor').addEventListener('click', function () { window.location.href = 'editor.html?map=' + encodeURIComponent(state.mapId || ''); });

  var truckOpen = true;
  $('#truckToggle').addEventListener('click', function () {
    truckOpen = !truckOpen;
    $('#truckPanel').classList.toggle('closed', !truckOpen);
    setTimeout(function () { try { state.map.resize(); } catch (e) {} }, 300);
  });

  $('#mapSelect').addEventListener('change', function () {
    window.location.href = 'map.html?map=' + encodeURIComponent(this.value);
  });

  $$('[data-layer]').forEach(function (input) {
    input.addEventListener('change', function () {
      if (input.dataset.layer === 'history_tracks' && input.checked && !state.historyLoaded) loadHistoryLayer();
      else toggleLayer(input.dataset.layer, input.checked);
    });
  });

  $$('.tools-tab').forEach(function (tab) {
    tab.addEventListener('click', function () {
      $$('.tools-tab').forEach(function (t) { t.classList.remove('active'); });
      $$('.tpage').forEach(function (p) { p.classList.remove('active'); });
      tab.classList.add('active');
      $('#' + tab.dataset.tpage).classList.add('active');
    });
  });

  $('#qStart').addEventListener('click', function () {
    state.routeMode = state.routeMode === 'start' ? null : 'start';
    this.style.background = state.routeMode === 'start' ? '#fff8e1' : '#fff';
    $('#qEnd').style.background = '#fff';
    if (state.routeMode) setStatus('点击地图选择起点');
  });
  $('#qEnd').addEventListener('click', function () {
    state.routeMode = state.routeMode === 'end' ? null : 'end';
    this.style.background = state.routeMode === 'end' ? '#fff8e1' : '#fff';
    $('#qStart').style.background = '#fff';
    if (state.routeMode) setStatus('点击地图选择终点');
  });
  $('#qClear').addEventListener('click', clearQuery);
  $('#qGo').addEventListener('click', function () {
    var sv = $('#facSelStart').value, ev = $('#facSelEnd').value;
    if (!sv || !ev) { setStatus('请选择起终点'); return; }
    if (sv === ev) { setStatus('起终点相同'); return; }
    var sn = state.nodeList.find(function (node) { return node.type + '/' + node.node_id === sv; });
    var en = state.nodeList.find(function (node) { return node.type + '/' + node.node_id === ev; });
    if (!sn || !en) return;
    setQueryPoint('start', sn.lng, sn.lat, sn.name, false);
    setQueryPoint('end', en.lng, en.lat, en.name);
  });
}

// ========== 启动 ==========
async function init() {
  setupEvents();
  try {
    var config = await api('/api/config');
    var mapsPayload = await api('/api/maps');
    state.config = config;
    state.maps = (mapsPayload.maps || []).filter(function (item) { return item.valid; });
    if (!state.maps.length) throw new Error('没有通过校验的地图包，请先运行 build_map.py');

    var select = $('#mapSelect');
    select.innerHTML = state.maps.map(function (item) {
      return '<option value="' + escapeHtml(item.map_id) + '">' + escapeHtml(item.name) + '</option>';
    }).join('');

    var urlParams = new URLSearchParams(window.location.search);
    var preferred = urlParams.get('map');
    if (!preferred || !state.maps.some(function (m) { return m.map_id === preferred; })) {
      preferred = state.maps.some(function (m) { return m.map_id === config.active_map_id; })
        ? config.active_map_id : state.maps[0].map_id;
    }
    select.value = preferred;

    await loadBaiduMap(config.baidu_map_ak);
    initMap();
    await loadMap(preferred);
    refreshMqttStatus();
    setInterval(refreshRuntime, 1500);  // 缩短轮询让矿车移动更平滑
    setInterval(refreshMqttStatus, 3000);
  } catch (err) {
    setStatus('启动失败');
    showMessage(err.message);
    toast(err.message);
  }
}

window.addEventListener('DOMContentLoaded', init);
