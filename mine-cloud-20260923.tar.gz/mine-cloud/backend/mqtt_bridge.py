from __future__ import annotations

import json
import logging
import time
from copy import deepcopy
from datetime import datetime, timezone
from threading import RLock
from typing import Any

from backend.config import Settings
from tools.common import utc_iso

LOGGER = logging.getLogger(__name__)


def event_timestamp(value: Any) -> float | None:
    """解析设备采集时间，用于防止旧定位覆盖新的实时位置。"""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.timestamp()


class MqttBridge:
    def __init__(self, settings: Settings, mine_ids: list[str]):
        self.settings = settings
        self.mine_ids = mine_ids
        self._lock = RLock()
        self._mqtt = None
        self._sub_client = None
        self._pub_client = None
        self._sub_connected = False
        self._pub_connected = False
        self._sub_error: str | None = None
        self._pub_error: str | None = None
        self._message_error: str | None = None
        self._last_message_at: str | None = None
        self._trucks: dict[str, dict[str, dict[str, Any]]] = {}
        self._truck_event_ts: dict[str, dict[str, float]] = {}

    def _make_client(self, client_id: str, username: str, password: str) -> Any:
        client = self._mqtt.Client(
            self._mqtt.CallbackAPIVersion.VERSION2,
            client_id=client_id,
            protocol=self._mqtt.MQTTv311,
        )
        if username:
            client.username_pw_set(username, password)
        if self.settings.mqtt_tls:
            client.tls_set(
                ca_certs=self.settings.mqtt_ca_file or None,
                certfile=self.settings.mqtt_cert_file or None,
                keyfile=self.settings.mqtt_key_file or None,
            )
            client.tls_insecure_set(self.settings.mqtt_tls_insecure)
        client.reconnect_delay_set(min_delay=1, max_delay=30)
        return client

    def start(self) -> None:
        if not self.settings.mqtt_enabled:
            return
        try:
            import paho.mqtt.client as mqtt
        except ImportError:
            self._sub_error = self._pub_error = "缺少 paho-mqtt，请重新执行 setup_local.sh"
            return
        self._mqtt = mqtt
        try:
            # 订阅连接：只接收 Gateway 的卡车遥测与遗嘱消息
            sub = self._make_client(
                self.settings.mqtt_client_id + "_sub",
                self.settings.mqtt_sub_username,
                self.settings.mqtt_sub_password,
            )
            sub.on_connect = self._on_sub_connect
            sub.on_disconnect = self._on_sub_disconnect
            sub.on_message = self._on_message
            sub.connect_async(self.settings.mqtt_host, self.settings.mqtt_port, self.settings.mqtt_keepalive)
            sub.loop_start()
            self._sub_client = sub
            # 发布连接：发布功能区与矩阵
            pub = self._make_client(
                self.settings.mqtt_client_id + "_pub",
                self.settings.mqtt_pub_username,
                self.settings.mqtt_pub_password,
            )
            pub.on_connect = self._on_pub_connect
            pub.on_disconnect = self._on_pub_disconnect
            pub.connect_async(self.settings.mqtt_host, self.settings.mqtt_port, self.settings.mqtt_keepalive)
            pub.loop_start()
            self._pub_client = pub
        except Exception as exc:  # MQTT失败不应阻止静态地图启动
            self._sub_error = self._pub_error = str(exc)
            LOGGER.exception("MQTT 启动失败")

    def stop(self) -> None:
        for client in (self._sub_client, self._pub_client):
            if client:
                try:
                    client.disconnect()
                    client.loop_stop()
                except Exception:
                    pass

    @staticmethod
    def _reason_failed(reason_code: Any) -> bool:
        # paho-mqtt 2.x VERSION2 回调中 reason_code 是 ReasonCode 对象
        return reason_code.is_failure if hasattr(reason_code, "is_failure") else int(reason_code) != 0

    def _on_sub_connect(self, client: Any, userdata: Any, flags: Any, reason_code: Any, properties: Any) -> None:
        success = not self._reason_failed(reason_code)
        with self._lock:
            self._sub_connected = success
            self._sub_error = None if success else f"MQTT 订阅连接失败：{reason_code}"
        if not success:
            return
        for mine_id in self.mine_ids:
            # 只订阅卡车话题。功能区与矩阵以地图包文件为唯一权威，地图端不再订阅自己的 map/#。
            client.subscribe(f"mine/{mine_id}/truck/#", qos=1)

    def _on_pub_connect(self, client: Any, userdata: Any, flags: Any, reason_code: Any, properties: Any) -> None:
        success = not self._reason_failed(reason_code)
        with self._lock:
            self._pub_connected = success
            self._pub_error = None if success else f"MQTT 发布连接失败：{reason_code}"

    def _on_sub_disconnect(self, client: Any, userdata: Any, disconnect_flags: Any, reason_code: Any, properties: Any) -> None:
        with self._lock:
            self._sub_connected = False
            if self._reason_failed(reason_code):
                self._sub_error = f"MQTT 订阅连接已断开：{reason_code}"

    def _on_pub_disconnect(self, client: Any, userdata: Any, disconnect_flags: Any, reason_code: Any, properties: Any) -> None:
        with self._lock:
            self._pub_connected = False
            if self._reason_failed(reason_code):
                self._pub_error = f"MQTT 发布连接已断开：{reason_code}"

    def _on_message(self, client: Any, userdata: Any, message: Any) -> None:
        if not message.payload:
            # 空载荷是 MQTT 清除保留消息的写法，对卡车话题无意义，只记录一次接收时间
            with self._lock:
                self._last_message_at = utc_iso()
            LOGGER.debug("忽略空载荷消息 %s", message.topic)
            return
        try:
            payload = json.loads(message.payload.decode("utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("消息不是 JSON 对象")
            self._store_message(message.topic, payload)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            with self._lock:
                self._message_error = f"忽略无效消息 {message.topic}：{exc}"

    def _store_message(self, topic: str, payload: dict[str, Any]) -> None:
        """只处理卡车话题：遥测 `truck/{id}` 与遗嘱 `truck/{id}/status`。

        功能区与矩阵以地图包文件为唯一权威，不再由 MQTT 回填内存，
        因此这里没有 map/# 分支——地图端只发不收自己的配置话题。
        """
        parts = topic.split("/")
        if len(parts) < 4 or parts[0] != "mine" or parts[2] != "truck":
            return
        if len(parts) == 4:
            kind = "telemetry"
        elif len(parts) == 5 and parts[4] == "status":
            kind = "status"
        else:
            return
        mine_id, truck_id = parts[1], parts[3]
        with self._lock:
            self._last_message_at = utc_iso()
            # SQLite Outbox 补传只用于历史留存，不能倒退实时位置或刷新在线状态。
            if payload.get("replayed") is True:
                return
            incoming_event_ts: float | None = None
            if kind == "telemetry":
                incoming_event_ts = event_timestamp(payload.get("timestamp"))
                previous_event_ts = self._truck_event_ts.get(mine_id, {}).get(truck_id)
                if (
                    previous_event_ts is not None
                    and (incoming_event_ts is None or incoming_event_ts <= previous_event_ts)
                ):
                    return
            record = self._trucks.setdefault(mine_id, {}).setdefault(truck_id, {"truck_id": truck_id})
            if kind == "telemetry":
                record.update(payload)
                # 主题中的 ID 是权威值，避免错误载荷覆盖内部车辆键。
                record["truck_id"] = truck_id
                record.setdefault("fault_code", "00000000")
                record["telemetry_topic"] = topic
                record["online"] = True  # 收到遥测视为在线
                if incoming_event_ts is not None:
                    self._truck_event_ts.setdefault(mine_id, {})[truck_id] = incoming_event_ts
            else:
                record["connection"] = payload
                record["status_topic"] = topic
                # 遗嘱消息：online=false 表示设备已下线/断连
                if isinstance(payload.get("online"), bool):
                    record["online"] = payload["online"]
            record["received_at"] = self._last_message_at
            record["received_ts"] = time.time()

    def publish_node(self, payload: dict[str, Any]) -> str:
        topic = f"mine/{payload['mine_id']}/map/{payload['node_type']}/{payload['node_id']}"
        self._publish(topic, payload, retain=True)
        return topic

    def publish_matrix(self, payload: dict[str, Any]) -> str:
        topic = f"mine/{payload['mine_id']}/map/matrix"
        self._publish(topic, payload, retain=True)
        return topic

    def delete_node(self, mine_id: str, node_type: str, node_id: str) -> str:
        topic = f"mine/{mine_id}/map/{node_type}/{node_id}"
        self._publish_raw(topic, b"", retain=True)
        return topic

    def _publish(self, topic: str, payload: dict[str, Any], retain: bool) -> None:
        self._publish_raw(
            topic,
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
            retain,
        )

    def _publish_raw(self, topic: str, payload: bytes, retain: bool) -> None:
        if not self.settings.mqtt_enabled:
            raise RuntimeError("MQTT 当前未启用")
        if not self._pub_client or not self._pub_connected:
            raise RuntimeError("MQTT 发布连接当前未连接")
        info = self._pub_client.publish(
            topic,
            payload,
            qos=1,
            retain=retain,
        )
        if info.rc != 0:
            raise RuntimeError(f"MQTT 发布失败，返回码 {info.rc}")
        # publish() 返回只表示消息进入客户端队列；QoS 1 必须等 Broker PUBACK，
        # 否则 HTTP 接口会在真正发布失败时仍向操作者报告成功。
        info.wait_for_publish(timeout=self.settings.mqtt_publish_timeout_s)
        if not info.is_published():
            raise RuntimeError("MQTT 发布等待 PUBACK 超时")

    def status(self) -> dict[str, Any]:
        with self._lock:
            errors = [error for error in (self._sub_error, self._pub_error, self._message_error) if error]
            return {
                "enabled": self.settings.mqtt_enabled,
                "connected": self._sub_connected and self._pub_connected,
                "partially_connected": self._sub_connected != self._pub_connected,
                "sub_connected": self._sub_connected,
                "pub_connected": self._pub_connected,
                "host": self.settings.mqtt_host if self.settings.mqtt_enabled else None,
                "port": self.settings.mqtt_port if self.settings.mqtt_enabled else None,
                "subscribed_mines": self.mine_ids,
                "last_message_at": self._last_message_at,
                "last_error": "；".join(errors) if errors else None,
            }

    def trucks(self, mine_id: str, offline_timeout_s: float | None = None) -> list[dict[str, Any]]:
        with self._lock:
            if offline_timeout_s is None:
                offline_timeout_s = self.settings.truck_offline_timeout_s
            cutoff = time.time() - offline_timeout_s
            result = []
            for record in self._trucks.get(mine_id, {}).values():
                # 遗嘱明确离线（online=false）→ 立即从界面隐藏
                if record.get("online") is False:
                    continue
                last_ts = record.get("received_ts", 0)
                # 超过 timeout 未收到任何消息的矿车视为离线，从界面隐藏
                if last_ts > 0 and last_ts < cutoff:
                    continue
                public_record = deepcopy(record)
                public_record.pop("received_ts", None)
                public_record.pop("telemetry_topic", None)
                public_record.pop("status_topic", None)
                result.append(public_record)
            return result
