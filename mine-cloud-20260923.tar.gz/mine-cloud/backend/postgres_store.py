from __future__ import annotations

import hashlib
import json
import logging
from typing import Any

from psycopg_pool import ConnectionPool

from backend.map_store import MapNotFoundError, MapPackageError


LOGGER = logging.getLogger(__name__)
REQUIRED_LAYERS = {
    "boundary",
    "hex_grid",
    "roads",
    "road_graph",
    "nodes",
    "history_tracks",
    "matrix",
}


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


class PostgresMapStore:
    """PostgreSQL-backed map store with the same public read API as MapStore."""

    def __init__(self, database_url: str, min_size: int = 1, max_size: int = 10, timeout_s: float = 10):
        self.pool = ConnectionPool(
            conninfo=database_url,
            min_size=min_size,
            max_size=max_size,
            timeout=timeout_s,
            open=True,
        )
        # Fail during startup rather than serving an application with no usable map store.
        self.pool.wait(timeout=timeout_s)

    def close(self) -> None:
        self.pool.close()

    def discover(self) -> list[dict[str, Any]]:
        with self.pool.connection() as conn:
            rows = conn.execute(
                """
                SELECT m.map_id, m.mine_id, m.name, m.generated_at,
                       array_remove(array_agg(l.layer_name), NULL) AS layers
                FROM maps AS m
                LEFT JOIN map_layers AS l ON l.map_id = m.map_id
                GROUP BY m.map_id, m.mine_id, m.name, m.generated_at
                ORDER BY m.map_id
                """
            ).fetchall()
        result = []
        for map_id, mine_id, name, generated_at, layers in rows:
            present = set(layers or [])
            missing = sorted(REQUIRED_LAYERS - present)
            result.append(
                {
                    "map_id": map_id,
                    "mine_id": mine_id,
                    "name": name,
                    "generated_at": generated_at.isoformat() if generated_at else None,
                    "valid": not missing,
                    "errors": [] if not missing else ["数据库缺少图层：" + "、".join(missing)],
                }
            )
        return result

    def manifest(self, map_id: str) -> dict[str, Any]:
        with self.pool.connection() as conn:
            row = conn.execute(
                "SELECT manifest FROM maps WHERE map_id = %s",
                (map_id,),
            ).fetchone()
        if row is None:
            raise MapNotFoundError(map_id)
        manifest = row[0]
        if not isinstance(manifest, dict):
            raise MapPackageError(f"地图 {map_id} 的 manifest 不是 JSON 对象")
        return manifest

    def layer(self, map_id: str, layer: str) -> Any:
        with self.pool.connection() as conn:
            row = conn.execute(
                "SELECT content FROM map_layers WHERE map_id = %s AND layer_name = %s",
                (map_id, layer),
            ).fetchone()
        if row is None:
            with self.pool.connection() as conn:
                exists = conn.execute("SELECT 1 FROM maps WHERE map_id = %s", (map_id,)).fetchone()
            if exists is None:
                raise MapNotFoundError(map_id)
            raise MapPackageError(f"数据库地图 {map_id} 缺少 {layer} 图层")
        return row[0]

    def graph(self, map_id: str) -> dict[str, Any]:
        graph = self.layer(map_id, "road_graph")
        if not isinstance(graph, dict):
            raise MapPackageError(f"数据库地图 {map_id} 的 road_graph 不是 JSON 对象")
        return graph

    def mine_ids(self) -> list[str]:
        with self.pool.connection() as conn:
            rows = conn.execute("SELECT mine_id FROM maps ORDER BY mine_id").fetchall()
        return [row[0] for row in rows]

    def map_id_for_mine(self, mine_id: str, preferred_map_id: str | None = None) -> str | None:
        if not isinstance(mine_id, str) or not mine_id:
            return None
        with self.pool.connection() as conn:
            rows = conn.execute(
                "SELECT map_id FROM maps WHERE mine_id = %s ORDER BY map_id",
                (mine_id,),
            ).fetchall()
        matches = [row[0] for row in rows]
        if not matches:
            return None
        if preferred_map_id in matches:
            return preferred_map_id
        if len(matches) > 1:
            LOGGER.warning("mine_id %s 对应多个数据库地图：%s", mine_id, ", ".join(matches))
        return matches[0]

    def snapshot_layers(self, conn: Any, map_id: str, for_update: bool = False) -> tuple[int, dict[str, Any], dict[str, Any]]:
        suffix = " FOR UPDATE" if for_update else ""
        row = conn.execute(
            "SELECT revision, manifest FROM maps WHERE map_id = %s" + suffix,
            (map_id,),
        ).fetchone()
        if row is None:
            raise MapNotFoundError(map_id)
        revision, manifest = row
        layer_rows = conn.execute(
            "SELECT layer_name, content FROM map_layers WHERE map_id = %s",
            (map_id,),
        ).fetchall()
        layers = {name: content for name, content in layer_rows}
        missing = REQUIRED_LAYERS - set(layers)
        if missing:
            raise MapPackageError(f"数据库地图 {map_id} 缺少图层：{'、'.join(sorted(missing))}")
        if not isinstance(manifest, dict):
            raise MapPackageError(f"数据库地图 {map_id} 的 manifest 不是 JSON 对象")
        return int(revision), manifest, layers
