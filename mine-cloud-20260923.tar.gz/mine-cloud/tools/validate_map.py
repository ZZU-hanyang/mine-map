#!/usr/bin/env python3
"""校验标准地图数据包，防止后端加载不完整或不一致的数据。"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any, Iterable


REQUIRED_FILE_KEYS = ("boundary", "hex_grid", "roads", "road_graph", "nodes", "history_tracks")
GEOJSON_TYPES = {
    "boundary": {"Polygon", "MultiPolygon"},
    "hex_grid": {"Polygon"},
    "roads": {"LineString", "MultiLineString"},
    "nodes": {"Point"},
    "history_tracks": {"LineString", "MultiLineString"},
}


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"缺少文件：{path.name}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"{path.name} 不是有效 JSON：第 {exc.lineno} 行") from exc


def coordinate_pairs(value: Any) -> Iterable[tuple[float, float]]:
    if isinstance(value, list) and len(value) >= 2 and all(isinstance(item, (int, float)) for item in value[:2]):
        yield float(value[0]), float(value[1])
        return
    if isinstance(value, list):
        for child in value:
            yield from coordinate_pairs(child)


def validate_geojson(name: str, data: Any, errors: list[str]) -> None:
    if not isinstance(data, dict) or data.get("type") != "FeatureCollection":
        errors.append(f"{name} 必须是 GeoJSON FeatureCollection")
        return
    features = data.get("features")
    if not isinstance(features, list):
        errors.append(f"{name}.features 必须是数组")
        return
    allowed = GEOJSON_TYPES[name]
    for index, feature in enumerate(features):
        geometry = feature.get("geometry") if isinstance(feature, dict) else None
        if not isinstance(geometry, dict) or geometry.get("type") not in allowed:
            errors.append(f"{name} 第 {index + 1} 个要素的几何类型不正确")
            continue
        for longitude, latitude in coordinate_pairs(geometry.get("coordinates")):
            if not all(math.isfinite(value) for value in (longitude, latitude)):
                errors.append(f"{name} 第 {index + 1} 个要素包含非数字坐标")
                break
            if not (-180 <= longitude <= 180 and -90 <= latitude <= 90):
                errors.append(f"{name} 第 {index + 1} 个要素包含越界坐标")
                break


def validate_map_package(package_dir: Path) -> list[str]:
    errors: list[str] = []
    manifest = load_json(package_dir / "manifest.json")
    if not isinstance(manifest, dict):
        return ["manifest.json 必须是 JSON 对象"]
    for key in ("schema_version", "map_id", "mine_id", "name", "crs", "files", "counts"):
        if key not in manifest:
            errors.append(f"manifest.json 缺少字段：{key}")
    if manifest.get("crs") != "WGS84":
        errors.append("当前版本只接受 crs=WGS84")
    files = manifest.get("files")
    if not isinstance(files, dict):
        return errors + ["manifest.files 必须是对象"]

    resolved_files: dict[str, Path] = {}
    package_root = package_dir.resolve()
    for key in REQUIRED_FILE_KEYS:
        relative = files.get(key)
        if not isinstance(relative, str) or not relative:
            errors.append(f"manifest.files 缺少 {key}")
            continue
        path = (package_dir / relative).resolve()
        if path != package_root and package_root not in path.parents:
            errors.append(f"{key} 路径越过地图包目录")
            continue
        if not path.is_file():
            errors.append(f"缺少 {key} 文件：{relative}")
            continue
        resolved_files[key] = path

    loaded: dict[str, Any] = {}
    for key, path in resolved_files.items():
        try:
            loaded[key] = load_json(path)
        except ValueError as exc:
            errors.append(str(exc))
    for key in GEOJSON_TYPES:
        if key in loaded:
            validate_geojson(key, loaded[key], errors)

    function_hexes: set[tuple[str, str]] = set()
    function_hex_ids: dict[tuple[str, str], str] = {}
    graph_pairs: set[frozenset[Any]] = set()
    graph_adjacency: dict[str, set[str]] = {}
    graph = loaded.get("road_graph")
    if isinstance(graph, dict):
        nodes = graph.get("nodes")
        edges = graph.get("edges")
        if not isinstance(nodes, list) or not isinstance(edges, list):
            errors.append("road_graph 的 nodes 和 edges 必须是数组")
        else:
            node_ids = {node.get("id") for node in nodes if isinstance(node, dict)}
            if None in node_ids or len(node_ids) != len(nodes):
                errors.append("road_graph 节点 ID 缺失或重复")
            for index, edge in enumerate(edges):
                if not isinstance(edge, dict) or edge.get("from") not in node_ids or edge.get("to") not in node_ids:
                    errors.append(f"road_graph 第 {index + 1} 条边引用了不存在的节点")
                    continue
                if edge.get("from") == edge.get("to"):
                    errors.append(f"road_graph 第 {index + 1} 条边的两端相同")
                pair = frozenset((edge.get("from"), edge.get("to")))
                if pair in graph_pairs:
                    errors.append(f"road_graph 第 {index + 1} 条边与已有道路重复")
                graph_pairs.add(pair)
                graph_adjacency.setdefault(str(edge.get("from")), set()).add(str(edge.get("to")))
                graph_adjacency.setdefault(str(edge.get("to")), set()).add(str(edge.get("from")))
                distance = edge.get("distance_m")
                if not isinstance(distance, (int, float)) or not math.isfinite(float(distance)) or distance <= 0:
                    errors.append(f"road_graph 第 {index + 1} 条边 distance_m 必须大于 0")
                time_stats = edge.get("time_stats")
                if time_stats is not None:
                    if not isinstance(time_stats, dict) or not time_stats:
                        errors.append(f"road_graph 第 {index + 1} 条边 time_stats 必须是非空对象")
                    else:
                        for direction, stats in time_stats.items():
                            if direction not in {"from_to", "to_from"} or not isinstance(stats, dict):
                                errors.append(f"road_graph 第 {index + 1} 条边包含无效方向时间统计")
                                continue
                            sample_count = stats.get("sample_count")
                            if not isinstance(sample_count, int) or isinstance(sample_count, bool) or sample_count <= 0:
                                errors.append(f"road_graph 第 {index + 1} 条边 {direction}.sample_count 必须为正整数")
                            for field in ("median_time_s", "p75_time_s", "median_speed_kmh"):
                                value = stats.get(field)
                                if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value)) or value <= 0:
                                    errors.append(f"road_graph 第 {index + 1} 条边 {direction}.{field} 必须大于 0")

            hex_features = (loaded.get("hex_grid") or {}).get("features", [])
            hex_ids = {
                (feature.get("properties") or {}).get("hex_id")
                for feature in hex_features
                if isinstance(feature, dict)
            }
            if None in hex_ids or len(hex_ids) != len(hex_features):
                errors.append("hex_grid 的 hex_id 缺失或重复")
            elif hex_ids != node_ids:
                errors.append("hex_grid 六边形与 road_graph 节点不一致")
            for index, feature in enumerate(hex_features):
                props = feature.get("properties") if isinstance(feature, dict) else None
                hex_type = (props or {}).get("type")
                if hex_type not in {"road", "loading", "unloading", "charging"}:
                    errors.append(f"hex_grid 第 {index + 1} 个六边形缺少有效 type")
                    continue
                if hex_type != "road":
                    node_id = (props or {}).get("node_id")
                    if not isinstance(node_id, str) or not node_id:
                        errors.append(f"hex_grid 第 {index + 1} 个功能区缺少 node_id")
                    elif (hex_type, node_id) in function_hexes:
                        errors.append(f"hex_grid 第 {index + 1} 个功能区 node_id 重复")
                    else:
                        function_hexes.add((hex_type, node_id))
                        function_hex_ids[(hex_type, node_id)] = str((props or {}).get("hex_id"))
    elif "road_graph" in loaded:
        errors.append("road_graph 必须是 JSON 对象")

    roads = loaded.get("roads")
    if isinstance(roads, dict) and isinstance(graph, dict):
        if len(roads.get("features", [])) != len(graph.get("edges", [])):
            errors.append("roads 要素数量与 road_graph 边数量不一致")
        road_pairs: set[frozenset[Any]] = set()
        for index, feature in enumerate(roads.get("features", [])):
            props = feature.get("properties") if isinstance(feature, dict) else None
            start, end = (props or {}).get("from"), (props or {}).get("to")
            if not start or not end:
                errors.append(f"roads 第 {index + 1} 个要素缺少 from/to")
                continue
            road_pairs.add(frozenset((start, end)))
        if road_pairs != graph_pairs:
            errors.append("roads 要素与 road_graph 道路边不一致")

    nodes_layer = loaded.get("nodes")
    if isinstance(nodes_layer, dict):
        seen_nodes = set()
        for index, feature in enumerate(nodes_layer.get("features", [])):
            props = feature.get("properties") if isinstance(feature, dict) else None
            node_type = (props or {}).get("node_type") or (props or {}).get("type")
            node_id = (props or {}).get("node_id")
            if node_type not in {"loading", "unloading", "charging"} or not isinstance(node_id, str) or not node_id:
                errors.append(f"nodes 第 {index + 1} 个要素缺少有效 node_type/node_id")
                continue
            key = (node_type, node_id)
            if key in seen_nodes:
                errors.append(f"nodes 第 {index + 1} 个功能区 ID 重复")
            seen_nodes.add(key)
        for key in function_hexes:
            if key not in seen_nodes:
                errors.append(f"功能区色块 {key[0]}/{key[1]} 在 nodes.geojson 中不存在")
        for key in seen_nodes:
            if key not in function_hexes:
                errors.append(f"nodes 功能区 {key[0]}/{key[1]} 没有对应的功能区色块")

    matrix_relative = files.get("matrix")
    if matrix_relative is not None:
        if not isinstance(matrix_relative, str) or not matrix_relative:
            errors.append("manifest.files.matrix 必须是文件路径")
        else:
            matrix_path = (package_dir / matrix_relative).resolve()
            if package_root not in matrix_path.parents or not matrix_path.is_file():
                errors.append("matrix 文件不存在或路径越界")
            else:
                try:
                    matrix_payload = load_json(matrix_path)
                    matrix = matrix_payload.get("matrix") if isinstance(matrix_payload, dict) else None
                    semantics = matrix_payload.get("semantics") if isinstance(matrix_payload, dict) else None
                    row_ids = matrix_payload.get("row_node_ids") if isinstance(matrix_payload, dict) else None
                    column_ids = matrix_payload.get("column_node_ids") if isinstance(matrix_payload, dict) else None
                    if not isinstance(matrix, list):
                        errors.append("matrix 必须是二维数组")
                    elif semantics != "loading_unloading_match":
                        errors.append("matrix.semantics 必须是 loading_unloading_match")
                    elif not isinstance(row_ids, list) or not isinstance(column_ids, list):
                        errors.append("matrix 必须包含 row_node_ids 和 column_node_ids")
                    else:
                        expected_rows = sorted(node_id for node_type, node_id in function_hexes if node_type == "loading")
                        expected_columns = sorted(node_id for node_type, node_id in function_hexes if node_type == "unloading")
                        if row_ids != expected_rows or column_ids != expected_columns:
                            errors.append("matrix 行列节点 ID 与功能区色块不一致")
                        if len(matrix) != len(row_ids):
                            errors.append("matrix 行数与 row_node_ids 数量不一致")
                        for row_index, row in enumerate(matrix):
                            if not isinstance(row, list) or len(row) != len(column_ids):
                                errors.append(f"matrix 第 {row_index + 1} 行列数与 column_node_ids 数量不一致")
                            elif any(value not in (0, 1) for value in row):
                                errors.append("matrix 中只能包含 0 或 1")
                            else:
                                for column_index, value in enumerate(row):
                                    if value != 1 or row_index >= len(row_ids) or column_index >= len(column_ids):
                                        continue
                                    source = function_hex_ids.get(("loading", row_ids[row_index]))
                                    target = function_hex_ids.get(("unloading", column_ids[column_index]))
                                    if source and target and not graph_reachable(source, target, graph_adjacency):
                                        errors.append(
                                            f"匹配关系 {row_ids[row_index]} → {column_ids[column_index]} 在路网上不可达"
                                        )
                except ValueError as exc:
                    errors.append(str(exc))

    counts = manifest.get("counts") if isinstance(manifest.get("counts"), dict) else {}
    expected_counts = {
        "hexagons": len((loaded.get("hex_grid") or {}).get("features", [])),
        "road_edges": len((graph or {}).get("edges", [])) if isinstance(graph, dict) else 0,
        "static_nodes": len((loaded.get("nodes") or {}).get("features", [])),
    }
    for key, actual in expected_counts.items():
        if key in counts and counts[key] != actual:
            errors.append(f"manifest.counts.{key}={counts[key]}，实际为 {actual}")
    return errors


def graph_reachable(source: str, target: str, adjacency: dict[str, set[str]]) -> bool:
    if source == target:
        return True
    pending = [source]
    visited = {source}
    while pending:
        current = pending.pop()
        for neighbor in adjacency.get(current, set()):
            if neighbor == target:
                return True
            if neighbor not in visited:
                visited.add(neighbor)
                pending.append(neighbor)
    return False


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="校验地图数据包")
    parser.add_argument("package", type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        errors = validate_map_package(args.package.resolve())
    except (OSError, ValueError) as exc:
        errors = [str(exc)]
    if errors:
        print("地图包校验失败：", file=sys.stderr)
        for error in errors:
            print(f"  - {error}", file=sys.stderr)
        return 1
    print(f"地图包校验通过：{args.package.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
