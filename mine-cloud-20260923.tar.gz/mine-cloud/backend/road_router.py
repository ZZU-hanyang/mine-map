from __future__ import annotations

import heapq
import math
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

EARTH_RADIUS_M = 6_371_000.0
HISTORY_PRIOR_SAMPLES = 20.0


@dataclass(frozen=True)
class RouteEdge:
    target: str
    distance_m: float
    median_time_s: float | None = None
    sample_count: int = 0

    def estimated_time_s(self, fallback_speed_kmh: float) -> tuple[float, bool]:
        fallback = self.distance_m / (fallback_speed_kmh * 1000 / 3600)
        if self.median_time_s is None or self.median_time_s <= 0 or self.sample_count <= 0:
            return fallback, False
        # 少量样本向15 km/h先验收缩，避免第一个异常样本支配路径选择。
        historical_weight = self.sample_count / (self.sample_count + HISTORY_PRIOR_SAMPLES)
        return self.median_time_s * historical_weight + fallback * (1 - historical_weight), True


def haversine_m(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    lat1_r, lat2_r = math.radians(lat1), math.radians(lat2)
    delta_lat = lat2_r - lat1_r
    delta_lon = math.radians(lon2 - lon1)
    value = math.sin(delta_lat / 2) ** 2 + math.cos(lat1_r) * math.cos(lat2_r) * math.sin(delta_lon / 2) ** 2
    return 2 * EARTH_RADIUS_M * math.atan2(math.sqrt(value), math.sqrt(max(0.0, 1 - value)))


class RoadRouter:
    def __init__(self, graph: dict[str, Any]):
        self.nodes = {node["id"]: node for node in graph.get("nodes", [])}
        self.adjacency: dict[str, list[RouteEdge]] = defaultdict(list)
        for edge in graph.get("edges", []):
            start, end = edge.get("from"), edge.get("to")
            if start not in self.nodes or end not in self.nodes:
                continue
            distance = float(edge.get("distance_m", 0))
            if distance <= 0:
                continue
            stats = edge.get("time_stats") if isinstance(edge.get("time_stats"), dict) else {}
            forward = stats.get("from_to") if isinstance(stats.get("from_to"), dict) else {}
            reverse = stats.get("to_from") if isinstance(stats.get("to_from"), dict) else {}
            self.adjacency[start].append(self._route_edge(end, distance, forward))
            self.adjacency[end].append(self._route_edge(start, distance, reverse))

    @staticmethod
    def _route_edge(target: str, distance_m: float, stats: dict[str, Any]) -> RouteEdge:
        try:
            median_time = float(stats.get("median_time_s"))
            sample_count = int(stats.get("sample_count", 0))
        except (TypeError, ValueError):
            median_time, sample_count = None, 0
        if median_time is not None and (not math.isfinite(median_time) or median_time <= 0):
            median_time = None
        return RouteEdge(target, distance_m, median_time, max(0, sample_count))

    def nearest(self, longitude: float, latitude: float, maximum_m: float = 120) -> tuple[str, float] | None:
        best: tuple[str, float] | None = None
        for node_id, node in self.nodes.items():
            distance = haversine_m(longitude, latitude, node["longitude"], node["latitude"])
            if best is None or distance < best[1]:
                best = node_id, distance
        return best if best and best[1] <= maximum_m else None

    def route(
        self,
        start: tuple[float, float],
        end: tuple[float, float],
        speed_kmh: float = 15,
        maximum_snap_m: float = 120,
    ) -> dict[str, Any]:
        # 有历史统计时按方向使用历史时间；缺失边和吸附距离按服务端默认车速。
        if not math.isfinite(speed_kmh) or speed_kmh <= 0:
            raise ValueError("speed_kmh 必须是大于 0 的有限数字")
        start_node = self.nearest(start[0], start[1], maximum_snap_m)
        end_node = self.nearest(end[0], end[1], maximum_snap_m)
        if not start_node:
            raise ValueError("起点距离道路过远")
        if not end_node:
            raise ValueError("终点距离道路过远")
        source, target = start_node[0], end_node[0]
        times = {source: 0.0}
        previous: dict[str, str] = {}
        queue = [(0.0, source)]
        while queue:
            elapsed, current = heapq.heappop(queue)
            if elapsed != times.get(current):
                continue
            if current == target:
                break
            for edge in self.adjacency.get(current, []):
                edge_time, _ = edge.estimated_time_s(speed_kmh)
                candidate = elapsed + edge_time
                if candidate < times.get(edge.target, float("inf")):
                    times[edge.target] = candidate
                    previous[edge.target] = current
                    heapq.heappush(queue, (candidate, edge.target))
        if target not in times:
            raise ValueError("起点与终点之间没有连通道路")
        node_path = [target]
        while node_path[-1] != source:
            node_path.append(previous[node_path[-1]])
        node_path.reverse()
        coordinates = [[self.nodes[node]["longitude"], self.nodes[node]["latitude"]] for node in node_path]
        road_distance = 0.0
        road_time_s = 0.0
        historical_distance = 0.0
        historical_edges = 0
        fallback_edges = 0
        for current, neighbor in zip(node_path, node_path[1:]):
            edge = next(item for item in self.adjacency[current] if item.target == neighbor)
            edge_time, uses_history = edge.estimated_time_s(speed_kmh)
            road_distance += edge.distance_m
            road_time_s += edge_time
            if uses_history:
                historical_edges += 1
                historical_distance += edge.distance_m
            else:
                fallback_edges += 1
        total_distance = road_distance + start_node[1] + end_node[1]
        snap_time_s = (start_node[1] + end_node[1]) / (speed_kmh * 1000 / 3600)
        total_time_s = road_time_s + snap_time_s
        effective_speed = total_distance / total_time_s * 3.6 if total_time_s > 0 else speed_kmh
        historical_coverage = historical_distance / road_distance if road_distance > 0 else 0.0
        return {
            "distance_m": round(total_distance, 1),
            "distance_km": round(total_distance / 1000, 3),
            "time_min": round(total_time_s / 60, 1),
            "speed_kmh": round(effective_speed, 2),
            "fallback_speed_kmh": speed_kmh,
            "eta_method": "historical_blend" if historical_edges else "fixed_speed",
            "historical_edge_count": historical_edges,
            "fallback_edge_count": fallback_edges,
            "historical_coverage": round(historical_coverage, 3),
            "start_snap_m": round(start_node[1], 1),
            "end_snap_m": round(end_node[1], 1),
            "path": coordinates,
        }
