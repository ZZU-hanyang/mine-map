#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

if [ ! -x .venv/bin/gunicorn ]; then
  echo "请先创建 .venv 并安装 requirements.txt" >&2
  exit 1
fi
CONFIG_FILE="${ENV_FILE:-.env}"
if [ ! -f "$CONFIG_FILE" ]; then
  echo "缺少生产配置 $CONFIG_FILE" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1091
source "$CONFIG_FILE"
set +a
unset PYTHONPATH

# MQTT 实时状态目前保存在进程内，因此固定一个 worker，并用线程处理并发 HTTP。
exec .venv/bin/gunicorn \
  --workers 1 \
  --threads "${WEB_THREADS:-8}" \
  --bind "${APP_HOST:-127.0.0.1}:${APP_PORT:-8000}" \
  --timeout 60 \
  --access-logfile - \
  --error-logfile - \
  'backend.app:create_app()'
