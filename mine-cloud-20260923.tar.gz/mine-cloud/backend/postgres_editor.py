from __future__ import annotations

import json
import tempfile
from copy import deepcopy
from pathlib import Path
from typing import Any

from psycopg.types.json import Jsonb

from backend.map_editor import MapEditor, MapRevisionConflict
from backend.postgres_store import PostgresMapStore, canonical_sha256
from backend.validators import MATRIX_SEMANTICS
from tools.common import utc_iso
from tools.validate_map import validate_map_package


class PostgresMapEditor(MapEditor):
    """Apply existing editor operations and persist all affected layers atomically."""

    def __init__(self, store: PostgresMapStore):
        # File recovery is intentionally skipped: PostgreSQL transactions provide atomicity.
        self.store = store

    @staticmethod
    def _snapshot_payload(revision: int, manifest: dict[str, Any], layers: dict[str, Any]) -> dict[str, Any]:
        matrix = layers["matrix"]
        return {
            "revision": str(revision),
            "manifest": deepcopy(manifest),
            "hex_grid": deepcopy(layers["hex_grid"]),
            "road_graph": deepcopy(layers["road_graph"]),
            "nodes": deepcopy(layers["nodes"]),
            "matrix": deepcopy(matrix.get("matrix", matrix)),
            "matrix_row_node_ids": deepcopy(matrix.get("row_node_ids", [])),
            "matrix_column_node_ids": deepcopy(matrix.get("column_node_ids", [])),
            "matrix_source": "postgres",
        }

    def snapshot(self, map_id: str) -> dict[str, Any]:
        with self.store.pool.connection() as conn:
            revision, manifest, layers = self.store.snapshot_layers(conn, map_id)
        return self._snapshot_payload(revision, manifest, layers)

    def commit(self, map_id: str, base_revision: str, operations: list[Any], note: str = "") -> dict[str, Any]:
        if not isinstance(base_revision, str) or not base_revision:
            raise ValueError("缺少地图 revision，请重新加载编辑页")
        if not isinstance(operations, list) or not operations:
            raise ValueError("没有待保存的地图修改")
        if len(operations) > 500:
            raise ValueError("一次最多提交 500 个编辑操作")
        note = str(note or "").strip()[:200]

        with self.store.pool.connection() as conn:
            revision, manifest, layers = self.store.snapshot_layers(conn, map_id, for_update=True)
            if str(revision) != base_revision:
                raise MapRevisionConflict("地图已被其他人修改，请重新加载后再编辑")

            manifest = deepcopy(manifest)
            hex_grid = deepcopy(layers["hex_grid"])
            graph = deepcopy(layers["road_graph"])
            nodes = deepcopy(layers["nodes"])
            matrix = deepcopy(layers.get("matrix")) or {
                "semantics": MATRIX_SEMANTICS,
                "row_node_ids": [],
                "column_node_ids": [],
                "matrix": [],
            }

            self._normalize_hex_types(hex_grid)
            mqtt_actions: list[dict[str, Any]] = []
            for index, operation in enumerate(operations):
                if not isinstance(operation, dict):
                    raise ValueError(f"第 {index + 1} 个编辑操作必须是对象")
                self._apply_operation(manifest, hex_grid, graph, nodes, matrix, operation, mqtt_actions)

            aligned_matrix, matrix_changed = self._aligned_matrix(matrix, hex_grid, manifest["mine_id"])
            if matrix_changed:
                matrix = aligned_matrix
                mqtt_actions = [action for action in mqtt_actions if action.get("action") != "set_matrix"]
                mqtt_actions.append({"action": "set_matrix", "payload": deepcopy(aligned_matrix)})

            self._check_graph_matches_hexes(hex_grid, graph)
            roads = self._roads_from_graph(graph)
            new_revision = revision + 1
            manifest.setdefault("files", {})["matrix"] = "matrix.json"
            manifest.setdefault("counts", {})["hexagons"] = len(hex_grid["features"])
            manifest["counts"]["road_edges"] = len(graph["edges"])
            manifest["counts"]["static_nodes"] = len(nodes["features"])
            manifest["edited_at"] = utc_iso()
            manifest["editor_revision"] = new_revision
            manifest["last_edit_note"] = note
            self._update_bounds(manifest, hex_grid)

            layers.update(
                {
                    "hex_grid": hex_grid,
                    "roads": roads,
                    "road_graph": graph,
                    "nodes": nodes,
                    "matrix": matrix,
                }
            )
            self._validate_database_map(manifest, layers)

            conn.execute(
                """
                UPDATE maps
                SET revision = %s,
                    name = %s,
                    manifest = %s,
                    updated_at = now()
                WHERE map_id = %s
                """,
                (new_revision, str(manifest.get("name") or map_id), Jsonb(manifest), map_id),
            )
            for layer_name in ("hex_grid", "roads", "road_graph", "nodes", "matrix"):
                content = layers[layer_name]
                conn.execute(
                    """
                    UPDATE map_layers
                    SET content = %s,
                        content_sha256 = %s,
                        updated_at = now()
                    WHERE map_id = %s AND layer_name = %s
                    """,
                    (Jsonb(content), canonical_sha256(content), map_id, layer_name),
                )

        result = self._snapshot_payload(new_revision, manifest, layers)
        result.update({"ok": True, "mqtt_actions": mqtt_actions})
        return result

    @staticmethod
    def _validate_database_map(manifest: dict[str, Any], layers: dict[str, Any]) -> None:
        files = manifest.get("files")
        if not isinstance(files, dict):
            raise ValueError("manifest 缺少 files 对象")
        with tempfile.TemporaryDirectory(prefix="mine-map-db-validate-") as raw_directory:
            directory = Path(raw_directory)
            (directory / "manifest.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            for layer_name, content in layers.items():
                relative = files.get(layer_name)
                if not isinstance(relative, str) or not relative:
                    raise ValueError(f"manifest 缺少 {layer_name} 文件声明")
                path = (directory / relative).resolve()
                if directory != path and directory not in path.parents:
                    raise ValueError(f"{layer_name} 文件路径越界")
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(content, ensure_ascii=False) + "\n", encoding="utf-8")
            errors = validate_map_package(directory)
            if errors:
                raise ValueError("地图修改未通过校验：" + "；".join(errors))
