# 矿区电子地图 HTTP API

供同一台服务器上的其他系统调用。本文档描述当前实现（无鉴权、无版本前缀）。

- **Base URL**：`http://127.0.0.1:8000`（端口来自 `.env` 的 `APP_PORT`）
- **数据格式**：请求与响应均为 JSON，`Content-Type: application/json`
- **坐标系**：所有经纬度都是 **WGS84**（不是百度/高德的 GCJ02、BD09）
- **鉴权**：当前**没有任何鉴权**。请让调用方走回环地址或内网，不要直接暴露到公网

> 与 MQTT 的分工：**拉取当前状态用 HTTP，接收变更通知用 MQTT**。
> MQTT 话题清单见本文末尾，详细约定见 `docs/MQTT_TOPICS.md`。

---

## 1. 地图与基础信息

### GET `/api/health`

健康检查。用于探活。

```json
{
  "ok": true,
  "maps": 3,
  "valid_maps": 3,
  "mqtt": { "enabled": true, "connected": true, "...": "见 /api/mqtt/status" }
}
```

### GET `/api/maps`

列出所有地图包。

```json
{
  "active_map_id": "mine-a",
  "maps": [
    {
      "map_id": "mine-a",
      "mine_id": "mine-a",
      "name": "月山矿区",
      "generated_at": "2026-09-10T09:11:07.620Z",
      "valid": true,
      "errors": []
    }
  ]
}
```

`valid: false` 的地图包不可用，`errors` 里是校验失败原因。

### GET `/api/maps/{map_id}/manifest`

地图包元信息。`editor_revision` 是全系统通用的版本号（见第 4 节）。

```json
{
  "map_id": "mine-a",
  "mine_id": "mine-a",
  "name": "月山矿区",
  "crs": "WGS84",
  "center": [118.03897471, 24.75217399],
  "bounds": [118.0328, 24.2956, 118.0451, 24.3087],
  "counts": { "hexagons": 839, "road_edges": 1507, "static_nodes": 15 },
  "build_parameters": { "hex_size_m": 10.0 },
  "editor_revision": 11,
  "edited_at": "2026-09-14T04:33:41.383Z"
}
```

### GET `/api/maps/{map_id}/layers/{layer}`

取原始 GeoJSON 图层。`layer` 只能是 `boundary`、`hex_grid`、`roads`、`nodes`、`history_tracks`。

`history_tracks` 体积大（mine-a 约 3.9 MB），按需加载。**注意：`matrix` 不在允许列表内**，请用第 3 节的接口。

---

## 2. 实时车辆

### GET `/api/runtime/{mine_id}/trucks`

当前在线的矿车。**数据只在内存里，服务重启即清空**，且没有历史记录。

```json
{
  "trucks": [
    {
      "truck_id": "truck_001",
      "truck_name": "1号矿车",
      "timestamp": "2026-09-16T05:00:00.000Z",
      "longitude": 118.0371,
      "latitude": 24.2978,
      "altitude": 84.4,
      "speed_kmh": 12.37,
      "soc": 86,
      "rtk_status": 4,
      "fault_code": "00000000",
      "online": true,
      "received_at": "2026-09-16T05:00:01.113Z",
      "connection": { "online": true, "reason": "running" }
    }
  ]
}
```

**字段说明**

| 字段 | 说明 |
|---|---|
| `soc` | 电量百分比 0～100，可能为 `null` |
| `fault_code` | 8 位按位故障码，`"00000000"` 表示正常 |
| `rtk_status` | RTK 定位状态，1/4/5 为固定解 |
| `online` | 是否在线 |
| `connection` | 来自遗嘱消息的原始内容，`reason` 是下线原因 |

**重要：哪些车会出现在列表里**

- 收到遥测的车辆 → 在线
- 收到 `online: false` 的遗嘱消息 → **立即从列表移除**
- **默认超过 45 秒没有收到任何消息 → 视为离线并从列表移除**（可通过 `TRUCK_OFFLINE_TIMEOUT_S` 配置）

所以列表为空只代表"当前没有在线的车"，不代表接口故障。

---

## 3. 功能区与装卸匹配矩阵（地图端发布内容）

这两个接口返回的就是地图端发布到 MQTT `mine/{mine_id}/map/#` 的那份内容，
只是换成 HTTP 拉取，**不需要订阅 MQTT**。

数据来源是地图包文件，**不是 MQTT 内存副本**，因此接口语义确定（不依赖 MQTT 连接状态），
且与监控页界面显示的内容完全一致。

### GET `/api/runtime/{mine_id}/nodes`

```json
{
  "map_id": "mine-a",
  "revision": 11,
  "nodes": [
    {
      "node_type": "charging",
      "node_id": "charging_001",
      "longitude": 118.03718007,
      "latitude": 24.29781617,
      "altitude": 0.0,
      "servers": 9,
      "max_queue": 7,
      "average_time_min": 4.0,
      "priority": 6,
      "status": "open",
      "timestamp": "2026-09-01T01:53:17.244Z"
    }
  ]
}
```

| 字段 | 说明 |
|---|---|
| `node_type` | `loading` 装货区 / `unloading` 卸货区 / `charging` 充电区 |
| `status` | `open` 开放 / `closed` 已关闭 |
| `servers` | 服务台数 |
| `max_queue` | 最大排队数 |
| `average_time_min` | 平均服务耗时（分钟） |
| `priority` | 优先级 |

### GET `/api/runtime/{mine_id}/matrix`

装货点与卸货点的业务匹配关系，`1` 表示已匹配。它不代表道路通行权限；道路是否可达应通过路网计算。

```json
{
  "map_id": "mine-a",
  "revision": 11,
  "matrix": {
    "mine_id": "mine-a",
    "semantics": "loading_unloading_match",
    "row_node_ids": ["loading_001", "loading_002"],
    "column_node_ids": ["unloading_001", "unloading_002", "unloading_003"],
    "matrix": [[1, 1, 0], [0, 1, 1]],
    "timestamp": "2026-09-14T04:28:04.842Z"
  }
}
```

`matrix[i][j]` 对应 `row_node_ids[i]` → `column_node_ids[j]`。

### 关于未知 mine_id

**未知的 `mine_id` 返回 `200`，不是 `404`**：

```json
{ "map_id": null, "revision": null, "nodes": [] }
```

这样设计的目的是：前端和调用方常常用 `Promise.all` 同时请求多个接口，
一次 404 会把同批次的其他请求结果一起丢掉。

---

## 4. 版本号 revision

`nodes`、`matrix` 接口以及 MQTT 发布的消息都带 `revision`，
来源是地图包的 `manifest.editor_revision`，**每次编辑页提交 +1**。

用途：

- 判断手上的数据是不是最新的：比 `revision` 大小，小的就是旧的
- 增量同步：先拉一次全量，之后只关心 `revision` 是否变化
- 对账：HTTP 和 MQTT 两条通道拿到的 `revision` 应当一致

`revision` 可能为 `null`（地图包缺失或损坏），此时按"无版本信息"处理，不要当成 0。

---

## 5. 两点到达时间

### POST `/api/maps/{map_id}/route`

请求体**只有起点和终点**，不接受速度参数。

```json
{
  "start": { "longitude": 118.0350438, "latitude": 24.2974115 },
  "end":   { "longitude": 118.0362401, "latitude": 24.2979511 }
}
```

响应：

```json
{
  "distance_m": 329.1,
  "distance_km": 0.329,
  "time_min": 1.3,
  "speed_kmh": 15.0,
  "start_snap_m": 0.0,
  "end_snap_m": 0.0,
  "path": [[118.03504376, 24.29741148], [118.03512926, 24.29727658]]
}
```

`path` 是按顺序排列的途经节点坐标（上例共 20 个点），可以直接连线画路径。

| 字段 | 说明 |
|---|---|
| `distance_m` / `distance_km` | 路径总长度（含吸附段） |
| `time_min` | 预计到达时间（分钟） |
| `speed_kmh` | 按最终距离和预计时间折算的有效平均速度 |
| `fallback_speed_kmh` | 缺少历史统计时使用的默认速度 |
| `eta_method` | `historical_blend` 或 `fixed_speed` |
| `historical_coverage` | 所选道路中有历史统计的距离比例，范围0～1 |
| `historical_edge_count` / `fallback_edge_count` | 使用历史统计和默认速度的道路边数量 |
| `start_snap_m` / `end_snap_m` | 起/终点吸附到最近道路节点的距离 |
| `path` | 途经节点经纬度数组，可直接画线 |

### 算法

```
1. 起终点各自吸附到路网最近的六边形节点（Haversine 取最近，超过 120m 报错）
2. 每条道路边按行驶方向读取历史中位通行时间；按样本量与默认速度平滑融合
3. 没有历史统计的边按 `distance_m ÷ DEFAULT_SPEED_KMH` 计算
4. 在路网上以预计通行秒数为边权运行 Dijkstra，选择预计用时最短路径
5. 起终点吸附距离按默认速度计时，再与道路时间相加
```

历史样本权重为 `sample_count ÷ (sample_count + 20)`；样本较少时结果更接近默认速度，样本充足时更接近历史中位时间。`.env` 的 `DEFAULT_SPEED_KMH` 默认为 `15`，旧地图、人工新增道路和没有历史样本的方向都自动使用该值。调用方传入速度参数仍会被忽略。

预计时间不包含：

- 加减速
- 装货 / 卸货排队时间
- 坡度、载重、路面状况
- 功能区的 `average_time_min` 也不参与这个计算

### 注意吸附距离

`start_snap_m` / `end_snap_m` **会计入 `distance_m` 和 `time_min`**。
从功能区坐标发起查询时两者为 0；在图上随手选点时，每个点最多额外增加 120m 直线距离。
如果你需要"纯路径长度"，用 `distance_m - start_snap_m - end_snap_m`。

### 错误

| HTTP | 场景 |
|---|---|
| 400 | 缺 `start`/`end`、经纬度非法或越界、`start` 距离道路超过 120m、起终点之间没有连通道路 |
| 404 | `map_id` 不存在 |
| 422 | 地图包校验不通过 |

---

## 6. 其他接口

| 接口 | 用途 |
|---|---|
| `GET /api/config` | 前端启动配置（含百度 AK），不建议对外 |
| `GET /api/mqtt/status` | MQTT 连接状态，可用于监控告警 |
| `POST /api/mqtt/nodes` | 向 MQTT 发布一条功能区配置（写入通道） |
| `POST /api/mqtt/matrix` | 向 MQTT 发布装卸匹配矩阵（写入通道） |
| `GET /api/maps/{map_id}/editor` | 编辑页全量快照，体积大，仅供编辑页使用 |
| `POST /api/maps/{map_id}/editor/commit` | **写入通道**：提交地图编辑（带 revision 冲突检测和整包校验），可选同时发布 MQTT |

`POST /api/mqtt/*` 会把消息发布到 broker，**会覆盖外部订阅方看到的内容**，
对外提供前请先加鉴权。

### 通用错误码

| HTTP | 含义 |
|---|---|
| 400 | 请求体不是 JSON 对象，或字段不合法（`validate_node` / `validate_matrix` 的校验失败） |
| 404 | `map_id` / `mine_id` 不存在，或 `layers` 的图层名不在允许列表内 |
| 409 | 编辑页 revision 冲突（`code: "revision_conflict"`），仅在编辑提交时出现 |
| 422 | 地图包存在但未通过校验，`error` 里是具体原因 |
| 503 | MQTT 未启用或发布连接断开（仅发布类接口） |

---

## 7. MQTT 话题

地图端订阅和发布的话题如下。需要**变更通知**（而不是轮询）时订阅这些话题。

### 地图端订阅（QoS 1）

```
mine/{mine_id}/truck/#
```

| 话题 | 载荷 |
|---|---|
| `mine/{mine_id}/truck/{truck_id}` | 遥测：经纬度、`soc`、`speed_kmh`、`rtk_status`、`fault_code` 等 |
| `mine/{mine_id}/truck/{truck_id}/status` | 在线状态：`online`（布尔）、`reason`、`gps_connected`、`rtk_connected`；由设备遗嘱发布 |

### 地图端发布（QoS 1，全部 `retain=true`）

| 话题 | 载荷 |
|---|---|
| `mine/{mine_id}/map/{loading\|unloading\|charging}/{node_id}` | 与第 3 节 nodes 的单个元素同构，另含 `revision` |
| `mine/{mine_id}/map/matrix` | 与第 3 节 matrix 同构，另含 `revision` |
| `mine/{mine_id}/map/{type}/{node_id}`（**空载荷**） | 表示删除该功能区，同时清除 broker 上的保留消息 |

**地图端不订阅 `mine/{mine_id}/map/#`** —— 配置以地图包文件为唯一权威，`map/#` 是纯出站通道。

### 保留消息与"读不到最新值"

`map/#` 的消息是 retained 的，编辑页提交时**只有勾选"发布 MQTT"才会发出**。
如果不勾选，地图包文件会更新（HTTP 接口能读到新值），但 broker 上的保留消息仍是旧的，
订阅方会看到旧数据。

**如果对外承诺了 MQTT 通道，编辑页提交时请始终勾选"发布 MQTT"。**

---

## 8. 常见对接场景

### 只想知道"现在有几辆车、在哪"

轮询 `GET /api/runtime/{mine_id}/trucks`，建议间隔 ≥ 1 秒。
这份数据没有历史，程序重启后为空。

### 需要车辆轨迹历史

**当前不支持。** 服务只在内存里保存每辆车的最新一条记录，不上数据库、不落盘。
需要历史的话得先加持久化（见 `docs/` 下的存储相关讨论）。

### 要读功能区配置

`GET /api/runtime/{mine_id}/nodes`。接口返回内容与监控页显示一致，
不受 MQTT 连接状态影响。

### 要"车一进装货区就通知我"

HTTP 轮询不合适，订阅 `mine/{mine_id}/truck/#`，自己判断位置是否落在功能区六边形内。
地图端本身没有围栏告警功能。

### 要算两台设备间的距离和时间

`POST /api/maps/{map_id}/route`。注意需要的是 `map_id` 而不是 `mine_id`，
两者的对应关系可从 `GET /api/maps` 查。

---

## 9. 已知限制

| 限制 | 说明 |
|---|---|
| 无鉴权 | 所有接口都可匿名访问，务必只在回环/内网使用 |
| 无 CORS | 浏览器跨域调用会被拦。服务端脚本、Postman 调用无此问题 |
| 无版本前缀 | 路径没有 `/api/v1`，后续变更可能影响调用方 |
| 无接口文档自动生成 | 本文档为手写，改动接口时请同步更新 |
| 车辆数据无持久化 | 重启即空，无历史 |
| 只支持 POST 查询路径 | 没有 GET 形式，不方便直接放浏览器地址栏 |
| 单进程 | 当前用 Flask 开发服务器，多系统并发调用建议换 gunicorn/waitress |
