# 地图端MQTT约定

## 订阅范围

后端按地图包中的 `mine_id` 订阅（QoS 1），**只订阅卡车话题**：

- `mine/{mine_id}/truck/#`：卡车遥测与遗嘱

`map/#` 是**出站通道**：地图端只发布，不订阅。功能区与矩阵以地图包文件
（`map_data/<map_id>/nodes.geojson`、`matrix.json`）为唯一权威，地图端不消费自己发布的配置，
避免"文件已更新、内存副本还是旧的"这类双真相问题。

因此订阅账号只需要 `truck/#` 的订阅权限，不需要 `map/#`。

## 主题总表

| 用途 | 话题 | 方向 | QoS / Retain |
|---|---|---|---|
| 卡车遥测 | `mine/{mine_id}/truck/{truck_id}` | Gateway → 地图 | QoS 1，不保留 |
| 卡车在线状态 | `mine/{mine_id}/truck/{truck_id}/status` | Gateway → 地图 | QoS 1，建议保留；离线由遗嘱发布 |
| 装货点地图信息 | `mine/{mine_id}/map/loading/{node_id}` | 地图端 → 外部系统 | QoS 1，保留 |
| 卸货点地图信息 | `mine/{mine_id}/map/unloading/{node_id}` | 地图端 → 外部系统 | QoS 1，保留 |
| 充电区地图信息 | `mine/{mine_id}/map/charging/{node_id}` | 地图端 → 外部系统 | QoS 1，保留 |
| 0/1装卸匹配矩阵 | `mine/{mine_id}/map/matrix` | 地图端 → 外部系统 | QoS 1，保留 |

外部系统要读当前功能区和矩阵，推荐直接调 HTTP 接口
（`GET /api/runtime/{mine_id}/nodes`、`/matrix`），它们与界面读同一份地图包文件；
需要变更通知时再订阅上表的 `map/#`。

## 消息解析规则

- **卡车遥测**（`truck/{id}`）：保存 `truck_id`、经纬高、`soc`、`speed_kmh`、`rtk_status`、
  `fault_code`。`fault_code` 缺失时补默认值 `00000000`。
- **地图信息**（`map/{type}/{node_id}`）：完整属性（`node_id`、经纬高、`servers`、
  `max_queue`、`average_time_min`、`priority`、`status`、`timestamp`），
  并附带 `revision`（来自地图包 `manifest.editor_revision`），消费方据此判断新旧。
- **矩阵**（`map/matrix`）：`semantics=loading_unloading_match`；`row_node_ids` 对应装货点，`column_node_ids` 对应卸货点，`matrix` 按这些ID动态生成且只含0或1。1表示业务匹配，不表示道路通行权限。

## 字段约束

- `soc` 范围 0～100，允许为 `null`。
- `status` 只能是 `open` 或 `closed`。
- `matrix` 行数必须等于 `row_node_ids` 数量，每行列数必须等于 `column_node_ids` 数量，并且只包含0/1。
- `fault_code` 按位故障字符串：`00000000` 正常、`00000001` GPS故障、
  `00000010` SOC故障、`00000100` CAN故障；RTK 状态 1/4/5 不判定为 GPS 硬件故障。

删除功能区时，地图端会向该功能区主题发送空的 Retain 消息，从EMQX中清除旧的保留消息。

## 双连接账号

后端使用**两个 MQTT 连接**，账号可分别指定：

- **订阅连接**（接收 Gateway 数据）：`.env` 的 `MQTT_SUB_USERNAME` / `MQTT_SUB_PASSWORD`。
- **发布连接**（发布功能区与矩阵）：`.env` 的 `MQTT_PUB_USERNAME` / `MQTT_PUB_PASSWORD`。
- 未单独指定时回退到 `MQTT_USERNAME` / `MQTT_PASSWORD`。

- 发布账号应允许发布 `mine/{mine_id}/map/#`；订阅账号只需允许订阅
  `mine/{mine_id}/truck/#`。
- 不同客户端必须使用不同 `MQTT_CLIENT_ID`（后端自动附加 `_sub` / `_pub` 后缀区分）。
- 出现 `Not authorized` 说明 EMQX 账号缺少对应 `mine/#` 权限。

EMQX 账号需要当前矿区卡车话题的订阅权限，以及地图节点和矩阵话题的发布权限。只给旧的 `mine/test/gps` 权限无法使用本项目。
